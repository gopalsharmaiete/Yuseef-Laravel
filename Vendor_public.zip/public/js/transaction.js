
$(document).ready(function(){  
    $('.saveref').submit(function (e) {
        e.preventDefault();
        var formName = $(this).closest('form').attr('name')
  
        var form = $(this).parents('form:first');
        var formid = this.name;
        //var idd =  $(form).parents('.transactionDetails');
        $('#'+formid +' .savewireref').html('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Loading...</span>');
             var refno = $(".refno").val();
             
             var remark = $('.remark').val();
             var transaction_id = $('.transaction_id').val();
             
             var pdata = {"_token":token(), 'refno': refno, 'remark': remark, 'transaction_id': transaction_id};
                        $.ajax({
                            type:"POST",
                            url:siteurl()+"/save-wire-reference",
                            data: pdata,
                            cache: false,
                            success: function (data) {// success callback function
                              if(data.status == 'success'){
                                  
                                
                                $('#'+formid ).html('<p style="color:green;">'+data.message+'</p>');
                                
                                //$(form).remove();
                              } else{
                                  $('#'+formid +' .savewireref').html('Submit');
                                  $('#'+formid ).appand('<p style="color:red;">'+data.message+'</p>');
                              }
                             
                            },
                            error: function(data){
                              console.log(data);
                              $('.savewireref').html('Submit');
                              alert('fail to proceed payment process.');
                            }
                            
                        });
                  
             });
  
});
    