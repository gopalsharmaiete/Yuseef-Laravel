
$(document).ready(function(){

/* Delete files in property edit page */
  // Delete 
  $('.delete').click(function(){
    var el = this;
  
    // Delete id
    var deleteid = $(this).data('id');
    var filename = $(this).data('name');
 
    // Confirm box
    bootbox.confirm("Do you really want to delete record?", function(result) {
 
       if(result){
       	var pdata = {"_token": token(), "id" : deleteid, "path" : "images/properties", "file" : filename};
         // AJAX Request
         $.ajax({
           url: siteurl()+'/deletefile',
           type: 'POST',
           data:  pdata,
           success: function(data){
             // Removing row from HTML Table
             if(data.status == 'success'){
			    $(el).closest('div').css('background','gray');
			    $(el).closest('div').fadeOut(800,function(){
			       $(this).remove();
			    });
			  }else{
			    bootbox.alert('Record not deleted.');
			  }

           }
         });
       }
 
    });
 
  });


/*Code for accept shares request*/
$(".accept_shares").click(function(){
    $.ajax({
    url:siteurl()+'/AcceptSharesAjax',
    type:'GET',
    data:{id:$(this).val(),'property_id':$(this).attr('propId'),'property_name':$(this).attr('propName')},
    success:function(data){
       if(data.status=="error"){
        alert(data.message);
      }
      if(data.status=="success"){
        alert('Approved');
        location.reload();
      }
      else{
        alert('Some issue please try again');
      }
    }
  });
});

/*End code for accept shares request*/


/*Code for reject shares request*/
$(".reject_shares").click(function(){
  $.ajax({
  url:siteurl()+'/RejectSharesAjax',
  type:'GET',
  data:{id:$(this).val(),'property_id':$(this).attr('propId'),'property_name':$(this).attr('propName')},
  success:function(data){
    if(data.status="success"){
      alert('Rejected');
      location.reload();
    }
    else{
      alert('Some issue please try again');
    }
  }
});
});

/*End code for reject shares request*/

/*Code for refuse shares*/
$(".refuse_shares").click(function(){
  
  $(this).closest("div.sellequity").find('.listoffer').hide();
  $(this).closest("div.sellequity").find('.editofferer').show();
  $(this).parent().hide();
});
/*End code for refuse shares*/


/*Code for accept/reject Counter bid request*/
$(".action_bid").click(function(){
  $.ajax({
  url:siteurl()+'/CounterBidAjax',
  type:'GET',
  data:{id:$(this).val(),'property_id':$(this).attr('propId'),'property_name':$(this).attr('propName'),'action':$(this).attr('act'),'ToUser':$(this).attr('ToUser')},
  success:function(data){
    if(data.status == 'error'){
       alert(data.message);
    } else if(data.status=="accepted"){
      alert('Approved');
      location.reload();
    }
    else if(data.status=="rejected"){
      alert('Rejected');
      location.reload();
    }
    else{
      alert('Some issue please try again');
    }
  }
});
});

/*End code for accept shares request*/




});



function checkShares(input,val,maxval) {
 
    maxval = parseInt(maxval);
    val = parseInt(val);
   if(val > maxval){
      alert("You Don't Have Enough Shares");
      $(input).val(maxval);
    }

 }

  