$(document).ready(function () {
    var windwdth = $(window).width();
    $('.hdrRight .investorBtun').on('click', function () {
        $(this).next().slideToggle('fast');
        $(this).toggleClass('active');
    })

    function sliderInitialize() {
        $('.owl-carousel.topSlider').owlCarousel({
            loop: true,
            autoplay: true,
            animateOut: 'fadeOut',
            margin: 10,
            nav: false,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            }
        })
    }

    $('.owl-carousel.logo').owlCarousel({
        loop: true,
        autoplay: true,
        margin: 10,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            400: {
                items: 2
            },
            600: {
                items: 3
            },
            900: {
                items: 4
            },
            1000: {
                items: 6
            },
            1200: {
                items: 7
            }
        }
    })


    function slidrHgt() {
        var hrd = $('.headerBox').height();
        var wind = $(window).height();
        var finalHt = wind - hrd;
        var slidrTxtPos = wind - 395;

        $('.bannerSection').css({ 'height': finalHt });
        $('.bannerSection .insdItem').css({ 'height': finalHt });
        $('.insdItem .sliderTxt').css({ 'top': slidrTxtPos - 50 })
    }

    if (windwdth > 1024) {
        slidrHgt()
        $(window).resize(function () {
            slidrHgt()
        })
        $(window).scroll(function () {
            slidrHgt()
        })

    }

    setTimeout(function () {
        sliderInitialize();
    }, 500);

    $('.hdrRight .dropMenu .butnDrop').on('click', function () {
        $(this).toggleClass('active');
        $('.fullMenu').slideToggle('fast');
    })


    //video play 
    var vid = document.getElementById('videoPlayer');

    function playVideo() {
        vid.play();
        $('.playBtn').hide();
        $('.videoCntr').addClass('active');

    }

    function pauseVid() {
        vid.pause();
        $('.videoCntr').removeClass('active');
        $('.playBtn').show();
    }



    $('.videoCntr a.playBtn').on('click', function () {
        playVideo();
    })

    $('video#videoPlayer').on('click', function () {
        pauseVid();
    });


    $(".bannerSection .mouseBox").click(function () {
        $('html, body').animate({
            scrollTop: $(".logoSection").offset().top
        }, 400);
    });


    if (windwdth < 1025) {
        var fullMenu = $('.fullMenu');
        $(fullMenu).clone().appendTo('.navBar nav').addClass('forMobile');

        $('.headerBox .mobileMenu').on('click', function () {
            $('.hdrRight .navBar').toggleClass('active');
            $(this).toggleClass('active');
            $('body').toggleClass('active');
        })

    }

    $('.dropLang').on('click', function () {
        $(this).next().slideToggle('fast');
        $('.loginSectn .settingDrop').slideUp('fast');
        $('.dropLogin .insdLogin').removeClass('active');
    })

    var bellLength = 61;
    var totalHgt = bellLength * 3;
    var liHeight = $('.bellDropBox li').length;
    var FullHgt = bellLength * liHeight;
    console.log(liHeight);
    $('.loginSectn .bellDropBox ul').css({ 'height': totalHgt + 3 });
    $('.bellDropBox cite').on('click', function () {
        $('.hdrRight .loginSectn .bellDropBox ul').css({ 'height': FullHgt });
        $(this).hide();
        e.stopPropagation();
    })

    if ($(liHeight) > 7) {
        $('.loginSectn .bellDropBox').addClass('exceedHeight');
    }
    else {
        $('.loginSectn .bellDropBox').removeClass('exceedHeight');
    }

    $('.bellBar a.bellIcon').on('click', function () {
        $(this).next().slideToggle('fast');
        $('.loginSectn .settingDrop').slideUp('fast');
        $('.dropLogin .insdLogin').removeClass('active');
    })

    $(document).click(function (e) {
        if (!$(e.target).is('.bellDropBox ul *, .bellDropBox cite, .bellBar a.bellIcon')) {
            $('.bellDropBox').hide();
            $('.loginSectn .bellDropBox ul').css({ 'height': totalHgt + 3 });
            $('.bellDropBox cite').show();
        }
    });

    $('.dropLogin .insdLogin').on('click', function () {
        $(this).next().slideToggle('fast');
        $(this).toggleClass('active');
    })

    $('.closeDashbord').on('click', function () {
        $('body').removeClass('activeDashbord');
        $('.dashBoardMenu').removeClass('active');
    })

    $('.openDashbord').on('click', function () {
        $('body').addClass('activeDashbord');
        setTimeout(function () {
            $('.dashBoardMenu').addClass('active');
        }, 200);
    })


  
        $('span.mobileDashTrigger').on('click', function () {
            $('body').addClass('activeDashbord');
        })
   

})