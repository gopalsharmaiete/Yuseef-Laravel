$(document).ready(function(){  

    $("#example1").dataTable({
      dom: 'Bfrtip',
      buttons: [
          'copy', 
          {extend:'csvHtml5',filename:'properties'}, 
          {extend:'excelHtml5',filename:'properties'}, 
          {extend:'pdfHtml5',filename:'properties'}, 
          'print'
      ]
  });
  
  
  });
  

  