$(document).ready(function(){  
  if($("#" + name).length > 0) {
      $("#example1").dataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
   } 
    
    });

    $(document).ready(function () {
      var offset = limit = '9';
      var s = $('#searchtext').val();
  
      $('#load').click(function (e) {
          e.preventDefault();
          var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset};
          $.ajax({
              type:"GET",
              url:"blog-load",
              data: pdata,
              success: function (data, status, xhr) {// success callback function
                  offset =parseInt(offset)+9;
                  if(data.html == ""){                    
                      $('.ajax-load').show();
                      $('.seProj').hide();                
                      $('.ajax-load').html("No more records found");
                      return;
                  }
                  $("#grid").append(data.html);
            }
              
          });
  
      });
  
      $(window).scroll(function() { 
          if($(window).scrollTop() == $(document).height() - $(window).height()) { 
            var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset};
              $('.ajax-load').show();
              $.ajax({
                  type:"GET",
                  url:"blog-load",
                  data: pdata,
                  success: function (data, status, xhr) {// success callback function
                      offset =parseInt(offset)+9;
                      if(data.html == ""){                    
                          $('.ajax-load').show();
                          $('.seProj').hide();                
                          $('.ajax-load').html("No more records found");
                          return;
                      }else
                      {
                          $('.ajax-load').hide();                        
                      }
                      $("#grid").append(data.html);
                }
                  
              });
          }
      });
  
  });
    
  