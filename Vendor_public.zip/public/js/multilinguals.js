$(document).ready(function(){  

    $("#example1").dataTable({
      dom: 'Bfrtip',
      buttons: [
          'copy',     
          {extend:'csvHtml5',filename:'multilingual'}, 
          {extend:'excelHtml5',filename:'multilingual'}, 
          {extend:'pdfHtml5',filename:'multilingual'},  'print'
      ]
  });
  
  
  });
  
 // $(document).ready(function () {
        $('.dtedit').click(function () {
             var sid = $(this).val();
            var currentTD = $(this).parents('tr').find('td');
            if ($(this).html() == 'Edit') {                  
                $.each(currentTD, function () {
                  if($(this).find('button').length == 0)
                  {
                    $(this).prop('contenteditable', true);
                    $(this).css('background-color', '#bfbfbf')
                  }
                });
            } else {
              var pdata = {"_token":$('meta[name="csrf-token"]').attr('content')};           
               $.each(currentTD, function () {
                if($(this).find('button').length == 0)
                  {                               
                    var str = $(this).html();     
                    str = str.replace(/<[^>]*>/g, '');
                    pdata[$(this).attr('name')] = str.trim();
                    $(this).prop('contenteditable', false);
                    $(this).css('background-color', '#fff')
                  }
                });
               
                $.ajax({
                              type:"PUT",
                              url:"multilingual/"+sid,
                              data: pdata,
                success: function (data, status, xhr) {// success callback function
              alert("updated Successfully");
              }
                              
                      });
               
            }
  
            $(this).html($(this).html() == 'Edit' ? 'Save' : 'Edit')
  
        });
  
        $('.del').click(function () {
             var sid = $(this).val();
             var pdata = {"_token":"{{ csrf_token() }}"};
                        $.ajax({
                            type:"DELETE",
                            url:"multilingual/"+sid,
                            data: pdata,
                            success: function (data, status, xhr) {// success callback function
                          alert("Deleted Successfully");
                          location.reload();
                          }
                            
                        });
             });
			 
			$('.copy').click(function () {
             var sid = $(this).val();
             var pdata = {"_token":"{{ csrf_token() }}", "id":sid};
                        $.ajax({
                            type:"GET",
                            url:"multilingual/create",
                            data: pdata,
                            success: function (data, status, xhr) {// success callback function
                              $("#label").val(data[0].label);
                              $("#group").val(data[0].group);
                              $("#description").val(data[0].description);
                            }
                            
                        });
             });
  
   // });
   
		  
$("#imp-csv-form").submit(function(event){
	event.preventDefault(); //prevent default action 
	var form_data = $(this).serialize(); //Encode form elements for submission
		$.ajax({
		url : post_url,
		type: request_method,
		data : form_data
	}).done(function(response){ //
		$("#server-results").html(response);
	});
});		  
		  