$(document).ready(function(){  

    $("#example1").dataTable({
      dom: 'Bfrtip',
      buttons: [
          'copy', 
          {extend:'csvHtml5',filename:name},
          {extend:'excelHtml5',filename:name},
          {extend:'pdfHtml5',filename:name}, 
          'print'
      ]
  });
  
  
  });
    