
/* Email varification */
function emailFunction() {
  var x = document.getElementById("email");
  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;
  if(x.value.match(mailformat))
  {
    $('#email').removeClass('is-invalid');
    var pdata = {"_token": token(), 'email': x.value};
      $.ajax({
            type:"POST",
            url:"ValidateEmail",
            data: pdata,
            cache: false,
            success: function (data) {// success callback function
              if(data.status == 'error'){
                  $('.box-footer').css('display','none');
                  $('.form_email .help-block').html('<p style="color:red;">Email already exist. Please <a href="#" class="moreB" data-toggle="modal" data-target="#login">signin</a>.</p>');
                  //document.checkout.email.focus();
              } else{
                $('.form_email .help-block').html('');
                $('.box-footer').css('display','block');
              }
              
            },
            error: function(data){
              alert('failed to check email...');
            }
            
        });
  }
  else
  {
    $('#email').addClass('is-invalid');
    //document.checkout.email.focus();
    return false;
  }
}
/* Email varification end*/


$(document).ready(function(){  



/*User login on popup */
$('#userlogin').click(function (e) {
        e.preventDefault();
             var username = $("#popupemail").val();
             var password = $('#password').val();
             var pdata = {"_token":token(), 'username': username, 'password': password};
                        $.ajax({
                            type:"POST",
                            url:"loginajax",
                            data: pdata,
                            cache: false,
                            success: function (data) {// success callback function
                              if(data.status == 'success'){
                                console.log("Login Successfully");
                                  $('.checkoutlogin .helpblock').html('<p style="color:green;">'+data.message+'</p>');
                                  location.reload();
                              } else{
                                console.log("Login error");
                                  $('.checkoutlogin .helpblock').html('<p style="color:red;">'+data.message+'</p>');
                              }
                              
                            },
                            error: function(data){
                              alert('fail to run login...');
                            }
                            
                        });
             });
/*User login on popup end */
  
    $("input[name='paymentMethod']").click(function(){
	    $(".checkout_btn").empty();
	    $(".checkout_btn").append('<span class="glyphicon glyphicon-refresh glyphicon-refresh-animate">');
	   
	    var gateway = $('input:radio[name=paymentMethod]:checked').val();
	    var pdata = {"_token": token(), "gateway" : gateway };
	    $.ajax({
            type:"POST",
            url:"paymentgateway",
            data: pdata,
            success: function (data) {// success callback function
                if(data.html == ""){                    
                    $('.ajax-load').html("There is some error in load of payment gateway. Please refresh the page try again.");
                    return;
                }
				$(".checkout_btn").empty();
                $(".checkout_btn").append(data.html);                
          }
            
        });

	});

    $('#checkoutpayment55').click(function (e) {
     
        e.preventDefault();
        $("#checkoutpayment").html('<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i><span class="sr-only">Loading...</span>');
             var name = $("#name").val();
             var email = $('#email').val();
             var address = $('#address').val();
             var islogin = $('#islogin').val();
             var amount = $('#amount').val();
             var property_id = $('#property_id').val();
             var user_id = $('#user_id').val();
             var currency = $('#currency').val();
             var commission_percentage = $('#commission_percentage').val();
             var commission_amount = $('#commission_amount').val();
             var total = $('#total').val();
             var gateway = $('input:radio[name=transfer]:checked').val();
             var pdata = {"_token":token(), 'name': name, 'email': email, 'address': address, 'islogin': islogin, 'amount': amount, 'property_id': property_id, 'user_id': user_id, 'currency': currency, 'gateway': gateway, 'commission_percentage': commission_percentage, 'commission_amount': commission_amount, 'total': total};
                        $.ajax({
                            type:"POST",
                            url:"finalCheckout",
                            data: pdata,
                            cache: false,
                            success: function (data) {// success callback function
                             
                              if(data.status == 'success'){
                                  $('#tableID').val(data.id);
                                  $('#orderID').val(data.orderID);
                                  var user_id = $('#userid').val();
                                  if(user_id == null || user_id == ""){
                                      $('#userid').val(data.userID);
                                  }
                                  
                                  if(gateway == 'wiretransfer'){                                   
                                    window.location = "http://40.121.65.234:8098/property/public/payment/wire-transfer?id="+data.id;
                                  } else{
                                    // $("#2coform").submit();
                                   //var x = document.getElementsByName('checkout');
                                    //x[0].submit();
                                    window.location = "http://40.121.65.234:8098/property/public/payment/gateway-transfer?id="+data.id+"&gateway="+gateway;
                                  }
                                  //$("#gatewayCheckout").click();
                                  $("#checkoutpayment").html('Proceed');
                              } else{
                                alert(data.status);
                                  $("#checkoutpayment").html('Proceed');
                                  $('.help-block').html('<p style="color:red;">'+data.message+'</p>');
                              }
                             
                            },
                            error: function(data){
                              console.log(data);
                              $("#checkoutpayment").html('Proceed');
                              alert('fail to proceed payment process.');
                            }
                            
                        });
             });

            });

