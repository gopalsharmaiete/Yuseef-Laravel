$(document).ready(function () {
    var offset = limit = '9';
    var type = $('#offering_type option:selected').val();
    var status = $('#funded_status option:selected').val();
    var country  = $('#country option:selected').val();
    var s = $('#searchtext').val();

    $('#load').click(function (e) {
        e.preventDefault();
        var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset, "offering_type":type, "funded_status":status, "s":s, "country":country};
        $.ajax({
            type:"GET",
            url:"shop/load",
            data: pdata,
            success: function (data, status, xhr) {// success callback function
                offset =parseInt(offset)+9;
                if(data.html == ""){                    
                    $('.ajax-load').show();
                    $('.seProj').hide();                
                    $('.ajax-load').html("No more records found");
                    return;
                }
                $("#grid").append(data.html);
          }
            
        });

    });

    $(window).scroll(function() { 
        if($(window).scrollTop() == $(document).height() - $(window).height()) { 
            var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset, "offering_type":type, "funded_status":status, "s":s, "country":country};
            $('.ajax-load').show();
            $.ajax({
                type:"GET",
                url:"shop/load",
                data: pdata,
                success: function (data, status, xhr) {// success callback function
                    offset =parseInt(offset)+9;
                    if(data.html == ""){                    
                        $('.ajax-load').show();
                        $('.seProj').hide();                
                        $('.ajax-load').html("No more records found");
                        return;
                    }else
                    {
                        $('.ajax-load').hide();                        
                    }
                    $("#grid").append(data.html);
              }
                
            });
        }
    });

});


$(function() {
    $('#type').change(function() {
        this.form.submit();
    });
    $('#status').change(function() {
        this.form.submit();
    });

    $('.filterform').change(function() {
        this.form.submit();
    });
});