$(document).ready(function(){  

    $("#example1").dataTable({
      dom: 'Bfrtip',
      buttons: [
          'copy', 'csv', 'excel', 'pdf', 'print'
      ]
  });
  
  
  });
  
  $(document).ready(function () {
        $('.dtedit').click(function () {
             var sid = $(this).val();
            var currentTD = $(this).parents('tr').find('td');
            if ($(this).html() == 'Edit') {                  
                $.each(currentTD, function () {
                  if($(this).find('button').length == 0)
                  {
                    $(this).prop('contenteditable', true);
                    $(this).css('background-color', '#bfbfbf')
                  }
                });
            } else {
              var pdata = {"_token":$('meta[name="csrf-token"]').attr('content')};           
               $.each(currentTD, function () {
                if($(this).find('button').length == 0)
                  {                               
                    var str = $(this).html();   
                    str = str.replace(/<[^>]*>/g, '');  
                    pdata[$(this).attr('name')] = str.trim();
                    $(this).prop('contenteditable', false);
                    $(this).css('background-color', '#fff')
                  }
                });
               
                $.ajax({
                              type:"PUT",
                              url:"permissions/"+sid,
                              data: pdata,
                success: function (data, status, xhr) {// success callback function
              alert("updated Successfully");
              }
                              
                      });
               
            }
  
            $(this).html($(this).html() == 'Edit' ? 'Save' : 'Edit')
  
        });
  
        $('.del').click(function () {
             var sid = $(this).val();
             var pdata = {"_token":"{{ csrf_token() }}"};
                        $.ajax({
                            type:"DELETE",
                            url:"permissions/"+sid,
                            data: pdata,
                            success: function (data, status, xhr) {// success callback function
                          alert("Deleted Successfully");
                          location.reload();
                          }
                            
                        });
             });
  
    });
  