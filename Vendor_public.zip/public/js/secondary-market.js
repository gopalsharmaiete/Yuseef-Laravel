$(document).ready(function () {
    var offset = limit = '9';
    var type = $('#offering_type option:selected').val();
    var status = $('#funded_status option:selected').val();
    var country  = $('#country option:selected').val();
    var design = $('#design').val();
    var s = $('#searchtext').val();

    $('#load').click(function (e) {
        e.preventDefault();
        var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset, "offering_type":type, "funded_status":status, "s":s, "country":country,"design":design};
        $.ajax({
            type:"GET",
            url:"secondary/load",
            data: pdata,
            success: function (data, status, xhr) {// success callback function
                offset =parseInt(offset)+9;
                if(data.html == ""){                    
                    $('.ajax-load').show();
                    $('.seProj').hide();                
                    $('.ajax-load').html("No more records found");
                    return;
                }
                $("#grid").append(data.html);
          }
            
        });

    });

    $(window).scroll(function() { 
        if($(window).scrollTop() == $(document).height() - $(window).height()) { 
            var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset, "offering_type":type, "funded_status":status, "s":s, "country":country,"design":design};
            $('.ajax-load').show();
            $.ajax({
                type:"GET",
                url:"secondary/load",
                data: pdata,
                success: function (data, status, xhr) {// success callback function
                    offset =parseInt(offset)+9;
                    if(data.html == ""){                    
                        $('.ajax-load').show();
                        $('.seProj').hide();                
                        $('.ajax-load').html("No more records found");
                        return;
                    }else
                    {
                        $('.ajax-load').hide();                        
                    }
                    $("#grid").append(data.html);
              }
                
            });
        }
    });

});


$(function() {
    $('#type').change(function() {
        this.form.submit();
    });
    $('#status').change(function() {
        this.form.submit();
    });

    $('.filterform').change(function() {
        this.form.submit();
    });

    $('#shares').change(function() {        
        amount = this.value*$('#share_unit_price').val();
        $('#share_total').text('= '+amount+' EGP');
    });
});




/*User login on popup */
$(document).ready(function () {
$('#userlogin').click(function (e) {
    e.preventDefault();
         var username = $("#popupemail").val();
         var password = $('#password').val();
         var pdata = {"_token":token(), 'username': username, 'password': password};
                    $.ajax({
                        type:"POST",
                        url: siteurl()+"/investment/loginajax",
                        data: pdata,
                        cache: false,
                        success: function (data) {// success callback function
                          if(data.status == 'success'){
                              $('.loginForm .help-block').html('<p style="color:green;">'+data.message+'</p>');
                              location.reload();
                          } else{
                              $('.loginForm .help-block').html('<p style="color:red;">'+data.message+'</p>');
                          }
                          console.log("Login Successfully");
                        },
                        error: function(data){
                          alert('fail to run login...');
                        }
                        
                    });
         });
});
/*User login on popup end */


$(document).ready(function(){
    var offset = limit = '9';
    var type = $('#offering_type option:selected').val();
    var status = $('#funded_status option:selected').val();
    var country  = $('#country option:selected').val();
    var design = $('#design').val();
    var s = $('#searchtext').val();
    
    $('#load-offer').click(function (e) {
        e.preventDefault();
        var pdata = {"_token":"{{ csrf_token() }}","limit":limit,"offset":offset, "offering_type":type, "funded_status":status, "s":s, "country":country,"design":design};
        $.ajax({
            type:"GET",
            url:"secondary-offer/load",
            data: pdata,
            success: function (data, status, xhr) {// success callback function
                offset =parseInt(offset)+9;
                if(data.html == ""){                    
                    $('.ajax-load').show();
                    $('.seProj').hide();                
                    $('.ajax-load').html("No more records found");
                    return;
                }
                $("#grid").append(data.html);
          }
            
        });

    });

});