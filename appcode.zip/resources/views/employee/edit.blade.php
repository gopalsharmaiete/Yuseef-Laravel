@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Edit User</h1>
@stop

@section('content')
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="save" novalidate method="post" role="form" action="{{url('employee/'.$Employee[0]->id)}}" enctype="multipart/form-data">               
                {{ csrf_field() }}
										{{ method_field('PATCH') }}
                  <div class="box-body">
                        <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                          <input name="name" type="text" class="form-control" id="exampleInputEmail1" value="{{$Employee[0]->name}}" placeholder="Enter  Name" required>
                        </div>
                        
                        @if(Auth::user()->role=='1')                        
                        <div class="form-group">
                            <!--<label>Role</label>-->
                            <select class="form-control" name='role' id='role'>
                                <option value="">Choose Role </option>
                                @foreach($roles as $key=>$val)
                                <option {{($Employee[0]->role==$key)?'selected':''}} value={{$key}} >{{$val}}</option>
                                @endforeach
                            </select>
                        </div>
                        @endif
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/employee.js') }}"></script>
@stop