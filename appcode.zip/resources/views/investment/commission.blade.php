@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    

   <!-- Main content -->
 
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="save" method="post" role="form" action="{{url('set-commission-percentage')}}" enctype="multipart/form-data">               
                {{ csrf_field()}}
									
                  <div class="box-body">
                        
                  <div class="form-group has-feedback {{ $errors->has('commission') ? 'has-error' : '' }}">
                    <input type="text" name="commission" class="form-control" value="{{ $commission['1'] }}"
                           placeholder="Commission" required>

                    @if ($errors->has('commission'))
                        <span class="help-block">
                            <strong>{{ $errors->first('commission') }}</strong>
                        </span>
                    @endif
                </div>
               
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/property.js') }}"></script>
@stop