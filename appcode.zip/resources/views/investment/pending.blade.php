@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing {{ucfirst(Request::path())}}</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>                        
                        <th>Property</th>
                        <th>Investor</th>
                        <th>Transaction Id</th>
                        <th>Amount</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($GatewayTransaction as $id=>$key)
                      <tr>                      
                        <td>{{$key->property->name}}</td>
                        <td>{{$key->user->name}}</td>
                        <td>{{$key->txn_id}}</td>
                        <td>{{$key->amount}}</td>
                        <td>@if(RolesHelper::check('3','17'))<button class='update_status' type="button" id="approve" value="{{$key->id}}">Approve</button>@endif&nbsp;@if(RolesHelper::check('3','17'))<button class='update_status' type="button"  id="disapprove" value="{{$key->id}}">Disapprove</button>@endif</td>
                      </tr>
                    @endforeach
                     
                   
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/property.js') }}"></script>

<script>

$(document).ready(function () {

  $('.update_status').click(function () {
    var status = $(this).attr('id');
    var id= $(this).val();

            var pdata = {"_token":"{{ csrf_token() }}","status":status,"id":id};
            $.ajax({
                type:"POST",
                url:"update-investment-status",
                data: pdata,
                success: function (data, status, xhr) {// success callback function
              alert("Successfully");
              location.reload();
              }
                
            });

  });

});

</script>

@stop