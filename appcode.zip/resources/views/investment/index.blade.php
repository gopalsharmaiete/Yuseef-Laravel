@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                    <!-- form start -->
          <form name="map-role-permission" method="get" action="{{url('investment-history')}}"> 
                  {{ csrf_field() }}

                  <div class="box-body">
                  <div class="row">
                    <div class="col-xs-3">
                    <div class="form-group">
                          
                          <select class="form-control" name='invester' id='invester'>
                              <option value="">Choose Investor </option>
                              @foreach($invester as $key=>$val)
                                  @php
                                    $selected = '';
                                    if($request->invester==$key)
                                      {
                                        $selected = 'selected';
                                      }
                                  @endphp
                              <option {{$selected}} value="{{$key}}">{{$val}}</option>
                              @endforeach
                          </select>
                      </div>
                    </div>
            
                    <div class="col-xs-4 form-group has-feedback {{ $errors->has('start_date') ? 'has-error' : '' }}">  
                    <input type="text" name="start_date" id="start_date"  class="form-control"
                           placeholder="start date" value="{{$request->start_date}}" autocomplete="off" required>                  
                    </div>  

                    <div class="col-xs-4 form-group has-feedback {{ $errors->has('end_date') ? 'has-error' : '' }}">  
                    <input type="text" name="end_date" id="end_date"  class="form-control"
                           placeholder="end date" value="{{$request->end_date}}" autocomplete="off" required>                  
                    </div>    

                    <div class="col-xs-1">
                          <div class="form-group">
                          <button class="btn btn-info btn-flat" type="submit">Go</button>                          
                          </div>
                    </div>
                  </div><!--row -->
                </div><!-- /.box-body -->
                @if ($message = Session::get('success'))
                    <div>
                        <p>{{ $message }}</p>
                   </div>
                    @endif

                    @if($errors->any())
                    <label class="control-label" for="inputError"><i class="fas fa-fw fa-times-circle-o"></i>{{$errors->first()}}</label>
                    @endif
        </form>						

              
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing {{ucfirst(Request::path())}}</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>                        
                        <th>Property</th>
                        <th>Invested Amount</th>
                        <th class="sum">Commission Amount</th>
                        <th>Investor</th>
                        <th>Invested Method</th>
                        <th>Transaction id</th>
                        <th>Invested at</th>
                      </tr>
                    </thead>
                    <tbody>
                   
                    @foreach($Investment as $id=>$key)
                      <tr>                      
                        <td>{{$key->property->name}}</td>
                        <td>{{$key['amount']}}</td>                        
                        <td>{{$key->transaction->commission_amount}}</td>
                        <td>{{$key->user->name}}</td>
                        <td>{{$gateways[$key->transaction->gateway_id]??''}}</td>
                        <td>{{$key->transaction->txn_id}}</td>
                        <td>{{$key->user->created_at}}</td>
                      </tr>
                    @endforeach
                     
                     <tfoot align="right">
                      <tr><th></th><th></th><th></th><th></th><th></th><th></th><th></th></tr>
                    </tfoot>  
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/admininvestor.js') }}"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">  
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    $( "#start_date" ).datepicker({ dateFormat: 'yy-mm-dd' });
    $( "#end_date" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
@stop