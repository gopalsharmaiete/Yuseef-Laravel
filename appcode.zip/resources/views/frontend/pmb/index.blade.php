@extends('layouts.user-dashboard-master')
@section('frontcontent')
 
 		<section class="loginPage">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="loginForm">

							<div class="title_head">
								<h1>Personel Board</h1>
							</div>
						
							<div class="innerform">
                                @if(app('request')->input('user') == '')
                                     <form  name="save"  method="get" role="form" enctype="multipart/form-data">
                                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                            <li class="nav-item active">
                                                                <a class="nav-link active" id="recent-tab" data-toggle="tab" href="#recent" role="tab" aria-controls="recent"
                                                                aria-selected="true">Recent</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" id="new-tab" data-toggle="tab" href="#new" role="tab" aria-controls="new"
                                                                aria-selected="false">New</a>
                                                            </li>
                                                           
                                                </ul>
                                                <div class="tab-content" id="myTabContent">
                                                    <div class="tab-pane fade show active in" id="recent" role="tabpanel" aria-labelledby="recent-tab">
                                                      <ul  style="padding-top:50px">
                                                       @foreach($Recents as $recent) 
                                                          @if($recent->from_id == $id) @php continue; @endphp; @endif
                                                        <li><a href="{{ URL('/pmb?user='.$recent->from_id)}}"><strong>{{$recent->fromUserName()[0]}}</strong>&nbsp;>(<i>{{$recent->count}}</i>)&nbsp;{{ $recent->message}}</a></li>
                                                      @endforeach
                                                      </ul>
                                                    
                                                </div>
                                                <div class="tab-pane fade" id="new" role="tabpanel" aria-labelledby="new-tab">
                                                   
                                                        <div class="input_row form-group" style="padding-top:50px">
                                                                    <select class="fld_col" name="user">
                                                                    @foreach($Users as $user)
                                                                        <option value="{{$user->id}}">{{$user->name}}</option>
                                                                    @endforeach
                                                                    </select>
                                                        </div>
                                                        <div class="morInfo_btn submitbtn">
                                                                <input type="submit" class="moreB" value="submit">
                                                        </div>
                                                   
                                                </div>
                                                    
                                            </div>
                                        </form>
                                  @else
                                    <div>
                                        <div class="input_row form-group" style="border:solid 1px;min-height:500px;overflow:scroll" id="messages">&nbsp;</div>
                                        <div class="input_row form-group">
                                            <textarea name="message" class="fld_col" id="message"></textarea>      
                                        </div>
                                            <div class="morInfo_btn submitbtn">
                                                        <input type="submit" class="moreB" id="send" value="Send"  >
                                            </div>

                                        </div>								
                                 @endif
                            </div>
                        </div>
					</div>
				</div>
			</div>
		</section>
 
 
  @stop
  @section('page_scripts')
<script>
  const to = parseInt('{{ app('request')->input('user') }}');
  const from =  parseInt('{{ Auth::user()->id }}');
  const _token = '{{ csrf_token() }}';
  const isReal = '{{ env("ISREALCHAT") }}';
  const timeInterval = parseInt('{{ env("CHATTIME") }}')*1000;
   

  $( document ).ready(function() {
      loadChat();
      
       
  $('#send').click(function(){
                    let message = $('#message').val();
                    if(message == '' || message == undefined){
                        alert('Please enter a message');
                        return false;
                    }

                $.ajax({
                        type: "post",
                        url: "{{URL('/pmb/save')}}",
                        data: {'to': to, 'from': from,'_token':_token,'message':message},
                        dataType: "json",
                        success: function(data) {
                           $('#message').val('');
                            printData(data);
                        }
                    });

         });
    
    
 });

function loadChat(){
       
       $.ajax({
               type: "get",
               url: "{{URL('/pmb/chat')}}",
               data: {'to': to, 'from': from},
               dataType: "json",
               success: function(data) {
                   printData(data);
               }

           });
  }

 function printData(data){
    $('#messages').html('');
    $.each(data, function(i, item) {
                   let to_id = parseInt(data[i].to_id);
                    let from_id = parseInt(data[i].from_id);
                   if(from_id === from ) {
                       
                     $('#messages').append('<p style="padding:2px 0px 0px 10px">(<i>'+data[i].date+'</i>)&nbsp;<strong>'+data[i].from_name+'</strong>:&nbsp;'+data[i].message+'</p>');
                    } else {
                      $('#messages').append('<p style="padding:2px 0px 0px 10px">(<i>'+data[i].date+'</i>)&nbsp;<strong>'+data[i].from_name+'</strong>:&nbsp;'+data[i].message+'</p>');
                      
                    }
     });

     if(isReal) {
          setInterval(loadChat,timeInterval);             
     }
 }


 
</script>


@stop