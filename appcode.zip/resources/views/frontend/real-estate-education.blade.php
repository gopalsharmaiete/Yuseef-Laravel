 @extends('layouts.guest-master')
@section('frontcontent')
	<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
							<li> {{__('menu.real_estate_education')}} </li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList progressHid">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.real_estate_education')}}</h2>
						        <p>{!! __('text.real-estate-education-highlight-text') !!}</p>
								<p class="fontP18">{!! __('text.real-estate-education-page-content') !!}</p>
							</div>
							
							<div class="progress-up">
								<div class="progress">
									<div class="progress-bar"></div>
								</div>
								@php $stepArray = array(0=>'one-step', 1=>'two-step', 2=>'three-step', 3=>'four-step', 4=>'five-step', 5=>'six-step');
								$i = 0; @endphp
								@foreach($imagesData as $key=>$val)
								@php $class = $stepArray[$i]; 
								$imagetext = 'text.'.$val['title'];  @endphp
								<div class="progress-bar-steps {{$class}} act">
									<div class="Real_Estate_Edu_ico"><img src="{{url('/')}}/images/pages/{{$val['name']}}" alt="" title="" ></div>
									<div class="contBProBar">{!! __($imagetext)!!}</div>
								</div>
								@php $i++; @endphp
								@endforeach
								<!--<div class="progress-bar-steps two-step">
									<div class="Real_Estate_Edu_ico"><img src="{{ asset('images/Real_Estate_Edu_ico02.png')}}" alt="" title="" ></div>
									<div class="contBProBar">Select <span>Equity</span></div>
								</div>
								<div class="progress-bar-steps three-step">
									<div class="Real_Estate_Edu_ico"><img src="{{ asset('images/Real_Estate_Edu_ico03.png')}}" alt="" title="" ></div>
									<div class="contBProBar">Agree to <span>Terms & Conditions</span></div>
								</div>
								<div class="progress-bar-steps four-step">
									<div class="Real_Estate_Edu_ico"><img src="{{ asset('images/Real_Estate_Edu_ico04.png')}}" alt="" title="" ></div>
									<div class="contBProBar">Invest</div>
								</div>
								<div class="progress-bar-steps five-step">
									<div class="Real_Estate_Edu_ico"><img src="{{ asset('images/Real_Estate_Edu_ico05.png')}}" alt="" title="" ></div>
									<div class="contBProBar">Monitor <span>your investment</span></div>
								</div>
								<div class="progress-bar-steps six-step">
									<div class="Real_Estate_Edu_ico"><img src="{{ asset('images/Real_Estate_Edu_ico06.png')}}" alt="" title="" ></div>
									<div class="contBProBar">Sell your shares <span>and earn profit</span></div>
								</div>-->
								
							</div><!-- ./progress-up -->
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
			
			<div class="container New">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="videoCntr">
							<a class="playBtn" href="javascript:void(0)">
								<img src="images/video_play.png">
							</a>
							
							<video id="videoPlayer" width="100%" poster="images/video_poster.png">
							  @if(isset($videoData[0]->name))
								  <source src="{{asset('images/video-upload/'.$videoData[0]->name)}}" type="video/mp4">
								@else
									<source src="video/demovideo.mp4" type="video/mp4">
							   @endif
							</video>
						</div>
					</div>
				</div>
			</div>
            
		</section>
@stop
