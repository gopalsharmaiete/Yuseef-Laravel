
@extends('layouts.guest-master')
@section('frontcontent')
	<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
							<li>{{__('menu.about_us')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.about_us')}}</h2>
						        <p>{!! __('text.about_us_top_content') !!}</p>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="bodr"></div>
						</div>
					</div>
				</div>            
			<!-- galryAbout start html -->
            <div class="galryAbout">
               <div class="container New">
                  <div class="row">

                      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          <div class="bagImg" style="padding:0px !important;">
                          	@foreach($imagesData as $key=>$val)
                              <span><img src="{{url('/')}}/images/pages/{{$val['name']}}"></span>
                             @endforeach
                          </div>
                      </div>
                      
                      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                          <div class="Innermelky">
								<h2>{!! html_entity_decode(__('text.about_us_whatwedo_heading')) !!}</h2>
						        <p>{!! html_entity_decode(__('text.about_us_whatwedo_content')) !!}</p>
                          </div>
                      </div>

                  </div> 
               </div>
            </div>
			<!-- galryAbout start html -->
            
		</section>


@stop
