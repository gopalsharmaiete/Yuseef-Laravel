@foreach($Property as $key=>$val)
	              <div class="col-lg-12">
							<div class="secondary_market">
								<div class="sellBlock">
									<div class="Sell_img shop-img">	
                                        @if(isset($val->file[0]->name) && $val->file[0]->module == 'property')
                                            <img src=" {{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
                                        @else
                                            <img src="{{ asset('images/grid1.png') }}" alt="img">
                                        @endif
                                    </div>
									<div class="Sell_txt">
										<div class="innerTitle">
											<div class="lft_sid">
												<h3>{{$val['name']}}</h3>
											</div>
											<div class="rit_sid">
												
											</div>
										</div>
									</div>
									<div class="morInfo_btn mymorInfo_btn">
									@php $url = '/shop/secondary-property/'. $val['id']; @endphp
										<a href="{{URL($url)}}" class="moreB">{{__('text.t-m-info')}}</a>
									</div>
								</div>
								<div class="priceRit_br">
									<div class="prcTitle">
									        @php 
										        $shares = $val->sharesHistory();
												$sharesDebit = $shares->where('type','debit')->sum('share');
												$sharesCredit = $shares->where('type','credit')->sum('share');	
												$actualShares = $val->base_price - ($sharesCredit - $sharesDebit);
												$actualShares = ($actualShares< 0) ? $val->base_price :  $actualShares;
												$askedPrice = 	(new App\Jobs\PropertyFunctions)->Check_get_average_price($val->id);
												$class = $askedPrice['average_type']  == 'positive' ||  $askedPrice['average_type']  == 'neutral'?  'rit_blu' : 'rit_red';
												$symbol = $askedPrice['average_type']  == 'positive' ||  $askedPrice['average_type']  == 'neutral'?  '+' : '';
											 @endphp
										<h4 class="lft_P">Asked Price: <span>{{number_format($askedPrice['average_price'], 2, '.', ',')}} {{__('text.currency')}}</span></h4>
									<cite class="{{ $class}}">{{$symbol }}{{$askedPrice['display_price']}} (%{{ $askedPrice['percentage']}})</cite>
									</div>
									<h4 class="width100">Shares Available : <span>{{$actualShares}} </span></h4>
									<div class="morInfo_btn">&nbsp;</div>
									<h4>&nbsp;</h4>
									<div class="descrip_t">
											<p>{{$val['description']}}</p>
									</div>
								</div>
							</div>
						</div>			
				@endforeach