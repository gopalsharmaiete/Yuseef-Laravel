						
@foreach($Property as $key=>$val)
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 gridBoxHeight">
							<div class="sellBlock New_grid">
								<div class="Sell_img shop-img">								
									@if(isset($val->file[0]->name) && $val->file[0]->module == 'property')
									<img src=" {{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
									@else
									<img src="{{ asset('images/grid1.png') }}" alt="img">
									@endif
								</div>
								<div class="Sell_txt">
									<div class="innerTitle">
										<div class="lft_sid">
											<h3>{{$val['name']}}</h3>
										</div>
										<div class="rit_sid">
											
										</div>
									</div>
									@php 
										$shares = $val->sharesHistory();
												$sharesDebit = $shares->where('type','debit')->sum('share');
												$sharesCredit = $shares->where('type','credit')->sum('share');	
												$actualShares = $val->base_price - ($sharesCredit - $sharesDebit);
												$actualShares = ($actualShares< 0) ? $val->base_price :  $actualShares;
												$askedPrice = 	(new App\Jobs\PropertyFunctions)->Check_get_average_price($val->id);
												$class = $askedPrice['average_type']  == 'positive' ||  $askedPrice['average_type']  == 'neutral'?  'rit_blu' : 'rit_red';
												$symbol = $askedPrice['average_type']  == 'positive' ||  $askedPrice['average_type']  == 'neutral'?  '+' : '';
									 @endphp
									<div class="priceRit_br">
										<div class="prcTitle">
											<h4 class="lft_P">Asked Price: <span>{{number_format($askedPrice['average_price'], 2, '.', ',')}} {{__('text.currency')}}</span></h4>
										<cite class="{{$class}}">{{$askedPrice['display_price']}} (%{{ $askedPrice['percentage'] }})</cite>
										</div>
									   <h4>Shares Available : <span> {{ $actualShares }}</span></h4>
                                       <div class="descrip_t">
										  <p>{{$val['description']}}</p>
									   </div>
										<div class="morInfo_btn butnBox">
										<a href="{{ URL('shop/secondary-property/'.$val['id'])}}" class="moreB">More Info</a>
										</div>
									</div>

								</div>
							</div>
						</div>										
				@endforeach
