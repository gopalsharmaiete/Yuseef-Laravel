 @extends('layouts.guest-master')
@section('frontcontent')
		<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">Home</a></li>
							<li>{{__('menu.price-guide')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.price-guide')}}</h2>
								<p class="fontP18">{{__('text.price-guide-description')}}</p>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
			
			<div class="container New">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="Price-Guide-block">
							<ul>
							@foreach($forms_serials as $key=>$val)
							@php $name = $val->data->firstWhere('label','=', $val->serial.'_name')['description']; @endphp
							 @if(!empty($name))
									<li>
										<div class="sellBlock">
											<div class="Sell_txt">
												<div class="innerTitle">
													<div class="lft_sid">
														<h3>{{$name}}</h3>
													</div>
												</div>
											</div>
											<div class="Sell_img" style="height:187px !important">
												@if(isset($val->file[0]->name))
												<img src="images/priceguide/{{$val->file[0]->name}}" alt="secndry1">
												@endif
											<h4>{{$val->data->firstWhere('label','=', $val->serial.'_amount')['description']}} Avg Price/Sqm</h4></div>
										</div>
									</li>
								@endif
							@endforeach	
								<!--<li>
									<div class="sellBlock">
										<div class="Sell_txt">
											<div class="innerTitle">
												<div class="lft_sid">
													<h3>New Cairo - Fifth Settlement - Tagamoa</h3>
												</div>
											</div>
										</div>
										<div class="Sell_img"><img src="images/price-guide02.jpg" alt="secndry1"><h4>$946 Avg. area/Sqm</h4></div>
									</div>
								</li>
								<li>
									<div class="sellBlock">
										<div class="Sell_txt">
											<div class="innerTitle">
												<div class="lft_sid">
													<h3>6th October</h3>
												</div>
											</div>
										</div>
										<div class="Sell_img"><img src="images/price-guide03.jpg" alt="secndry1"><h4>$946 Avg. area/Sqm</h4></div>
									</div>
								</li>-->
								
							</ul>
						</div>
						
					</div>
				</div>
			</div>
            
		</section>
@stop
