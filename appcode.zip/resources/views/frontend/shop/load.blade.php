						
@foreach($Property as $key=>$val)
<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 minSlid">
						<div class="sellBlock">
							
							<div class="Sell_img shop-img">
							@if(isset($val->file[0]->name))
							<img src=" {{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}" height="338" width="193">
							@else
							<img src="{{ asset('images/Tsell_1.png') }}" alt="img" height="338" width="193">
							@endif
							</div>
							
							<div class="Sell_txt">
								<div class="innerTitle">
									<div class="lft_sid">
										<h3>{{$val['name']}}</h3>
										<p> {{$val['countryname']->name}}</p>
									</div>
									<div class="rit_sid">
										<span class="clock">{{  \Carbon\Carbon::now()->DiffInDays( \Carbon\Carbon::parse($val['end_date']) ) }} day’s Left</span>
									</div>
								</div>
								<div class="prcTitle">
									<h4 class="lft_P">Asked Price: <span>{{number_format($val['base_price'], 2, '.', ',')}} {{__('text.currency')}}</span></h4>
									
								</div>
								<div class="descrip_t">
									<p>{{$val['description']}}</p>
								</div>
								<div class="rangSlider">
									<cite class="dolrT">{{number_format($val['investment']->sum('amount'), 2, '.', ',')}} {{__('text.currency')}} Raised Of {{number_format($val['base_price'], 2, '.', ',')}} {{__('text.currency')}}</cite>
									<div class="progress">
									<?php
										$percantage= round($val['investment']->sum('amount')*100/$val['base_price']);
										$prnt =  "<div class='progress-bar' role='progressbar' style='width: ".$percantage."%;' aria-valuenow='25' aria-valuemin='0'
										 aria-valuemax='100'><span class='slideRang'>".$percantage."%</span>";
										 echo $prnt;
									?>
										 </div>
									</div>
								</div>
							</div>
							<div class="morInfo_btn">
								@php $url = '/shop/property/'. $val['id']; @endphp
								<a href="{{URL($url)}}" class="moreB">{{__('text.t-m-info')}}</a>
							</div>
						</div>
					</div>							
				@endforeach
