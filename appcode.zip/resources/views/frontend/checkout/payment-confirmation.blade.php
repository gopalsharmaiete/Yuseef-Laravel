 @extends('layouts.guest-master')
@section('frontcontent')
	<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				<img src="{{ asset('images/insdBanner.jpg') }}">
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
							<li>Payment Confirmation</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>Payment Confirmation</h2>
						        <p>Your payment of {{$request->currency_code ?? ''}} {{$request->total ?? ''}} against {{$request->li_0_name ?? ''}} property with oder number {{$request->order_number ?? ''}} is successfully placed.</p>
						        <p>Please contact site admin in case of any inconvenience.</p>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="bodr"></div>
						</div>
					</div>
				</div>            
			
            
		</section>


@stop
