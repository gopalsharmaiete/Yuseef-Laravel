 @extends('layouts.guest-master')
@section('frontcontent')
	<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				<img src="{{ asset('images/insdBanner.jpg') }}">
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
							<li>Wire Transfer</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>Wire Transfer</h2>
								<p>Thank you for your investment. Please download the file below for Wire Transfer Instruction.</p>
						        <div class="detail_table">
		                          <table cellpadding="0" cellspacing="0" border="0" width="100%">
		                            <tbody>
		                              <tr>
		                                <td>Additional Details</td>
		                                <td> 
		                                <a href="http://40.121.65.234:8098/property/public/documents/contracts/1569570280-additional-items-11099.pdf" download>
		                                      <span class="glyphicon glyphicon-download-alt"></span>
		                                    </a>
		                                </td>
		                                
		                              </tr>
		                            </tbody>
		                          </table>
		                        </div>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="bodr my-3"></div>
							<div class="col-lg-6 col-sm-6">
								<ul>
								@foreach($transaction_detail as $key=>$value)
									
										<li><b>Property Name:</b> {{$value->property->name}}</li>
										<li><b>Amount:</b> {{$value->amount}}</li>
										<li><b>Requested Date:</b> {{$value->created_at}}</li>
										@php $transaction_id = $value->txn_id??'';
												$id = $value->id;

										@endphp

								@endforeach
								</ul>
							</div>
							<div class="col-lg-6 col-sm-6 transactionDetails" id="{{$id}}">
								<div class="help-block"></div>
								@if($transaction_id == '')
								<form class="saveref" id="saveref_{{$id}}" name="saveref_{{$id}}" method="post" role="form" action="#">
								  <div class="form-group row has-feedback">
					                    <input type="text" name="refno" class="refno form-control" value="" placeholder="Reference number of wire transfer" required>
					                  </div>
					                  <div class="form-group row has-feedback">
					                    <input type="text" name="remark" class="remark form-control" value="" placeholder="Remark">
					                  </div>
					                  <input type="hidden" name="transaction_id" class="transaction_id" value="{{$id}}">
					                  <div class="box-footer submitbox">
					                   	<button type="submit"  class="savewireref btn btn-primary">Submit</button>
					                   </div>
					                </form>
                  
								@endif
							</div>
						</div>
					</div>
				</div>            
			
            
		</section>


@stop
@section('page_scripts')
<script src="{{ asset('js/transaction.js') }}"></script>
@stop