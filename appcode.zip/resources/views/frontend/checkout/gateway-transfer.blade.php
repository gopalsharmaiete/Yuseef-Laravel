<?php

@session_start();
    define("AUTHENTICATION", "https://www.paytabs.com/apiv2/validate_secret_key");
    define("PAYPAGE_URL", "https://www.paytabs.com/apiv2/create_pay_page");
    define("VERIFY_URL", "https://www.paytabs.com/apiv2/verify_payment");

class paytabs {
	

    private $merchant_email;
    private $secret_key;

     public function __construct($merchant_email, $secret_key) {
        $this->merchant_email = $merchant_email;
        $this->secret_key = $secret_key;
    }
    
    function authentication(){
        $obj = json_decode($this->runPost(AUTHENTICATION, array("merchant_email"=> $this->merchant_email, "secret_key"=>  $this->secret_key)),TRUE);
		
		if($obj->response_code == "4000"){
          return TRUE;
        }
        return FALSE;
		
    }
    
    function create_pay_page($values) {
        $values['merchant_email'] = $this->merchant_email;
        $values['secret_key'] = $this->secret_key;
        $values['ip_customer'] = $_SERVER['REMOTE_ADDR'];
        $values['ip_merchant'] = $_SERVER['SERVER_ADDR'];
        return json_decode($this->runPost(PAYPAGE_URL, $values));
    }
    
    
    
    function verify_payment($payment_reference){
        $values['merchant_email'] = $this->merchant_email;
        $values['secret_key'] = $this->secret_key;
        $values['payment_reference'] = $payment_reference;
        return json_decode($this->runPost(VERIFY_URL, $values));
    }
    
    function runPost($url, $fields) {
        $fields_string = "";
        foreach ($fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        $ip = $_SERVER['REMOTE_ADDR'];

        $ip_address = array(
            "REMOTE_ADDR" => $ip,
            "HTTP_X_FORWARDED_FOR" => $ip
        );
		  curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_HEADER, false);
          curl_setopt($ch, CURLOPT_TIMEOUT, 30);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($ch, CURLOPT_VERBOSE, true);
		/*
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $ip_address);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_REFERER, 1);
*/
        $result = curl_exec($ch);
        curl_close($ch);
        
        return $result;
    }

}

/*
 * Trying to create a pay page
 */



$pt = new paytabs(env("PAYTABMERCHANTEMAIL"), env("PAYTABSECRETKEY"));

$return_url = URL('gateway-return');
    if(isset($GatewayTransaction['return_url']))
    {
        $return_url = $GatewayTransaction['return_url'];
    }

//$result = $pt->authentication();

$result = $pt->create_pay_page(array(
    //Customer's Personal Information
    'merchant_email' => env("PAYTABMERCHANTEMAIL"),
	'secret_key' => env("PAYTABSECRETKEY"),
    'cc_first_name' => "melky",          //This will be prefilled as Credit Card First Name
    'cc_last_name' => "group",            //This will be prefilled as Credit Card Last Name
    'cc_phone_number' => "00973",
    'phone_number' => "33333333",
    'email' => env("PAYTABMERCHANTEMAIL"),
    
    //Customer's Billing Address (All fields are mandatory)
    //When the country is selected as USA or CANADA, the state field should contain a String of 2 characters containing the ISO state code otherwise the payments may be rejected. 
    //For other countries, the state can be a string of up to 32 characters.
    'billing_address' => "melky group",
    'city' => "manama",
    'state' => "manama",
    'postal_code' => "00973",
    'country' => "BHR",
    
    //Customer's Shipping Address (All fields are mandatory)
    'address_shipping' => "melky group",
    'city_shipping' => "manama",
    'state_shipping' => "manama",
    'postal_code_shipping' => "00973",
    'country_shipping' => "BHR",
   
   //Product Information
    "products_per_title" => "Product1",   //Product title of the product. If multiple products then add â€œ||â€ separator
    'quantity' => "1",                                    //Quantity of products. If multiple products then add â€œ||â€ separator
    'unit_price' => $GatewayTransaction['amount'],                                  //Unit price of the product. If multiple products then add â€œ||â€ separator.
    "other_charges" => $GatewayTransaction['commission_amount'],                                     //Additional charges. e.g.: shipping charges, taxes, VAT, etc.
    
    'amount' => $GatewayTransaction['amount']+$GatewayTransaction['commission_amount'],                                          //Amount of the products and other charges, it should be equal to: amount = (sum of all productsâ€™ (unit_price * quantity)) + other_charges
    'discount'=>"0",                                                //Discount of the transaction. The Total amount of the invoice will be= amount - discount
    'currency' => "USD",                                            //Currency of the amount stated. 3 character ISO currency code 
   

    
    //Invoice Information
    'title' => "Melky Group",               // Customer's Name on the invoice
    "msg_lang" => "en",                 //Language of the PayPage to be created. Invalid or blank entries will default to English.(Englsh/Arabic)
    "reference_no" => $GatewayTransaction['order_number'],        //Invoice reference number in your system
   
    
    //Website Information
    "site_url" => env("PAYTABSITEURL"),      //The requesting website be exactly the same as the website/URL associated with your PayTabs Merchant Account
    'return_url' => $return_url,
    "cms_with_version" => "API USING PHP",

    "paypage_info" => "1"
));

echo "FOLLOWING IS THE RESPONSE: <br />";
print_r ($result);

header("Location:".$result->payment_url);
die();
// echo '<script type="text/javascript">
//            window.location = "'.$result->payment_url.'"
//       </script>';
// $_SESSION['paytabs_api_key'] = $result->secret_key;

?>