@extends('layouts.guest-master')
@section('header_scripts')
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
<script src="https://js.braintreegateway.com/web/dropin/1.8.1/js/dropin.min.js"></script>
 @stop
@section('frontcontent')
    

    <!-- Hom_breadcrumb start html -->
    <div class="Hom_breadcrumb">
      <div class="container New">
        <div class="row">
          <div class="col-lg-12">
            <ul class="breadcrumb">
              <li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
              <li>{{__('menu.checkout')}}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- Hom_breadcrumb end html -->

    <section class="listShop_sec">
      <!-- ShopList start html -->
      <div class="ShopList aboutList">
        <div class="container New">
          <div class="row">
            <div class="col-lg-12">
              <div class="Innermelky">
                <h2>{{__('menu.checkout')}}</h2>
              </div>
            </div>
          </div>
        </div>
      </div>  

      <div class="container New">
          <div class="row">  
        <div class="container wow fadeIn">

      <!--Grid row-->
      <div class="row">

        <!--Grid column-->
        <div class="col-md-8 mb-4">
        @if ($errors->any())
               @foreach ($errors->all() as $error)
                     <div class="alert alert-danger">
                         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                              {{ $error }}
                        </div>
               @endforeach
          @endif

          <!--Card-->
          <div class="card">

            <!--Card content-->
            <form class="card-body" name="checkout" method="POST" id="checkout paymentFrm" action="{{url('investment/finalCheckout')}}" >
            {{ csrf_field()}}
              <!--Grid row-->
              <div class="row">

                @guest
                <div class="d-block my-3 col-md-12 mb-2">
                  <div class="custom-control custom-radio">
                    <input id="guest" name="userlogin" type="radio" value="guest" class="custom-control-input" @guest checked @endguest required>
                    <label class="custom-control-label" for="guest">Guest Checkout</label>
                  </div>
                  <div class="custom-control custom-radio">
                    <input id="existinguser" name="userlogin" type="radio" class="custom-control-input" @auth checked @endauth required>
                    <label class="custom-control-label" for="existinguser">Already have an account. Please <a href="#" class="moreB" data-toggle="modal" data-target="#login">signin</a></label>
                  </div>
                </div>
                @endguest

              <hr>
                <!--Grid column-->
                <div class="col-md-6 mb-2">

                  <!--firstName-->
                  <div class="md-form ">
                    <input type="text" id="name" name="name" class="form-control" placeholder="Your Name"" value="{{$user->name??''}}" @auth disabled @endauth required>
                    <label for="firstName" class="">Name</label>
                  </div>

                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-md-6 mb-2">

                  <!--lastName-->
                  <div class="md-form form_email">
                    <input type="text" id="email" name="email" class="form-control" placeholder="youremail@example.com" value="{{$user->email??''}}" @auth disabled @endauth onblur="emailFunction()" required> 
                    <label for="email" class="">Email (optional)</label>
                    <div class="help-block"></div>
                  </div>

                </div>
                <!--Grid column-->

              </div>
              <!--Grid row-->

              
              <!--address-->
              <div class="md-form mb-5">
                <input type="text" id="address" name="address" class="form-control" placeholder="Ex - 1234 Main St" value="{{$user->address??''}}">
                <label for="address" class="">Address</label>
              </div>

              <!--address-2
              <div class="md-form mb-5">
                <input type="text" id="address-2" class="form-control" placeholder="Apartment or suite">
                <label for="address-2" class="">Address 2 (optional)</label>
              </div>-->

              <!--Grid row-->
              <!--<div class="row">

                <div class="col-lg-4 col-md-12 mb-4">

                  <label for="country">Country</label>
                  <select class="custom-select d-block w-100" id="country" required>
                    <option value="">Choose...</option>
                    <option>United States</option>
                  </select>
                  <div class="invalid-feedback">
                    Please select a valid country.
                  </div>

                </div>

                <div class="col-lg-4 col-md-6 mb-4">

                  <label for="state">State</label>
                  <select class="custom-select d-block w-100" id="state" required>
                    <option value="">Choose...</option>
                    <option>California</option>
                  </select>
                  <div class="invalid-feedback">
                    Please provide a valid state.
                  </div>

                </div>
                
                <div class="col-lg-4 col-md-6 mb-4">

                  <label for="zip">Zip</label>
                  <input type="text" class="form-control" id="zip" placeholder="" required>
                  <div class="invalid-feedback">
                    Zip code required.
                  </div>

                </div>
                

              </div>-->
              <!--Grid row-->

             <hr>

             <div class="row">
                
                <!--   <div class="col-md-12 mb-3 paypal" id="paypal-button-container"></div>

                
             <script>paypal_sdk.Buttons().render('#paypal-button-container');</script>-->
              
                <!--<div class="col-md-6 mb-3">
                  <label for="cc-name">Name on card</label>
                  <input type="text" class="form-control" id="cc-name" placeholder="" required>
                  <small class="text-muted">Full name as displayed on card</small>
                  
                </div>
                <div class="col-md-6 mb-3">
                  <label for="cc-number">Credit card number</label>
                  <input type="text" class="form-control" id="card_num" placeholder="" required>
                  
                </div>
              </div>
              <div class="row">
                <div class="col-md-5 mb-5">
                  <div class="col-md-12">
                  <label for="cc-expiration">Expiration</label>
                </div>
                  <div class="col-md-6 mb-6">
                  <input type="number" name="exp_month" class="form-control" id="exp_month" placeholder="MM" required>
                </div>
                  <div class="col-md-6 mb-6">
                  <input type="number" name="exp_year" class="form-control" id="exp_year" placeholder="YY" required>
                </div>
                  
                </div>
                <div class="col-md-3 mb-3">
                  <label for="cc-expiration">CVV</label>
                  <input type="number" class="form-control" id="cvv" placeholder="" required>
                  
                </div>-->
              </div>
              

              
             <!-- <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="save-info">
                <label class="custom-control-label" for="save-info">Save this information for next time</label>
              </div>-->
              
              <input type="hidden" id="islogin" name="islogin" value="@auth{{'Y'}}@endauth">
              <input type="hidden"  id="amount" name="amount" value="{{$amount}}">
              <input type="hidden"  id="property_id" name="property_id" value="{{$property_id}}">
              <input type="hidden"  id="property_name" name="property_name" value="{{$property_name}}">
              <input type="hidden"  id="user_id" name="user_id" value="{{$user->id??''}}">
              <input type="hidden"  id="currency" name="currency" value="USD">
              <input type="hidden"  id="commission_percentage" name="commission_percentage" value="{{$commission_percent['1']}}">
               <input type="hidden"  id="commission_amount" name="commission_amount" value="{{$commission}}">
               <input type="hidden"  id="total" name="total" value="{{$amount+$commission}}">

              <input id="token" name="token" type="hidden" value="">
              @if($amount != '')
              <div class="box-footer" @guest style="display:none;" @endguest>
                <div class="d-block my-3 col-md-12 mb-2">
                    <!--<div class="custom-control custom-radio">
                      <input id="cardtransfer" name="transfer" type="radio" value="onlinetransfer" class="custom-control-input" checked required>
                      <label class="custom-control-label" for="transfer">Card Payment</label>
                    </div>-->
                    <div class="custom-control custom-radio">
                      <input id="cardtransfer" name="transfer" type="radio" value="paytabs" class="custom-control-input" checked required>
                      <label class="custom-control-label" for="transfer">Card Payment</label>
                    </div>
                    <div class="custom-control custom-radio">
                      <input id="wiretransfer" name="transfer" type="radio" value="wiretransfer" class="custom-control-input" required>
                      <label class="custom-control-label" for="transfer">Wire Transfer</label>
                    </div>
                </div>
                <button  id="checkoutpayment" type="submit" class="btn btn-primary">Proceed</button>
              </div>
              @endif
            </form>
          
            @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
          <!--/.Card-->

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-4 mb-4">

          <!-- Heading -->
          <h3 class="d-flex justify-content-between align-items-center mb-3">
            <span class="text-muted">Your cart</span>
            <span class="badge badge-secondary badge-pill">1</span>
          </h3>

          <!-- Cart -->
          <ul class="list-group mb-3 z-depth-1 cartdetail">
            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h4 class="my-0">Property name</h4>
                <p class="text-muted">{{$property_name}}</p>
              </div>
              <span class="text-muted">EGP{{$amount}}</span>
            </li>

            <li class="list-group-item d-flex justify-content-between lh-condensed">
              <div>
                <h4 class="my-0">Commission</h4>
                <p class="text-muted">({{$commission_percent['1']}})%</p>
              </div>
              <span class="text-muted">{{$commission}}</span>
            </li>            
            <!--<li class="list-group-item d-flex justify-content-between bg-light">
              <div class="text-success">
                <h6 class="my-0">Promo code</h6>
                <small>EXAMPLECODE</small>
              </div>
              <span class="text-success">-$5</span>
            </li>-->
            <li class="list-group-item d-flex justify-content-between">
              <span>Total (EGP)</span>
              <strong>{{$amount+$commission}}</strong>
            </li>
          </ul>
          <!-- Cart -->

          <!-- Promo code 
          <form class="card p-2">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Promo code" aria-label="Recipient's username" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-secondary btn-md waves-effect m-0" type="button">Redeem</button>
              </div>
            </div>
          </form>-->
          <!-- Promo code -->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->

    </div>
              </div>
            </div>
    </section>
     <!-- Modal for login -->
      <div class="modal fade" id="login" role="dialog">
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">{{ trans('adminlte::adminlte.login_message') }}</h4>
            </div>
            <div class="modal-body checkoutlogin">
             
                <div class="helpblock"></div>
              
              <form action="#" method="post">
                {!! csrf_field() !!}
              
                <div class="input_row form-group has-feedback {{ $errors->has('email') ? 'has-error' : '' }}">
                  <input type="email" name="popupemail" id="popupemail" class="fld_col" value="{{ old('email') }}"
                       placeholder="{{ trans('adminlte::adminlte.email') }}">
                  
                  @if ($errors->has('email'))
                    <span class="help-block">
                      <strong>{{ $errors->first('email') }}</strong>
                    </span>
                  @endif
                </div>
                <div class="input_row form-group has-feedback {{ $errors->has('password') ? 'has-error' : '' }}">
                  <input type="password" name="password" id="password" class="fld_col"
                       placeholder="{{ trans('adminlte::adminlte.password') }}">
                  
                  @if ($errors->has('password'))
                    <span class="help-block">
                      <strong>{{ $errors->first('password') }}</strong>
                    </span>
                  @endif
                </div>
                <div class="input_row form-group">
                  <div class="checkbox icheck">
                    <label>
                      <input type="checkbox" name="remember"> {{ trans('adminlte::adminlte.remember_me') }}
                    </label>
                  </div>
                </div>
                
                <div class="morInfo_btn submitbtn">
                <input type="submit" class="moreB" id="userlogin" value="{{ trans('adminlte::adminlte.sign_in') }}">
                
                </div>
              </form>
              

            
            </div>
            
          </div>
          
        </div>
      </div>
@stop
@section('page_scripts')
<script src="{{ asset('js/checkout.js') }}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/css/bootstrapValidator.min.css">
<script>

$('#card_num').keyup(function(event) { 
  $('#checkout').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            card_num: {
                validators: {
                    creditCard: {
                        message: 'The credit card number is not valid'
                    }
                }
            }
        }
    });
});
</script>
@stop