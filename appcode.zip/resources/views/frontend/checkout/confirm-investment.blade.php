@extends('layouts.guest-master')
@section('frontcontent')


    <!-- Hom_breadcrumb start html -->
    <div class="Hom_breadcrumb">
      <div class="container New">
        <div class="row">
          <div class="col-lg-12">
            <ul class="breadcrumb">
              <li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
              <li>{{__('menu.confirminvest')}}</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- Hom_breadcrumb end html -->

    <section class="listShop_sec">
      <!-- ShopList start html -->
      <div class="ShopList aboutList">
        <div class="container New">
          <div class="row">
            <div class="col-lg-12">
              <div class="Innermelky">
                <h2>{{__('menu.confirminvest')}}</h2>
              </div>
            </div>
          </div>
        </div>
      </div>  

      <div class="container New">
          <div class="row">  
        <!-- form start -->
            <form name="confirmInvestment" id="confirmInvestment" method="post" role="form" action="{{url('/investment/checkout')}}" enctype="multipart/form-data" class="form">               
            {{ csrf_field()}}
              <input type="hidden" name="amount" value="{{$investAmt}}">
              <input type="hidden" name="property_id" value="{{$propertyID}}">
              <input type="hidden" name="propertyName" value="{{$propertyName}}">
              <div class="box-body"><!-- /.box-body --> 
             @php $x = 1; @endphp
              @foreach($forms_serials as $val)
                @php $data = $val->data->firstWhere('label', '=', $val->serial.'_name')['description']; @endphp
                  @if(!empty($data))
                      <div class="form-group has-feedback {{ $errors->has($val['confirmInvest']) ? 'has-error' : '' }}">
                        <input type="checkbox" id="confirmInvest{{$x}}" class="terms" name="confirmInvest[]">
                        <label for="confirmInvest{{$x}}">{{$data}}</label>    
                        
                      </div>  
                   @endif    
              @php $x++; @endphp
            @endforeach
              </div><!-- /.box-body --> 
              <div class="box-footer">
                <button type="submit" class="btn btn-primary cnfrm_invest" >Submit</button>
              </div>
            </form>
            @if ($message = Session::get('success'))

                <div>
                    <p>{{ $message }}</p>
                </div>

                @endif

                @if ($message = Session::get('error'))

                <div class="alert alert-error badge-danger-lighten">

                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                <p>{{ $message }}</p></div>

                @endif
              </div>
            </div>
    </section>
@stop

@section('page_scripts')
<script>


$(document).ready(function(){
$('.cnfrm_invest').on('click', function(e) {
e.preventDefault();
var x = 0;
$('input[type="checkbox"].terms').each(function(){
  
    var a = $("input[type='checkbox'].terms");
    if(a.length == a.filter(":checked").length){
        return true
        x =0;
    } else{
      x = 1;
    }
    
});
if(x==1){
      alert('Please select all the terms.');
} else{
  $(".form").submit();
}

});
});
</script>
@stop