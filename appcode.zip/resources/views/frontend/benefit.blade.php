 @extends('layouts.guest-master')
@section('frontcontent')
		<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
			    @php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
							<li>{{__('menu.benefit')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.benefit')}}</h2>
								<p class="fontP18">{!! __('text.benefit_main_content') !!}</p>
							</div>
						</div>
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="Benefits-block">
									<ul>
										@php $i = 0; @endphp
										@foreach($imagesData as $key=>$val)
										@php  
											$imagetext = 'text.'.$val['title'];  @endphp
										<li>
											<div class="img-block">
												<img src="{{url('/')}}/images/pages/{{$val['name']}}" alt="" title="" class="t_img" >
											</div>
											<div class="textim_cont">{!! __($imagetext)!!}</span></div>
										</li>
										@php $i++; @endphp
										@endforeach
									</ul>
								</div>
								
								<div class="Benefits-block-lists">
									<ul class="videoText">
										{!! __('text.benefit_points') !!}
									</ul>
								</div>
								
							</div>
					</div>
					
				</div>
			</div>		
			<!-- ShopList end html -->
			
			
            
		</section>
@stop
