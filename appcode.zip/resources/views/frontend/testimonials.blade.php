 @extends('layouts.guest-master')
@section('frontcontent')
		<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">Home</a></li>
							<li>{{__('menu.testimonial')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.testimonial')}}</h2>
						        <p>{{__('text.testimonial_desc')}}</p>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
			
			<div class="container New">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="testimonials-block">
							<ul>
							@foreach($forms_serials as $key=>$val)
							  @if(isset($val->file[0]->name) && !empty($val->file[0]->name))
								<li>
								  <img src="images/testimonial/{{$val->file[0]->name}}" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>{!! $val->data->firstWhere('label', '=', $val->serial.'_details')['description'] !!}</p>
										<p class="t_name"><b>{{$val->data->firstWhere('label', '=', $val->serial.'_name')['description']}}</b></p>
										<p class="t_desination">Desination, <span>{{$val->data->firstWhere('label', '=', $val->serial.'_designation')['description']}}</span></p>
									</div>
								</li>
								@endif
							@endforeach
								<!--<li>
									<img src="images/testimonials-img01.jpg" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p class="t_name"><b>Robble White</b></p>
										<p class="t_desination">Desination, <span>Lorem ipsum</span></p>
									</div>
								</li>
								<li>
									<img src="images/testimonials-img02.jpg" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p class="t_name"><b>Riley Jones</b></p>
										<p class="t_desination">Desination, <span>Lorem ipsum</span></p>
									</div>
								</li>
								<li>
									<img src="images/testimonials-img03.jpg" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p class="t_name"><b>Payton Hillman</b></p>
										<p class="t_desination">Desination, <span>Lorem ipsum</span></p>
									</div>
								</li>
								<li>
									<img src="images/testimonials-img01.jpg" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p class="t_name"><b>Robble White</b></p>
										<p class="t_desination">Desination, <span>Lorem ipsum</span></p>
									</div>
								</li>
								<li>
									<img src="images/testimonials-img02.jpg" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p class="t_name"><b>Riley Jones</b></p>
										<p class="t_desination">Desination, <span>Lorem ipsum</span></p>
									</div>
								</li>
								<li>
									<img src="images/testimonials-img03.jpg" alt="" title="" class="t_img" >
									<div class="textim_cont">
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p class="t_name"><b>Payton Hillman</b></p>
										<p class="t_desination">Desination, <span>Lorem ipsum</span></p>
									</div>
								</li>-->
							</ul>
						</div>
					</div>
				</div>
			</div>
            
		</section>

@stop
