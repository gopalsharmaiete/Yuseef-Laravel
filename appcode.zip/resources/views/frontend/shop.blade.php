 @extends('layouts.guest-master')
@section('frontcontent')
			<!-- inside banner -->
			<section class="insideBanner">
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
			</section>
			<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">{{__('menu.home')}}</a></li>
							<li>{{__('menu.shop')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->
		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.shop')}}</h2>
								<p>{!!  html_entity_decode(__('text.shop-description')) !!}</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- ShopList end html -->

			<!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<form name="searchProperty" id="searchProperty" action="#" method="GET">
								<div class="alignBox">
								<!--	<div class="variation2">
										<select name="offering_type" id="offering_type" class="select filterform">
											<option value="">Select Category</option>
											
											@foreach($Category as $key=>$val)
											@if(isset($_GET['offering_type']) && $_GET['offering_type'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option  value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div>

									<div class="variation2">
										<select name="funded_status" id="funded_status" class="select filterform">
											<option value="">Select Status</option>
											@foreach($Status as $key=>$val)
											@if(isset($_GET['funded_status']) && $_GET['funded_status'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div>

									<div class="variation2">
										<select name="country" id="country" class="select filterform">
											<option value="">Select Country</option>
											@foreach($country as $key=>$val)
											@if(isset($_GET['country']) && $_GET['country'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div> -->	

								</div>

								<div class="srchBox">
									<input type="text" class="fld" id="searchtext" name="s" @if(isset($_GET['s'])) value="{{$_GET['s']}}" @endif placeholder="Search">
									<input type="submit" class="srch" value="">
								</div>
							</form>
							</div>
						</div>
					</div>

					<div class="row" id="grid">

					
@foreach($Property as $key=>$val)
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 minSlid">
						<div class="sellBlock">
							
							<div class="Sell_img shop-img">
							@if(isset($val->file[0]->name) && $val->file[0]->module == 'property')
							<img src=" {{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}" height="338" width="193">
							@else
							<img src="{{ asset('images/Tsell_1.png') }}" alt="img" height="338" width="193">
							@endif
							</div>
							
							<div class="Sell_txt">
								<div class="innerTitle">
									<div class="lft_sid">
										<h3>{{$val['name']}}</h3>
										<p> {{$val['countryname']->name??''}}</p>
									</div>
									<div class="rit_sid">
										<span class="clock">{{  \Carbon\Carbon::now()->DiffInDays( \Carbon\Carbon::parse($val['end_date']) ) }} day’s Left</span>
									</div>
								</div>
								<div class="prcTitle">
									<h4 class="lft_P">Asked Price: <span>{{number_format($val['base_price'], 2, '.', ',')}} {{__('text.currency')}}</span></h4>
									
								</div>
								<div class="descrip_t">
									<p>{{$val['description']}}</p>
								</div>
								<div class="rangSlider">
									<cite class="dolrT">{{number_format($val['investment']->sum('amount'), 2, '.', ',')}} {{__('text.currency')}} Raised Of {{number_format($val['base_price'], 2, '.', ',')}} {{__('text.currency')}}</cite>
									<div class="progress">
									<?php
										$percantage= round($val['investment']->sum('amount')*100/$val['base_price']);
										$prnt =  "<div class='progress-bar' role='progressbar' style='width: ".$percantage."%;' aria-valuenow='25' aria-valuemin='0'
										 aria-valuemax='100'><span class='slideRang'>".$percantage."%</span>";
										 echo $prnt;
									?>
										 </div>
									</div>
								</div>
							</div>
							<div class="morInfo_btn">
								@php $url = '/shop/property/'. $val['id']; @endphp
								<a href="{{URL($url)}}" class="moreB">{{__('text.t-m-info')}}</a>
							</div>
						</div>
					</div>				
				@endforeach
					</div>

					<div class="ajax-load text-center" style="display:none">
						<p><img src="{{asset('images/loader.gif')}}"></p>
					</div>

					<div class="morInfo_btn seProj">
						<a href="" class="moreB" id="load">load More</a>
					</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->

		</section>


@stop
@section('page_scripts')
 <script src="{{ asset('js/shop.js') }}"></script>
@stop