@extends('layouts.guest-master')
@section('frontcontent')
			<!-- inside banner -->
			<section class="insideBanner">
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
			</section>
			<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">{{__('menu.home')}}</a></li>
							<li>{{__('menu.secondary_market')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->
		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.secondary_market')}}</h2>
								<p>{!! html_entity_decode(__('text.home-purpose-bullet-2')) !!}</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- ShopList end html -->

			<!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">

				<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky gridOptn">
								
								<ul>
									@php 
									  $listActive = '';
									  $gridActive = 'active';
									  if(app('request')->input('design') == 'list') {
										  $listActive = 'active';
									      $gridActive = '';
									  }
									@endphp
									<li class="gridIcon {{ $gridActive }}"><a href="{{ Request::url().'?design=grid' }}"></a></li>
									<li class="listIcon  {{ $listActive }}"><a href="{{ Request::url().'?design=list' }}"></a></li>
								</ul>
								
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<form name="searchProperty" id="searchProperty" action="#" method="GET">
								<div class="alignBox">
										<div class="variation2">
												<a href="#" class="btn btn-default">Secondary Market</a>
										</div>
										<div class="variation2">
											 <a href="{{ URL('/secondary-marketing-offers')}}" class="btn btn-success">Secondary Market Offers</a>
										</div>
									<!--<div class="variation2">
									@if(!empty(app('request')->input('design')))
									   <input type="hidden" name="design" id="design"  value="{{ app('request')->input('design') }}" />
									@else
									<input type="hidden" name="design"  id="design" value="grid" />
									@endif
										<select name="offering_type" id="offering_type" class="select filterform">
											<option value="">Select Category</option>
											
											@foreach($Category as $key=>$val)
											@if(isset($_GET['offering_type']) && $_GET['offering_type'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option  value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div>

									<div class="variation2">
										<select name="funded_status" id="funded_status" class="select filterform">
											<option value="">Select Status</option>
											@foreach($Status as $key=>$val)
											@if(isset($_GET['funded_status']) && $_GET['funded_status'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div>

									<div class="variation2">
										<select name="country" id="country" class="select filterform">
											<option value="">Select Country</option>
											@foreach($country as $key=>$val)
											@if(isset($_GET['country']) && $_GET['country'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div>	-->

								</div>

								<div class="srchBox">
									<input type="text" class="fld" id="searchtext" name="s" @if(isset($_GET['s'])) value="{{$_GET['s']}}" @endif placeholder="Search">
									<input type="submit" class="srch" value="">
								</div>
							</form>
							</div>
						</div>
					</div>

					<div class="row" id="grid">
					
			@foreach($Property as $key=>$val)
				             
			       <div class="col-lg-12">
							<div class="secondary_market">
								<div class="sellBlock">
									<div class="Sell_img shop-img">	
                                        @if(isset($val->file[0]->name) && $val->file[0]->module == 'property')
                                            <img src=" {{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
                                        @else
                                            <img src="{{ asset('images/grid1.png') }}" alt="img">
                                        @endif
                                    </div>
									<div class="Sell_txt">
										<div class="innerTitle">
											<div class="lft_sid">
												<h3>{{$val['name']}}</h3>
											</div>
											<div class="rit_sid">
												
											</div>
										</div>
									</div>
									<div class="morInfo_btn mymorInfo_btn">
									@php $url = '/shop/secondary-property/'. $val['id']; @endphp
										<a href="{{URL($url)}}" class="moreB">{{__('text.t-m-info')}}</a>
									</div>
								</div>
								<div class="priceRit_br">
									<div class="prcTitle">
											@php 
												$shares = $val->sharesHistory();
												$sharesDebit = $shares->where('type','debit')->sum('share');
												$sharesCredit = $shares->where('type','credit')->sum('share');	
												$actualShares = $val->base_price - ($sharesCredit - $sharesDebit);
												$actualShares = ($actualShares< 0) ? $val->base_price :  $actualShares;
												$askedPrice = 	(new App\Jobs\PropertyFunctions)->Check_get_average_price($val->id);
												$class = $askedPrice['average_type']  == 'positive' ||  $askedPrice['average_type']  == 'neutral'?  'rit_blu' : 'rit_red';
												$symbol = $askedPrice['average_type']  == 'positive' ||  $askedPrice['average_type']  == 'neutral'?  '+' : '-';	
										   @endphp
		                               <h4 class="lft_P">Asked Price: <span>{{number_format($askedPrice['average_price'], 2, '.', ',')}} {{__('text.currency')}}</span></h4>
									<cite class="{{$class}}">{{$symbol }}{{$askedPrice['average_price']-1}} (%{{($askedPrice['percentage'])}})</cite>
									</div>
									<h4 class="width100">Shares Available : <span>{{$actualShares }} </span></h4>
									<div class="morInfo_btn">&nbsp;</div>
									<h4>&nbsp;</h4>
									<div class="descrip_t">
											<p>{{$val['description']}}</p>
									</div>
								</div>
							</div>
						</div>			
				@endforeach
					</div>

					<div class="ajax-load text-center" style="display:none">
						<p><img src="{{asset('images/loader.gif')}}"></p>
					</div>
              
					<div class="morInfo_btn  seProj">
					  @if(is_countable($Property) && count($Property) > 0)
						<a href="#" class="moreB" id="load-offer">load More</a>
					  @else
					    <h3>No Property found</h3>
					  @endif
					</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->

		</section>


@stop
@section('page_scripts')
<script src="{{ asset('js/secondary-market.js') }}"></script>
@stop