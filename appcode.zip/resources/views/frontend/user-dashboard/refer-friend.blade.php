@extends('layouts.user-dashboard-master')
@section('frontcontent')
<section class="listShop_sec dashboardSec">
<div class="productSec">   
      <div class="ShopList">
        <div class="container New">
          <div class="row">
            <div class="col-lg-12">
              <div class="Innermelky">
                <h2>Refer a Friend Form</h2>
                <p>Melky Group is an opportunity for growth. You earn property ownership with help of each other In summary. there's no reason for Egyptians to not being able to own properly.</p>
              </div>
            </div>
          </div>
        </div>
      </div> 
<div class="container New">
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">&nbsp;</h3>
                  @if (Session::has('message'))
                     <div class="alert alert-info">{{ Session::get('message') }}</div>
                  @endif
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="referfriend" method="post" role="form" action="#" enctype="multipart/form-data">               
                {{ csrf_field()}}
									
                  <div class="box-body">
                        
                  <div class="form-group row has-feedback {{ $errors->has('rname') ? 'has-error' : '' }}">
                    <label for="rname" class="col-sm-2 col-form-label">{{ __('form-label.referrer-name') }}</label>
                    <div class="col-sm-10">
                    <input type="text" name="rname" class="form-control" value="{{ $user->name }}"
                           placeholder="{{ __('form-label.referrer-name') }}" required>
                    </div>
                    @if ($errors->has('name'))
                        <span class="help-block">
                            <strong>{{ $errors->first('rname') }}</strong>
                        </span>
                    @endif
                </div>
                 <div class="form-group row has-feedback {{ $errors->has('rcompany') ? 'has-error' : '' }}">
                    <label for="rcompany" class="col-sm-2 col-form-label">{{ __('form-label.referrer-company') }}</label>
                    <div class="col-sm-10">
                    <input type="text" name="rcompany" class="form-control" value=""
                           placeholder="{{ __('form-label.referrer-company') }}" >
                    </div>
                    @if ($errors->has('name'))
                        <span class="help-block">
                            <strong>{{ $errors->first('rcompany') }}</strong>
                        </span>
                    @endif
                </div>
                
                <div class="form-group row has-feedback {{ $errors->has('remail') ? 'has-error' : '' }}">
                  <label for="remail" class="col-sm-2 col-form-label">{{ __('form-label.referrer-email') }}</label>
                  <div class="col-sm-10">
                    <input type="text" name="remail" class="form-control" value="{{$user->email}}"
                           placeholder="{{ __('form-label.referrer-email') }}" required>
                  </div>
                    @if ($errors->has('remail'))
                        <span class="help-block">
                            <strong>{{ $errors->first('remail') }}</strong>
                        </span>
                    @endif
                </div> 
                <hr>
                <h4>{{ __('form-label.referrer-your-friend-info') }}</h4>
                <br><br>
                <div class="form-group row has-feedback {{ $errors->has('rfname') ? 'has-error' : '' }}">
                   <label for="rfname" class="col-sm-2 col-form-label">{{ __('form-label.referrer-friend-fname') }}</label>
                   <div class="col-sm-10">
                    <input type="text" name="rfname" class="form-control" value="{{ old('rfname') }}"
                           placeholder="{{ __('form-label.referrer-friend-fname') }}" required|email>
                   </div>
                    @if ($errors->has('rfname'))
                        <span class="help-block">
                            <strong>{{ $errors->first('rfname') }}</strong>
                        </span>
                    @endif
                </div>       

                <div class="form-group row has-feedback {{ $errors->has('rflname') ? 'has-error' : '' }}">
                  <label for="rflname" class="col-sm-2 col-form-label">{{ __('form-label.referrer-friend-lname') }}</label>
                  <div class="col-sm-10">
                    <input type="text" name="rflname" class="form-control"
                           placeholder="{{ __('form-label.referrer-friend-fname') }}" required>
                  </div>
                    @if ($errors->has('rflname'))
                        <span class="help-block">
                            <strong>{{ $errors->first('rflname') }}</strong>
                        </span>
                    @endif
                </div>  

                
                <div class="form-group row has-feedback {{ $errors->has('rfcompany') ? 'has-error' : '' }}">
                  <label for="rfcompany" class="col-sm-2 col-form-label">{{ __('form-label.referrer-friend-company') }}</label>
                  <div class="col-sm-10">
                    <input type="text" name="rfcompany" class="form-control"
                           placeholder="{{ __('form-label.referrer-friend-company') }}" required>
                  </div>
                    @if ($errors->has('rfcompany'))
                        <span class="help-block">
                            <strong>{{ $errors->first('rfcompany') }}</strong>
                        </span>
                    @endif
                </div> 
                <div class="form-group row has-feedback {{ $errors->has('rfemail') ? 'has-error' : '' }}">
                  <label for="rfemail" class="col-sm-2 col-form-label">{{ __('form-label.referrer-friend-email') }}</label>
                  <div class="col-sm-10">
                    <input type="text" name="rfemail" class="form-control"
                           placeholder="{{ __('form-label.referrer-friend-email') }}" required>
                  </div>
                    @if ($errors->has('rfemail'))
                        <span class="help-block">
                            <strong>{{ $errors->first('rfemail') }}</strong>
                        </span>
                    @endif
                </div>
                  </div><!-- /.box-body -->
                  
                  <input type="hidden" class="custom-file-input" name="status" id="status" value="1">
                  <div class="box-footer submitbox">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p class="success-msz">{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
  </div>
</div>
</section>
@stop

@section('page_scripts')




@stop