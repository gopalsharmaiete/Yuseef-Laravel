@extends('layouts.user-dashboard-master')
@section('frontcontent')
<section class="listShop_sec dashboardSec">
<div class="productSec">   
      <div class="ShopList">
        <div class="container New">
          <div class="row">
            <div class="col-lg-12">
              <div class="Innermelky">
                <h2>Notification</h2>
                
              </div>
            </div>
          </div>
        </div>
      </div> 
<div class="container New">
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">&nbsp;</h3>
                 
                </div><!-- /.box-header -->
                <div class="col-md-12">
                @foreach (Auth::user()->notifications as $notification)  
                     @if($notification->type == 'App\Notifications\NewMessage')        						   			
                        <div class="panel panel-default">
                           <div class="panel-body"><div style="float:left"><span class="notificationBell">&nbsp;</span></div><div style="float:left;margin-left:10px"><a  href="{{ isset($notification->data['URL']) ? $notification->data['URL']: '#' }}">You have received an offer from {{$notification->data['ByUserName']}} For {{$notification->data['shares']}} Shares Of {{$notification->data['property_name']}} </a></div> </div>
                        </div>
                        @elseif($notification->type == 'App\Notifications\ApproveShares')
                          <div class="panel panel-default">
                            <div class="panel-body"><div style="float:left"><span class="notificationBell">&nbsp;</span></div><div style="float:left;margin-left:10px"><a  href="{{ isset($notification->data['URL']) ? $notification->data['URL']: '#' }}">Your Purchase Request Has Been Accepted By
                            {{$notification->data['ByUserName']}} For {{$notification->data['property_name']}}  </a></div> </div>
                            </div>
                        @elseif($notification->type == 'App\Notifications\BidsShares')
											      <li><a href="{{ isset($notification->data['URL']) ? $notification->data['URL'] : '#' }}"><img src="{{ asset('images/Real_Estate_Edu_ico01.png') }}"> <span>Your You Received An Counter Bid From
											        {{$notification->data['ByUserName']}} For {{$notification->data['property_name']}}  </span></a></li>																						
                        @endif
                @endforeach
                </div>
             </div>
       </div>
    </section>
  </div>
</div>
</section>
@stop

@section('page_scripts')




@stop