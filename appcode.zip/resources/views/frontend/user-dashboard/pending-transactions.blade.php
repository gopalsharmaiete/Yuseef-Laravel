@extends('layouts.user-dashboard-master')
@section('frontcontent')
<section class="listShop_sec dashboardSec">
<div class="productSec">   
      <div class="ShopList">
        <div class="container New">
          <div class="row">
            <div class="col-lg-12">
              <div class="Innermelky">
                <h2>Pending Transactions</h2>
                <p>Please submit the transaction id of relative property transaction form.</p>
              </div>
            </div>
          </div>
        </div>
      </div> 
<div class="container New">
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              
            @if(!empty($transaction_detail))
             @foreach($transaction_detail as $key=>$value)
             <div class="row">
              <div class="bodr my-3"></div>
              <div class="col-lg-6 col-sm-6">
                <ul>
                
                  
                    <li><b>Property Name:</b> {{$value->property->name}}</li>
                    <li><b>Amount:</b> {{$value->amount}}</li>
                    <li><b>Requested Date:</b> {{$value->created_at}}</li>
                    @php $transaction_id = $value->txn_id??'';
                    $id = $value->id; @endphp
                
                </ul>
              </div>
              <div class="col-lg-6 col-sm-6 transactionDetails" id="{{$id}}">
                <div class="help-block"></div>

                <form class="saveref" id="saveref_{{$id}}" name="saveref_{{$id}}" method="post" role="form" action="#">
                  <div class="form-group">
                    <input type="text" name="refno" id="refno" class="refno form-control" value="" placeholder="Reference number of wire transfer" required>
                  </div>
                  <div class="form-group">
                    <input type="text" name="remark" class="remark form-control" value="" placeholder="Remark">
                  </div>
                  <input type="hidden" name="transaction_id" class="transaction_id" value="{{$id}}">
                  <div class="box-footer submitbox">
                              <button type="submit"  class="savewireref btn btn-primary">Submit</button>
                          </div>
                </form>
                
              
            </div>
          </div>
            @endforeach
            @else
            <h4>There is no pending transaction avaliable.</h4>
            @endif
       </div>
    </section>
  </div> 
</div>
</section>



@stop

@section('page_scripts')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="{{ asset('js/transaction.js') }}"></script>
@stop