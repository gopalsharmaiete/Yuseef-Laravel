@extends('layouts.user-dashboard-master')
@section('frontcontent')

<section class="listShop_sec dashboardSec">
		
 <!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">

					
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
							
							</div>
						</div>
					</div>

					<div class="row">
						
					@if(!empty($Property))
					    @foreach($Property as $key=>$val)
                             <div class="col-lg-12">
                                    <div class="secondary_market">
                                            @php 
                                                $sharesDebit = $val->sharesHistory->where('type','debit')->where('user_id',Auth::id())->sum('share');
                                                $sharesCredit = $val->sharesHistory->where('type','credit')->where('user_id',Auth::id())->sum('share');
                                                $actualShares = $sharesCredit-$sharesDebit;
                                                $sharesUnitPrice =  (new App\Jobs\PropertyFunctions)->Check_get_average_price($val->id);
                                           @endphp
                                        <div class="sellBlock">
										<div class="Sell_img dashimg dashboard-img">									
									@if(isset($val->file[0]->name))
									<img src="{{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
									@else
									<img src="images/dashBord_img.png" alt="dashBord_img">
									@endif
									</div>
                                            <div class="Sell_txt">
                                                  <div class="innerTitle">
                                                      <div class="lft_sid">
                                                          <h3>{{$val->name}}</h3>
                                                       </div>
                                                    </div>
                                                    <div class="morInfo_btn">
                                                        <a href="{{URL('/shop/property/')}}/{{$val->id}}" class="moreB">{{__('text.t-m-info')}}</a>
                                                    </div>
                                                </div>
                                         </div>

                                        <div class="numbrText">
                                            <h4>Number Of Shares</h4>
                                            <p>{{ $actualShares }} </p>
                                           
                                        </div>
                                        <div class="numbrText">
                                                <h4>Current Value</h4>
                                              <p>{{  $actualShares * $sharesUnitPrice['average_price'] }} EGP</p>
                                            </div>
            
                                            <div class="numbrText">
                                                <h4>Previous Value</h4>
                                                <p>
                                                {{1* $actualShares}} EGP
                                                </p>
                                          </div>
                                          <div class="numbrText">
                                                <h4>Dated</h4>
                                                <p> {{ date('Y-m-d',strtotime($val->created_at))}}</p>
                                          </div>
                                      </div>
                                </div>
                                <div class="content sellequityWrapper">
									<div class="col-md-4">	
									</div>
									<div class="col-md-8">
										<h4>Transfers</h4>
									</div>
									@foreach($val->secondaryInvestmentBidsOfferTransfer(Auth::user()->id)->get() as $trans)	
										<div class="content sellequityBlocks">
											<div class="col-lg-4">
												&nbsp;
											</div>
											<div class="col-lg-8 sellequity ">
												<div class="content">	
													<div class="col-md-3">
														<p> <strong>Shares:</strong> {{ $trans->shares }} </p>
                                                    </div>
                                                    <div class="col-md-3">
														<p> <strong>Unit Price:</strong> {{ $trans->unit_price }} </p>
													</div>
                                                    <div class="col-md-3">
														<p> <strong>Amount:</strong> {{ $trans->shares*$trans->unit_price }} </p>
													</div>
													<div class="col-md-3">
															<p> <strong>Date:</strong> {{ date('Y-m-d',strtotime($trans->created_at)) }} </p>
													</div>
													
													
												</div>
												
											</div>
										</div>
                                    @endforeach
                                    @foreach($val->secondaryInvestmentRequestTransfer(Auth::user()->id)->get() as $trans)	
										<div class="content sellequityBlocks">
											<div class="col-lg-4">
												&nbsp;
											</div>
											<div class="col-lg-8 sellequity ">
												<div class="content">	
													<div class="col-md-3">
														<p> <strong>Shares:</strong> {{ $trans->shares }} </p>
                                                    </div>
                                                    <div class="col-md-3">
														<p> <strong>Amount:</strong> {{ $trans->unit_price }} </p>
													</div>
                                                    <div class="col-md-3">
														<p> <strong>Amount:</strong> {{ $trans->shares*$trans->unit_price }} </p>
													</div>
													<div class="col-md-3">
															<p> <strong>Date:</strong> {{ date('Y-m-d',strtotime($trans->created_at)) }} </p>
													</div>
													
													
												</div>
												
											</div>
										</div>
									@endforeach
									   <div class="clear-fix">&nbsp;</div>
							     </div>
                                @endforeach
                        @endif
                     </div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->
</section>
	
@stop

@section('page_scripts')
 <script src="{{ asset('js/shop.js') }}"></script>
@stop
