@extends('layouts.user-dashboard-master')
@section('frontcontent')

<section class="listShop_sec dashboardSec UserdashboardSecMark">


			<!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">
                  <div class="row">
						<?php //echo "<pre>"; print_r($Property); die; ?>
					  @if(Session::has('error'))
						<div class="col-md-12">
                             <div class="alert alert-danger">
							 <p>{{ Session::get('error')}}</p>
							 </div>
						</div>
                     @endif
					
					@if(!empty($Property))
					@foreach($Property as $key=>$val)
					   @php 
							$sharesDebit = $val->sharesHistory->where('type','debit')->where('user_id',Auth::id())->sum('share');
							$sharesCredit = $val->sharesHistory->where('type','credit')->where('user_id',Auth::id())->sum('share');
							$actualShares = $sharesCredit-$sharesDebit;
					
							$sharesUnitPrice =  (new App\Jobs\PropertyFunctions)->Check_get_average_price($val->id);
			            @endphp
						
						<div class="col-lg-12 secondary_market_wrapper">
							<div class="secondary_market">

								<div class="sellBlock">
								<div class="Sell_img dashimg dashboard-img">									
									@if(isset($val->file[0]->name))
									<img src="{{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
									@else
									<img src="images/dashBord_img.png" alt="dashBord_img">
									@endif
									</div>
									<div class="Sell_txt">
										<div class="innerTitle">
											<div class="lft_sid">
												<h3>{{$val['name']}}</h3>
											</div>
											<div class="rit_sid">
												<span class="clock">{{  \Carbon\Carbon::now()->DiffInDays( \Carbon\Carbon::parse($val['end_date']) ) }} day’s Left</span>
											</div>
										</div>
									</div>
									<div class="morInfo_btn">
										<a href="{{URL('/shop/secondary-property/')}}/{{$val['id']}}" class="moreB">{{__('text.t-m-info')}}</a>
									</div>
								</div>

								<div class="numbrText">
									<h4>Number of Shares</h4>
									<p>
										{{number_format($actualShares, 2, '.', ',')}}
									</p>
								</div>

								<div class="numbrText">
									<h4>Current Value</h4>
								    <p>{{$actualShares * $sharesUnitPrice ['average_price']}} EGP</p>
								</div>

								<div class="numbrText">
									<h4>Previous Value</h4>
									<p>{{$actualShares * $val['prev_average_price']}} EGP</p>
								</div>
								<div class="numbrText">
									<h4>Contracts</h4>
									@if($val->file->contains('module','contracts'))
										@foreach($val->file as $ckey=>$cval)																													
											<a href="{{url('/')}}/documents/contracts/{{$cval['name']}}" download><p class="contract"> {{$cval['title']}} </p></a>
										@endforeach
									@else
									<a href="#" download><p class="contract"> n/a </p></a>
									@endif
								</div>
							</div>
				@if(!$val->SecondaryInvestmentRequest->isEmpty())
								<!-- Start Sell Equity -->
						<div class="content sellequityWrapper">
								<div class="col-md-4">	
								</div>
								<div class="col-md-8">
									<h4>Buy/Sell Equity</h4>
								</div>
						
					@foreach($val->SecondaryInvestmentRequest->sortBy('status')  as $Sikey=>$Sival)
					
					     @php $paymentArr=[]; @endphp
                            @if(!$val->SecondaryInvestmentGatewayTransaction->isEmpty())
                                  @foreach($val->SecondaryInvestmentGatewayTransaction as $trans) 
								     @if(!in_array($trans->secondary_request_reference_id,$paymentArr))
									    @php $paymentArr[]=$trans->secondary_request_reference_id;  @endphp
									 @endif
								  @endforeach
							@endif
						@if($Sival['status']=='0')		
							@if(!isset($refuse_secondary_investment_request[$Sival['id']]))

							@if(in_array($Sival['property_id'],$UserPropInvestment) || $Sival['user_id']==Auth::id())
						<!-- Start Sell Blocks -->
						<div class="content sellequityBlocks">
						
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-8 sellequity ">
						
							<div class="content">	
								<div class="col-md-12">
									@if($Sival['user_id']==Auth::id())
									<p> Pending Purchase Request Made by you </p>
									@else
									<p>You have received an offer {{$Sival['user_id']}}</p>
									@endif
								</div>
							</div>
							<div class="content listoffer">
								<div class="col-lg-4">
								<span>{{$Sival['shares']}}</span> Shares
								</div>
								<div class="col-lg-4">
								asked price  <span>{{$Sival['unit_price']}}</span> Egp 
								</div>
								<div class="col-lg-4">
								Total <span>{{$Sival['unit_price']*$Sival['shares']}}</span> Egp
								</div>
							</div>
							<!--Start Modify -->
							<div class="content editofferer" style="display:none">
								<form name="" action="{{url('/dashboard/secondary-market/shares-bid')}}" method="POST">
									@csrf
									<input type='hidden' name="property_id" value="{{$val['id']}}">
									<input type='hidden' name="request_id" value="{{$Sival['id']}}">									
									<div class="form-group col-lg-3">
									<label>Shares</label><input type="text" name="shares" class="remark form-control" value="{{ ($Sival['shares'] < $actualShares) ? $Sival['shares']:$actualShares }}" placeholder="" onkeyup="checkShares(this,this.value,'{{ $actualShares }}')">								 
									</div>
									<div class="form-group col-lg-3">								   
									<label>Asked Price</label><input type="text" name="unit_price" class="remark form-control" value="{{$Sival['unit_price']}}" placeholder="">								 
									</div>
									<div class="form-group col-lg-3">
									<!--<label>Total</label> <p>{{$Sival['unit_price']*$Sival['shares']}} Egp</p>								-->
									</div>
									<div class="form-group col-lg-3">								   
									<p></p><button type="submit" class="savewireref btn btn-primary" value="">Submit</button>&nbsp;
									</div>
								</form>
							</div>
							<!-- End modify -->
							@if($Sival['user_id']!=Auth::id())
							<div class="content">
								<div class="col-lg-3">
									&nbsp;
								</div>
								<div class="col-lg-2">
									&nbsp;
								</div>
								<div class="col-lg-7">
								<button type="button" class='accept_shares' class="savewireref btn btn-primary" value="{{$Sival['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Accept</button>&nbsp;
								<button type="button" class='reject_shares' class="savewireref btn btn-primary" value="{{$Sival['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Reject</button>&nbsp;	
								<button type="button" class='refuse_shares' class="savewireref btn btn-primary" value="{{$Sival['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Counterbid</button>
								</div>
							</div>
							@endif
							
						</div>
			
				</div>
				<!--End blocks -->
					@endif
				@endif
				
				@elseif(($Sival['status']=='1' && $Sival['user_id']==Auth::id()))
				<!-- Start Sell Blocks -->
				<div class="content sellequityBlocks">
						
						<div class="col-lg-4">
						&nbsp;
						</div>
						<div class="col-lg-8 sellequity ">
						
							<div class="content">	
								<div class="col-md-12">
									<p><b>Please make payment for the Accepted offer</b></p>
								</div>
							</div>
							<div class="content listoffer">
								<div class="col-lg-2">
								<span>{{$Sival['shares']}}</span> Shares
								</div>
								<div class="col-lg-3">
								asked price  <span>{{$Sival['unit_price']}}</span> Egp 
								</div>
								<div class="col-lg-4">
								Total <span>{{$Sival['unit_price']*$Sival['shares']}}</span> <span>Egp +</span> ({{$commission_percent['1']}}) <span>% Commission</span>
								</div>
								@php
								$commission_amount = ($Sival['unit_price']*$Sival['shares'])*$commission_percent['1']/100;																
								@endphp
								<div class="col-lg-3">
								Grand Total <span>{{($Sival['unit_price']*$Sival['shares'])+$commission_amount}}</span> Egp 
								</div>								
								
							</div>

						
							<div class="content">
							 @if(in_array($Sival['id'],$paymentArr))
							   <p>Payment Made Successfully</p>
							 @else
									<div class="col-lg-3">
										&nbsp;
									</div>
									<div class="col-lg-2">
										&nbsp;
									</div>
									<div class="col-lg-3">
									<a href="{{url('/dashboard/secondary-market/final-payment/'.$Sival['id'].'?mode=card&table=request')}}"><button type="button" class='Payment' class="savewireref btn btn-primary" value="{{$Sival['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Card Payment</button></a>								
									</div>
									<div class="col-lg-3">
									<a href="{{url('/dashboard/secondary-market/final-payment/'.$Sival['id'].'?mode=wiretransfer&table=request')}}"><button type="button" class='Payment' class="savewireref btn btn-primary" value="{{$Sival['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Wire Transfer</button></a>								
									</div>
							 @endif
							</div>
							
						</div>
			
				</div>
				<!--End blocks -->
				@endif
				@endforeach				
			</div>
			@endif
<!--------------------------- -->
				<!-- End Sell Equity -->

		
				<!------------------ Start Diaplay ----------------->
	@if(!$val->SecondaryInvestmentBidsOffer->isEmpty())
				<div class="content sellequityWrapper">
								<div class="col-md-4">	
								</div>
								<div class="col-md-8">
									<h4>CounterBid(s)/Offer(s) </h4>
								</div>
					@foreach($val->SecondaryInvestmentBidsOffer  as $SiBkey=>$SiBval)	
					
					@if((in_array($SiBval['property_id'],$secondary_investment) ||$SiBval['to_user']==Auth::id() || $SiBval['user_id']==Auth::id())&& !isset($RefuseSecondaryInvestmentOffer[$Sival['id']]))
								<!-- Start Sell Blocks -->
								<div class="content sellequityBlocks">
								
								<div class="col-lg-4">
								&nbsp;
								</div>
								<div class="col-lg-8 sellequity ">
								
									<div class="content">	
										<div class="col-md-12">
								@if(($SiBval['to_user']=='' || $SiBval['to_user']=='0') && $SiBval['status']=='0')
										<p>You have received an Offer  </p>
								@else
										@if($SiBval['status']=='0')
											<p>You have received Bid against your offer </p>
										@elseif($SiBval['status']=='1')
											<p>Accepted Bid</p>
										@elseif($SiBval['status']=='2')
											<p>Rejected Bid</p>
										@else
											<p>Other Bid</p>	
										@endif
								@endif
										</div>
									</div>
									<div class="content listoffer">
										<div class="col-lg-4">
										<span>{{$SiBval['shares']}}</span> Shares
										</div>
										<div class="col-lg-4">
										asked price  <span>{{$SiBval['unit_price']}}</span> Egp 
										</div>
										<div class="col-lg-4">
										Total <span>{{$SiBval['unit_price']*$SiBval['shares']}}</span> Egp
										</div>
									</div>
									@if($SiBval['to_user']==Auth::id() || $SiBval['to_user']=='' || $SiBval['to_user']=='0')
										@if($SiBval['status']=='0')
										<div class="content">
											<div class="col-lg-3">
												&nbsp;
											</div>
											<div class="col-lg-2">
												&nbsp;
											</div>
											<div class="col-lg-7">
											<button type="button" class='action_bid' class="savewireref btn btn-primary" value="{{$SiBval['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}" ToUser="{{$SiBval['to_user']}}" act="accept">Accept</button>&nbsp;
											<button type="button" class='action_bid' class="savewireref btn btn-primary" value="{{$SiBval['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}" ToUser="{{$SiBval['to_user']}}" act="reject">Reject</button>&nbsp;							
											</div>
										</div>
										@elseif($SiBval['status']=='1' && $SiBval['is_paid']=='0')
										<div class="content">
												<div class="col-lg-3">
												&nbsp;
												</div>
												<div class="col-lg-3">
													&nbsp;
												</div>
												<div class="col-lg-3">
												<a href="{{url('/dashboard/secondary-market/final-payment/'.$SiBval['id'].'?mode=card&table=offer')}}"><button type="button" class='Payment' class="savewireref btn btn-primary" value="{{$SiBval['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Card Payment</button></a>								
												</div>
												<div class="col-lg-3">
												<a href="{{url('/dashboard/secondary-market/final-payment/'.$SiBval['id'].'?mode=wiretransfer&table=offer')}}"><button type="button" class='Payment' class="savewireref btn btn-primary" value="{{$SiBval['id']}}" propName="{{$val['name']}}" propId="{{$val['id']}}">Wire Transfer</button></a>								
												</div>
										</div>
										@endif
									@endif
								</div>
					
						</div>
						<!--End blocks -->
						@endif
						
				@endforeach				
			</div>
	@endif

				<!---------------------- End Display  ------------------->




<!------- --------------------------------->
						</div>		
									
						@endforeach
						@endif

					</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->
</section>
	
@stop

@section('page_scripts')
 <script src="{{ asset('js/userDashboard.js') }}"></script>
@stop
