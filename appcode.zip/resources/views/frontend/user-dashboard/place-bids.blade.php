@extends('layouts.user-dashboard-master')
@section('frontcontent')

<section class="listShop_sec dashboardSec">
		
 <!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">

					
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
							
							</div>
						</div>
					</div>

					<div class="row">
						
					@if(!empty($sendInvestmentOffer))
					
                            @foreach($sendInvestmentOffer as $key=>$val)
                                <div class="col-lg-12">
                                        <div class="secondary_market">

                                                <div class="sellBlock">
                                                        <!--<div class="Sell_img dashboard-img"><img src="{{asset('images/dashBord_img.png')}}" alt="dashBord_img"></div>-->
                                                   <div class="Sell_txt">
                                                        <div class="innerTitle">
                                                            <div class="lft_sid">
                                                                <h3>{{$val->property->name}}</h3>
                                                            </div>
                                                            
                                                        </div>
                                                    
                                                    </div>
                                                    <div class="morInfo_btn">
                                                        <a href="{{URL('/shop/property/')}}/{{$val->property->id}}" class="moreB">{{__('text.t-m-info')}}</a>
                                                    </div>
                                                    
                                                </div>

                                            <div class="numbrText">
                                                <h4>Number Of Shares</h4>
                                                <p>{{ $val->shares }} </p>
                                               
                                            </div>
                                            <div class="numbrText">
                                                <h4>Unit Price</h4>
                                                <p>{{ number_format($val->unit_price) }} EGP </p>
                                             </div>
                                            <div class="numbrText">
                                                <h4>Total Amount</h4>
                                                <p>{{ number_format($val->unit_price * $val->shares)  }} EGP</p>
                                             </div>
                                            <div class="numbrText">
                                                    <h4>Dated</h4>
                                                    
                                                    <p>{{ date('Y-m-d',strtotime($val->created_at))}}</p>
                                                </div>
                                                
                                                @if($val->status == '1')
                                                    <div class="numbrText">
                                                            <h4>Payment Status</h4>
                                                            @if($val->is_paid == '0')
                                                                <p class="badge badge-danger" style="background-color:red"><strong style="color:whitesmoke">Payment Pending</strong></p>
                                                            @else
                                                                <p class="badge badge-success" style="background-color:lawngreen"><strong style="color:whitesmoke">Paid</strong></p>
                                                            @endif
                                                    </div>
                                                 @else
                                                    <div class="numbrText">
                                                            <h4>Status</h4>
                                                            <p class="badge badge-danger" style="background-color:red"><strong style="color:whitesmoke">Pending</strong></p>
                                                     </div>
                                                 @endif
                                            
                                
                                        </div>
                                    </div>
                                @endforeach
						@endif

					</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->
</section>
	
@stop

@section('page_scripts')
 <script src="{{ asset('js/shop.js') }}"></script>
@stop