@extends('layouts.user-dashboard-master')
@section('frontcontent')
<section class="listShop_sec dashboardSec">
<div class="productSec">   
      <div class="ShopList">
        <div class="container New">
          <div class="row">
            <div class="col-lg-12">
              <div class="Innermelky">
                <h2>Edit Property Form</h2>
                <p>Melky Group is an opportunity for growth. You earn property ownership with help of each other In summary. there's no reason for Egyptians to not being able to own properly.</p>
              </div>
            </div>
          </div>
        </div>
      </div> 
<div class="container New">
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">&nbsp;</h3>
                  @if (Session::has('message'))
                     <div class="alert alert-info">{{ Session::get('message') }}</div>
                  @endif
                  @if ($message = Session::get('success'))

                      <div>
                          <p class="success-msz">{{ $message }}</p>
                      </div>

                    @endif

                    @if ($message = Session::get('error'))

                        <div class="alert alert-danger ">

                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                        <p>{{ $message }}</p></div>

                    @endif
                    @if ($errors->any())
                        @foreach ($errors->all() as $error)
                          <div class="alert alert-danger">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    {{ $error }}
                          </div>
                        @endforeach
                  @endif
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="save" method="post" role="form" action="{{url('dashboard/property/SaveUpdateProperty')}}" enctype="multipart/form-data">               
                {{ csrf_field()}}
									<input type="hidden" name="id" value="{{$Property['id']}}">
                  <div class="box-body">
                        
                  <div class="form-group row has-feedback {{ $errors->has('name') ? 'has-error' : '' }}">
                    <label for="name" class="col-sm-2 col-form-label">{{ __('form-label.offering-name') }}</label>
                    <div class="col-sm-10">
                    <input type="text" name="name" class="form-control" value="{{ $Property['name'] }}"
                           placeholder="Offering Name" required>
                    </div>
                    @if ($errors->has('name'))
                        <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                    @endif
                </div>
                 <div class="form-group row has-feedback {{ $errors->has('offering_type') ? 'has-error' : '' }}">
                    <label for="offering_type" class="col-sm-2 col-form-label">Type</label>
                    <div class="col-sm-10">
                        <select name="offering_type" class="form-control">
                          <option>Select Type</option>
                            @foreach($Category as $key=>$val)
                              @if($Property['offering_type'] == $key)
                                @php $selected = 'selected'; @endphp
                                @else
                                @php $selected = ''; @endphp
                              @endif
                              <option value="{{$key}}" {{$selected}}>{{$val}}</option>
                            @endforeach
                        </select>
                    </div>
                    @if ($errors->has('offering_type'))
                        <span class="help-block">
                            <strong>{{ $errors->first('offering_type') }}</strong>
                        </span>
                    @endif
                </div>
                
                <div class="form-group row has-feedback {{ $errors->has('base_price') ? 'has-error' : '' }}">
                  <label for="base_price" class="col-sm-2 col-form-label">Total Cost</label>
                  <div class="col-sm-10">
                    <input type="text" name="base_price" class="form-control"
                           placeholder="Total Cost" value="{{$Property['base_price']}}" required>
                  </div>
                    @if ($errors->has('base_price'))
                        <span class="help-block">
                            <strong>{{ $errors->first('base_price') }}</strong>
                        </span>
                    @endif
                </div> 

                <div class="form-group row has-feedback {{ $errors->has('description') ? 'has-error' : '' }}">
                   <label for="description" class="col-sm-2 col-form-label">Listing Detail</label>
                   <div class="col-sm-10">
                    <input type="text" name="description" class="form-control" value="{{ $Property['description'] }}" placeholder="Listing Detail" required|email>
                   </div>
                    @if ($errors->has('description'))
                        <span class="help-block">
                            <strong>{{ $errors->first('description') }}</strong>
                        </span>
                    @endif
                </div>       

                <div class="form-group row has-feedback {{ $errors->has('landmark') ? 'has-error' : '' }}">
                  <label for="landmark" class="col-sm-2 col-form-label">Location</label>
                  <div class="col-sm-10">
                    <input type="text" name="landmark" class="form-control"                       placeholder="Location" required value="{{ $Property['landmark'] }}">
                  </div>
                    @if ($errors->has('landmark'))
                        <span class="help-block">
                            <strong>{{ $errors->first('landmark') }}</strong>
                        </span>
                    @endif
                </div>  

                
                <div class="form-group row">
                  <label for="country" class="col-sm-2 col-form-label">Country</label>
                  <div class="col-sm-10">
                    <!--<label>Role</label>-->
                    <select class="form-control" name='country' id='country'>
                        <option value="">Choose Country </option>
                        @foreach($country as $key=>$val)
                          @if($Property['country'] == $key)
                            @php $selected = 'selected'; @endphp
                            @else
                            @php $selected = ''; @endphp
                          @endif
                        <option  value="{{$key}}" {{$selected}} >{{$val}}</option>
                        @endforeach
                    </select>
                  </div>
                </div>
                @php $PropAmenities = array(); @endphp
                @foreach($Property['amenities'] as $values)
                      
                  @php  $PropAmenities[$values['amenity']] = $values['value']; @endphp
                @endforeach
             
                  
                  @foreach($amenities as $key=>$value)
                     
                    <div class="form-group row has-feedback {{ $errors->has($key) ? 'has-error' : '' }}">
                      <label for="{{$key}}" class="col-sm-2 col-form-label">{{$value}}</label>
                      <div class="col-sm-10">
                        @if($key == 'price-per-meter')
                          <input type="number" name="amenities[{{$key}}]" class="form-control"
                               placeholder="{{$value}}" value="{{$PropAmenities[$key]??''}}" required>
                        @else
                       
                          <input type="text" name="amenities[{{$key}}]" id="{{$key}}" class="form-control"
                               placeholder="{{$value}}" value="{{$PropAmenities[$key]??''}}" required>
                             
                        @endif
                      </div>
                        @if ($errors->has($key))
                            <span class="help-block">
                                <strong>{{ $errors->first($key) }}</strong>
                            </span>
                        @endif
                    </div>  

                  @endforeach
               <div class="form-group row has-feedback {{ $errors->has('about_developer') ? 'has-error' : '' }}">
                  <label for="about_developer" class="col-sm-2 col-form-label">About Developer</label>
                  <div class="col-sm-10">
                    <textarea name="about_developer" class="form-control" id="about_developer" rows="3">{{ $Property['about_developer'] }}</textarea>
                  </div>
                    @if ($errors->has('about_developer'))
                        <span class="help-block">
                            <strong>{{ $errors->first('about_developer') }}</strong>
                        </span>
                    @endif
                </div>                        
                <div class="form-group row has-feedback {{ $errors->has('about_project') ? 'has-error' : '' }}">
                  <label for="about_project" class="col-sm-2 col-form-label">About Project</label>
                  <div class="col-sm-10">
                    <textarea name="about_project" class="form-control" id="about_project" rows="3">{{ $Property['about_project'] }}</textarea>
                  </div>
                    @if ($errors->has('about_project'))
                        <span class="help-block">
                            <strong>{{ $errors->first('about_project') }}</strong>
                        </span>
                    @endif
                </div>   
                
                <div class="form-group row has-feedback {{ $errors->has('end_date') ? 'has-error' : '' }}">  
                  <label for="end_date" class="col-sm-2 col-form-label">Property End Date</label>
                  <div class="col-sm-10">
                    <input type="text" name="end_date" id="end_date"  class="form-control"
                           placeholder="end date" autocomplete="off" required value="{{ date('d/m/Y',strtotime($Property['end_date'])) }}">
                  </div>
                    @if ($errors->has('end_date'))
                        <span class="help-block">
                            <strong>{{ $errors->first('end_date') }}</strong>
                        </span>
                    @endif
                </div>                        
                <div class="form-group row has-feedback {{ $errors->has('postedas') ? 'has-error' : '' }}">
                   <label for="postedas" class="col-sm-2 col-form-label">Posted As</label>
                   <div class="col-sm-10">
                    <input type="text" name="postedas" class="form-control" value="{{ old('postedas') }}" value="{{ $Property['created_by'] }}"
                           placeholder="Posted As" required|email>
                   </div>
                    @if ($errors->has('postedas'))
                        <span class="help-block">
                            <strong>{{ $errors->first('postedas') }}</strong>
                        </span>
                    @endif
                </div>  
                <div class="form-group row has-feedback ">
                <label for="end_date" class="col-sm-2 col-form-label">Property Existing Images</label> 
                <div class="col-sm-10">
                  <div class="row form-group">
                  <div class="col-sm-12">
                      <p><a href="#" class="moreB" data-toggle="modal" data-type="property" data-target="#propertyImages">Click here</a> to display existing images of this property</p>
                  </div>
                  
                </div>
                </div>
              </div> 
              <div class="form-group row has-feedback ">
                <label for="end_date" class="col-sm-2 col-form-label">Property Existing Doc</label> 
                <div class="col-sm-10">
                  <div class="row form-group">
                  <div class="col-sm-12">
                      <p><a href="#" class="moreB" data-toggle="modal" data-type="contracts" data-target="#propertyContracts">Click here</a> to display existing documents of this property</p>
                  </div>
                  
                </div>
                </div>
              </div> 
                <div class="form-group row has-feedback ">
                <label for="end_date" class="col-sm-2 col-form-label">Property Images</label> 
                <div class="col-sm-10 property-image">
                  <div class="row form-group">
                  <div class="col-sm-11">
                      <input type="file" class="custom-file-input" id="propertyimagex" name="propertyimage[]" >
                      <label class="custom-file-label" for="propertyimagex">Choose Image...</label>
                      
                      <div class="hint">Attach any picture of Property.</div>
                  </div>
                  <div class="col-sm-1">
                    <a href="javascript:void(0);" class="add_button" title="Add field"><img src="{{ asset('images/add-icon.png') }}"/></a>

                  </div>
                </div>
                </div>
              </div>
                <div class="form-group row has-feedback">
                <label for="end_date" class="col-sm-2 col-form-label">Property Documents</label> 
                  <div class="property-doc col-sm-10">
                    <div class="row form-group">
                    <div class="col-sm-11">
                      <div class="col-sm-6">
                      <input type="file" class="custom-file-input" id="propertydocx" name="propertydoc[]">
                      <label class="custom-file-label" for="propertydocx">Choose File...</label>
                      
                      <div class="hint">Attach any document of property.</div>
                    </div>
                    <div class="col-sm-6">
                        <input type="text" name="docname[]" class="form-control" placeholder="Doc Name">
                    </div>
                      </div>
                      <div class="col-sm-1">
                        <a href="javascript:void(0);" class="add_button_doc" title="Add field"><img src="{{ asset('images/add-icon.png') }}"/></a>
                      </div>
                  </div>
                </div>
                  </div><!-- /.box-body -->
                  
                  <input type="hidden" class="custom-file-input" name="status" id="status" value="1">
                  <div class="box-footer submitbox">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
               
          </div>
       </div>
    </section>
  </div>
</div>
</section>

@include('helpers.property-images', ['imageData' => $Property->file, 'modalName' => 'propertyImages', 'type' => 'property', 'path' => 'images/properties', 'heading' => 'Property Existing Images', 'isdoc' => 0])
@include('helpers.property-images', ['imageData' => $Property->file, 'modalName' => 'propertyContracts', 'type' => 'contracts', 'path' => 'documents/contracts', 'heading' => 'Property Existing Documents', 'isdoc' => 1])

@stop

@section('page_scripts')
<!--<script src="{{ asset('js/employee.js') }}"></script>-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">  
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.css" rel="stylesheet"/>

<script>
 
    $('a').click(function(){
      var imagetype = $(this).data('type');
      
      var pdata = {"_token": token()};
      $.ajax({
        type: 'POST',
         url: siteurl()+'/type/'+imagetype,
         data: pdata,
         success: function(data){
             

           }
    }); 
    });

    $( "#end_date" ).datepicker({ dateFormat: 'yy-mm-dd',
    beforeShow : function(){
           if(!$('.datepicker_wrapper').length){
                $('#ui-datepicker-div').unwrap('<div class="establishment_date_wrapper"></div>');
                $('#ui-datepicker-div').wrap('<div class="enddate"></div>');
           }
      } });
    $("#establishment-date").datepicker({dateFormat: 'yy-mm-dd'});
    

   
  
  $(document).on("change", '.custom-file-input', function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});


  
     var Imgx = 1;
    var maxFieldImg = 10; //Input fields increment limitation
    var addButtonImg = $('.add_button'); //Add button selector
    var wrapperImg = $('.property-image'); //Input field wrapper
    
    //Initial field counter is 1
    
    //Once add button is clicked
    $(addButtonImg).click(function(){
        //Check maximum number of input fields
              
        if(Imgx  <  maxFieldImg ){ 
          Imgx ++; //Increment field counter
            $(wrapperImg).append('<div class="row additional form-group"><div class="col-sm-11"><input type="file" class="custom-file-input" id="propertyimage'+ x +'" name="propertyimage[]"><label class="custom-file-label" for="propertyimage'+ x +'">Choose Image...</label></div><div class="col-sm-1"><a href="javascript:void(0);" class="remove_button"><img src="{{ asset("images/remove-icon.png")}}"/></a></div></div>'); //Add field html
        }
    });

    
    //Once remove button is clicked
    $(wrapperImg).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').parent('.additional').remove(); //Remove field html
        Imgx--; //Decrement field counter
    });

    

  
    var maxField = 10; //Input fields increment limitation
    var addButton = $('.add_button_doc'); //Add button selector
    var wrapper = $('.property-doc'); //Input field wrapper
    var x = 1; //Initial field counter is 1
    
    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append('<div class="row additional form-group"><div class="col-sm-11"><div class="col-sm-6"><input type="file" class="custom-file-input" id="propertydoc'+ x +'" name="propertydoc[]"><label class="custom-file-label" for="propertydoc'+ x +'">Choose File...</label></div><div class="col-sm-6"><input type="text" name="docname[]" class="form-control" placeholder="Doc Name"></div></div><div class="col-sm-1"><a href="javascript:void(0);" class="remove_button_doc"><img src="{{ asset("images/remove-icon.png")}}"/></a></div>'); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button_doc', function(e){
        e.preventDefault();
        $(this).parent('div').parent('.additional').remove(); //Remove field html
        x--; //Decrement field counter
    });



  </script>

<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> <script type="text/javascript">
//<![CDATA[
    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script>


@stop