@extends('layouts.user-dashboard-master')
@section('frontcontent')
 
 		<section class="loginPage" style="padding: 10px 0 10px;">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="loginForm">

							<div class="title_head">
								<h1>{{ trans('form-label.account-info') }}</h1>
							</div>
							@php $serial_id = ''; @endphp
							@if(!empty($editCardinfo))
								@foreach($editCardinfo as $key=>$val)
								
				                @if($val['label'] == 'cc_name')
									@php $details['cname'] =  $val['description']; 
											$serial_id = $val['serial']; @endphp
									@continue
								@endif
								 @if($val['label'] == 'card_num')
									@php $details['cnum'] = $val['description']; @endphp
									@continue
								@endif
								 @if($val['label'] == 'exp_month')
									@php $details['cmonth'] = $val['description']; @endphp
									@continue
								@endif
								 @if($val['label'] == 'exp_year')
									@php $details['cyear'] = $val['description']; @endphp
									@continue
								@endif
								
								@endforeach
							@endif
							<div class="innerform">
							<form action="{{url('dashboard/paymentinfo/update/')}}/{{$serial_id}}" name="save" novalidate method="post" id="account_info" role="form" enctype="multipart/form-data">
								{!! csrf_field() !!}
								<div class="row">
								<div class="col-md-12 mb-3">
					              	<div class="form-group">  
					                  	<label for="cc-name">Name on card</label>
					                  	<input type="text" class="form-control" name="cc_name" id="cc_name" placeholder="" value="{{$details['cname']??''}}" required>
					                  	<small class="text-muted">Full name as displayed on card</small>
				                  	</div>
				                </div>
				                <div class="col-md-12 mb-3">
					                <div class="form-group">
					                  <label for="cc-number">Card number</label>
					                  <input type="text" class="form-control" id="card_num" name="card_num" value="{{$details['cnum']??''}}" placeholder="" required>
				                  	</div>
				                </div>
				              </div>
				              <div class="row">
				                <div class="col-md-12 mb-5">
				                  <div class="col-md-12">
				                  <label for="cc-expiration">Expiration</label>
				                </div>
				                  	<div class="form-group">
				                  		<div class="col-md-6 mb-6 ">  
				                  			<input type="number" name="exp_month" class="form-control" id="exp_month" value="{{$details['cmonth']??''}}" placeholder="MM" required>
				                		</div>
				                	
				                  	
				                  		<div class="col-md-6 mb-6">  
				                  			<input type="number" name="exp_year" class="form-control" id="exp_year" value="{{$details['cyear']??''}}" placeholder="YY" required>
				                		</div>
				                	</div>
				                  
				                </div>
								</div>
								@if(!empty($editCardinfo))
									<input type="hidden" name="serial" class="fld_col" value="{{$serial_id}}">
									<div class="morInfo_btn submitbtn">
								<input type="submit" class="moreB" value="Update">
								
								</div>

								@else
									<input type="hidden" name="serial" class="fld_col" value="{{$user_id}}">
									<div class="morInfo_btn submitbtn">
								<input type="submit" class="moreB" value="Save">
								
								</div>
								@endif
								
							</form>
							@if ($message = Session::get('success'))

			                    <div>
			                        <p class="success-msz">{{ $message }}</p>
			                    </div>

			                    @endif

			                    @if ($message = Session::get('error'))

			                    <div class="alert alert-error badge-danger-lighten">

			                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

			                    <p>{{ $message }}</p></div>

			                    @endif
							@if ($message != '')

			                    <div>
			                        <p>{{ $message }}</p>
			                    </div>

			                    @endif

			                   
								
							</div>

							
						</div>
					</div>
				</div>

			</div>
		</section>
		@if($cards_info)
		<section class="listShop_sec dashboardSec" >
			<div class="productSec">   
		      <div class="ShopList">
		        <div class="container New">
		          <div class="row">
		            <div class="col-lg-12">
		              <div class="Innermelky">
		                <h4>List All Cards Details</h4>
		              </div>
		            </div>
		          </div>
		        </div>
		      </div> 
		      <div class="container New">
		          <div class="row">
		            <div class="col-lg-12">
		            	<div class="detail_table">
							<table cellpadding="0" cellspacing="0" border="0" width="100%">
								
								<tbody>
									<tr>
				                       <td><b>Name on Card</b></th>
				                       <td><b>Card Number</b></td>
				                       <td><b>Expire Month</b></td>
				                       <td><b>Expire Year</b></td>
				                       <td></td>
				                      </tr>
									@php
			                      $serial = '';
			                      @endphp                      
			                      @foreach($cards_info as $key=>$val)                        
			                        @if($val['serial']!=$serial)                        
			                        <tr>                        
			                        @endif
			                          @if($val['label']=='cc_name')
			                          <td><a href="{{url('dashboard/paymentinfo').'/'.$val['serial']}}">  {{ucfirst($val['description'])}}</a></td>
			                          @else
			                          <td>{{ucfirst($val['description'])}}</td>
			                          @endif                          
			                        @php
			                        $serial = $val['serial'];
			                        @endphp
									
			                        @if($val['serial']!=$serial)
			                        </tr>
			                        @endif 

			                      @endforeach
									
								</tbody>
							</table>
						</div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
 	@endif
 
  @stop
  @section('page_scripts')
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/js/bootstrapValidator.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.3/css/bootstrapValidator.min.css">
<script>

$('#card_num').keyup(function(event) { 
  $('#account_info').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            card_num: {
                validators: {
                    creditCard: {
                        message: 'The credit card number is not valid'
                    }
                }
            }
        }
    });
});
</script>


@stop