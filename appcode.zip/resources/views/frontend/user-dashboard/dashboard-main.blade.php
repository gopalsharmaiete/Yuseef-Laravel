@extends('layouts.user-dashboard-master')
@section('frontcontent')

<section class="listShop_sec dashboardSec">
			<!-- totalAmunt_invest start html -->
			<section class="totalAmunt_invest">
				<div class="container New">
					<div class="row">

						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<div class="invstBar first">
								<span></span>
								<div class="totlText">
									<h2>Total Invested Amount</h2>
								    <p>{{$grossTotalInvestment}} EGP</p>
								</div>
							</div>
						</div>

						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<div class="invstBar scnd">
								<span></span>
								<div class="totlText">
									<h2>Number of Investment</h2>
								    <p>{{  $numberOfinvestments }}</p>
								</div>
							</div>
						</div>

						<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<div class="invstBar thrd">
								<span></span>
								<div class="totlText">
									<h2>Rate of Return</h2>
								<p>{{ round($rateOfReturn,2) }}%</p>
								</div>
							</div>
						</div>

					</div>
				</div>
			</section>
			<!-- totalAmunt_invest end html -->

			<!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">

					
					<div class="row">
					
						<div class="col-lg-12">
							<div class="Innermelky">
							<form name="searchProperty" id="searchProperty" action="#" method="GET">
								<div class="alignBox">
									<div class="variation2">
										<select name="offering_type" id="offering_type" class="select filterform">
											<option value="">Select Category</option>											
											@foreach($Category as $key=>$val)
											@if(isset($_GET['offering_type']) && $_GET['offering_type'] == $key )
												@php $selected = 'selected'; @endphp
											@else
												@php $selected = ''; @endphp
											@endif
											<option  value="{{$key}}" {{$selected}}>{{$val}}</option>
											@endforeach
										</select>
									</div>

								</div>

								<div class="srchBox">
									<input type="text" class="fld" id="searchtext" name="s" @if(isset($_GET['s'])) value="{{$_GET['s']}}" @endif placeholder="Search" >
									<input type="submit" class="srch" value="">									
								</div>
							</form>
							</div>
						</div>
					</div>

					<div class="row">
							@if(Session::has('error'))
							<div class="col-md-12">
								 <div class="alert alert-danger">
								 <p>{{ Session::get('error')}}</p>
								 </div>
							</div>
						 @endif
						 @if(Session::has('success'))
							<div class="col-md-12">
								 <div class="alert alert-success">
								 <p>{{ Session::get('success')}}</p>
								 </div>
							</div>
						 @endif
						
					@if(!empty($Property))
					
					@foreach($Property as $key=>$val)
				        @php 
						  	$sharesDebit = $val->sharesHistory->where('type','debit')->where('user_id',Auth::id())->sum('share');
							$sharesCredit = $val->sharesHistory->where('type','credit')->where('user_id',Auth::id())->sum('share');
							$actualShares = $sharesCredit-$sharesDebit;
							
							$sharesUnitPrice =  (new App\Jobs\PropertyFunctions)->Check_get_average_price($val->id);
						@endphp
		           
					
						<div class="col-lg-12">
							<div class="secondary_market">
                              
								<div class="sellBlock">
									<div class="Sell_img dashimg dashboard-img">									
									@if(isset($val->file[0]->name))
									<img src="{{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
									@else
									<img src="images/dashBord_img.png" alt="dashBord_img">
									@endif
									</div>
									<div class="Sell_txt">
										<div class="innerTitle">
											<div class="lft_sid">
												<h3>{{$val['name']}}</h3>
											</div>
											<div class="rit_sid">
												<span class="clock">{{  \Carbon\Carbon::now()->DiffInDays( \Carbon\Carbon::parse($val['end_date']) ) }} day’s Left</span>
											</div>
										</div>
									</div>
									<div class="morInfo_btn">
										<a href="{{URL('/shop/property/')}}/{{$val['id']}}" class="moreB">{{__('text.t-m-info')}}</a>
									</div>
									@if($actualShares > 0 && $val['status'] == 1)
									   <div class="morInfo_btn">
												<button class="moreB" class="sell" data-id="{{$val['id']}}"  onclick="showForm(this)">Sell</button>
										</div>
									@endif
								
									@if($val['created_by']==Auth::id() && $val['status'] == 1)
                                      <div class="morInfo_btn" style="float:right">
									   <a href="{{URL('/dashboard/property/edit/'.$val['id'])}}" class="moreB">Edit</a>
									  </div>
									@endif
								</div>

								<div class="numbrText">
									<h4>Number of Shares</h4>
									<p>
										{{$actualShares}}
								 </p>
								</div>

								<div class="numbrText">
									<h4>Current Value</h4>
								  <p>{{  $actualShares * $sharesUnitPrice['average_price'] }} EGP</p>
								</div>

								<div class="numbrText">
									<h4>Previous Value</h4>
									<p>
									{{$actualShares * $val['prev_average_price']}} EGP
									</p>
								</div>
								<div class="numbrText">
									<h4>Contracts</h4>
									@if($val->file->contains('module','contracts'))
										@foreach($val->file as $ckey=>$cval)																													
											<a href="{{url('/')}}/documents/contracts/{{$cval['name']}}" download><p class="contract"> {{$cval['title']}} </p></a>
										@endforeach
									@else
									<a href="#"><p class="contract"> n/a </p></a>
									@endif
								</div>
								</div>
								  @if($actualShares > 0)
							<div class="content sellequityBlocks" id="sellequityBlocks{{ $val['id'] }}" style="display:none">
											<div class="col-lg-2" >
													&nbsp;
											</div>
											<div class="col-lg-2">
												<h5>Sell Your Share</h5>
											</div>
											<div class="col-lg-8">
												<div class="content editofferer" >
													<form name="" action="{{url('/dashboard/secondary-market/shares-bid-main')}}" method="POST">
														@csrf
													  <input type='hidden' name="property_id" value="{{$val['id']}}">
																					
														<div class="form-group col-lg-3">
														<label>Shares</label><input type="text" name="shares" class="remark form-control" value="{{ $actualShares }}" placeholder="" onkeyup="checkShares(this,this.value,'{{ $actualShares }}')" required>								 
														</div>
														<div class="form-group col-lg-3">								   
														<label>Asked Price</label><input type="text" name="unit_price" class="remark form-control" value="{{$sharesUnitPrice['average_price']}}" placeholder="" required>								 
														</div>
														<div class="form-group col-lg-3">
																					
														</div>
														<div class="form-group col-lg-3">								   
														<p></p><button type="submit" class="savewireref btn btn-primary" value="">Submit</button>&nbsp;
														</div>
														</form>
													</div>
											</div>
										</div>
									@endif
							     </div>
						 @endforeach
						@endif

					</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->
</section>
	
@stop


@section('page_scripts')
 <script src="{{ asset('js/shop.js') }}"></script>
 <script>
 function showForm(button){
	id = $(button).data('id');
    $('#sellequityBlocks'+id).show(); 
}

function checkShares(input,val,maxval) {
 
	maxval = parseInt(maxval);
	val = parseInt(val);
	if(val > maxval){
	alert("You Don't Have Enough Shares");
	$(input).val(maxval);
	}

}

 </script>
@stop
