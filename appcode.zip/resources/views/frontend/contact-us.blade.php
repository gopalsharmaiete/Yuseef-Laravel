 @extends('layouts.guest-master')
@section('frontcontent')
			<!-- inside banner -->
	<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
			    @php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">{{__('menu.home')}}</a></li>
							<li>{{__('menu.contact')}}</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.contact')}}</h2>
						        <p>{{__('text.contact-description')}}</p>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="bodr"></div>
						</div>
					</div>
				</div> 
			<!-- contactBar start html -->
            <div class="contactBar">
               <div class="container New">
                  <div class="row">

                      <div class="col-lg-12">
                            
							<!-- start contactForm -->
							<div class="contactForm">
								<div class="insdcont">
									<h2>{{__('text.send-your-query')}}</h2>
									<div class="insdForm">
										<form name="contact_form" action="#" method="post">
											{{ csrf_field() }}
											<input type="text" class="fld" pattern="^\w+[ ]*\w+$" name="name" placeholder="Name" required>
											<input type="email" class="fld" name="email" placeholder="Email" required>
											<textarea class="txtarea" name="description" placeholder="Description"></textarea>
											<input type="submit" value="SUBMIT" class="sbmt">
										</form>
									</div>
								</div>
							</div>
							<!-- end contactForm -->

							<!-- start contactTxt -->
							<div class="contactTxt">

								<div class="insdContct">
									<h2>{{__('text.contact-our-office-address')}}</h2>
									<ul>
										<li class="adrs">
											<span>{{__('text.contact-address')}} {{__('text.contact-pincode')}}</span>
										</li>
										<li class="call">
											<span>
											{{__('text.contact-phone')}}
											</span>
										</li>
										<li class="ml">
											<span>
												<a href="#">{{__('text.contact-email')}}</a>
											</span>
										</li>
									</ul>
								</div>
                                
                                <div class="map_img">
								<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7290567.006974257!2d26.383490765670597!3d26.84481279773019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14368976c35c36e9%3A0x2c45a00925c4c444!2sEgypt!5e0!3m2!1sen!2sin!4v1573810835691!5m2!1sen!2sin" width="400" height="250" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                                </div>

							</div>
							<!-- end contactTxt -->

                      </div>

                  </div> 
               </div>
            </div>
			<!-- contactBar start html -->
            
		</section>

@stop


@section('page_scripts')
<script>
$(document).ready(function(){
	$("form").submit(function(e){
		e.preventDefault();
		$.post('contact-us',$("form").serialize());
		alert('Thank you for your message');
		location.reload();
	});
});
</script>
@stop