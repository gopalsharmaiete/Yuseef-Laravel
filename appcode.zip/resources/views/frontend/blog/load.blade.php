					@foreach($Blog as $key=>$val)
						<div class="col-lg-12">
							<div class="secondary_market blogPosts new-blog-text">
								<div class="sellBlock">
									<div class="Sell_img">
										<a href="{{url('/blog/'.$val['id'])}}">
											@if(!$val->file->isEmpty())
											
											  <img src="{{asset('images/blog/'.$val->file[0]->name)}}" alt="secndry1">
											@else
											  <img src="images/secndry1.png" alt="secndry1">
											@endif
										</a>
										</div>
								</div>
								<div class="priceRit_br">
									<h4><a href="{{url('/blog/'.$val['id'])}}">{{$val['title']}}</a></h4>
								 <span class="by-john">By {{$val['author']}}</span>
									<p class="lorem-text-new">{{ strip_tags(substr($val['description'],0,400)).'....' }}</p>
									
									<div class="viewsBtm">
										<!--<a href="#">0 Views</a>-->
										<a href="#">{{$val['created_at']}}</a>
										<a href="#" class="likeLink"></a>
									</div>
								</div>
							</div>
						</div>
						@endforeach						
