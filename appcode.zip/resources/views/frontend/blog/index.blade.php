@extends('layouts.guest-master')
@section('frontcontent')

<!-- inside banner -->
<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				<img src="images/inside-banner2.jpg">
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">Home</a></li>
							<li>Blog</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>Blog</h2>
								<p>On the Secondary Market, you have the ability to trade with current users who already own shares of selected properties</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- ShopList end html -->

			<!-- top_seller_propertie start html -->
			<div class="top_seller_propertie listProperty">
				<div class="container New">

					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<div class="srchBox">
									<input type="text" class="fld" placeholder="Search">
									<input type="submit" class="srch" value="">
								</div>
							</div>
						</div>
					</div>

					<div class="row" id="grid">
					@foreach($Blog as $key=>$val)
					  <div class="col-lg-12">
							<div class="secondary_market blogPosts new-blog-text">
								<div class="sellBlock">
									<div class="Sell_img">
										<a href="{{url('/blog/'.$val['id'])}}">
											@if(!$val->file->isEmpty())
											
											  <img src="{{asset('images/blog/'.$val->file[0]->name)}}" alt="secndry1">
											@else
											  <img src="images/secndry1.png" alt="secndry1">
											@endif
										</a>
									</div>
								</div>
								<div class="priceRit_br">
									<h4><a href="{{url('/blog/'.$val['id'])}}">{{$val['title']}}</a></h4>
								     <span class="by-john">By {{$val['author']}}</span>
									<p class="lorem-text-new">{{ strip_tags(substr($val['description'],0,400)).'....' }}</p>
									
									<div class="viewsBtm">
										<!--<a href="#">0 Views</a>-->
										<a href="#">{{$val['created_at']}}</a>
										<a href="#" class="likeLink"></a>
									</div>
								</div>
							</div>
						</div>
						@endforeach						

					</div>

					<div class="ajax-load text-center" style="display:none">
						<p><img src="{{asset('images/loader.gif')}}"></p>
					</div>
					
					<div class="morInfo_btn seProj">
						<a href="#" class="moreB">load More</a>
					</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->

		</section>

@stop
@section('page_scripts')
 <script src="{{ asset('js/blog.js') }}"></script>
@stop