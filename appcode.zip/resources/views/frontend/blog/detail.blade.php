@extends('layouts.guest-master')
@section('frontcontent')

<!-- inside banner -->
<section class="insideBanner">
			
		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">Home</a></li>
							<li>Blog Details</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky blogDetailsHd">
								<h2>{{$blog->title}}</h2>
								<div class="views">
								<span class="author">by {{ ucfirst($blog->author)}}</span>
									<p>
										<!--<a href="">2 views /</a>-->
										<a href="">{{date('d-M-Y',strtotime($blog->created_at))}}</a>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>



			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="blogDet_banner" style="text-align:center !important;">
							 
								@if(!$blog->file->isEmpty())
									<img src="{{asset('images/blog/'.$blog->file[0]->name)}}" alt="secndry1">
								@else
								  <img src="{{ asset('images/inside-banner2.jpg')}}">
								@endif
							
						</div>
					</div>
				</div>
				
				<div class="text-">
             		<p>{!! $blog->description !!}</p>                	
             	</div>

			</div>

				</div>
			</div>
			<!-- top_seller_propertie start html -->

		</section>

@stop
@section('page_scripts')
 <script src="{{ asset('js/blog.js') }}"></script>
@stop