@extends('layouts.guest-master')

@section('underhead')
<meta property="og:image"content="{{ asset('images/product_img.png') }}" />
@stop

@section('frontcontent')
<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">{{__('menu.home')}}</a></li>
							<li><a href="#">{{__('menu.shop')}}</a></li>
							<li>Product</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<!-- productSec start html -->

		<div class="productSec">
			<div class="container New">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="prodctImg">
							<div id="myCarousel" class="carousel slide" data-ride="carousel">
								  <!-- Indicators 
								  <ol class="carousel-indicators">
								    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
								    <li data-target="#myCarousel" data-slide-to="1"></li>
								    <li data-target="#myCarousel" data-slide-to="2"></li>
								  </ol>-->

								  <!-- Wrapper for slides -->
								  <div class="carousel-inner">
								  	@if(count($Property->file) > 0)
								  	@php $x=1; @endphp
										@foreach($Property->file as $value)
										@if($value->module == 'property')
											@if($x==1)
												@php $active= 'active'; @endphp
											@else
												@php $active= ''; @endphp
											@endif
									    <div class="item {{$active}}">
									      <img src="{{url('/')}}/images/properties/{{$value->name}}" >
									    </div>
									    	@php $x++; @endphp
									    	@endif
								   		@endforeach
									@else
									<div class="item active">
										<img src="{{ asset('images/Tsell_1.png') }}">
									</div>
									@endif
								   
								  </div>

								  <!-- Left and right controls -->
								  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
								    <span class="glyphicon glyphicon-chevron-left"></span>
								    <span class="sr-only">Previous</span>
								  </a>
								  <a class="right carousel-control" href="#myCarousel" data-slide="next">
								    <span class="glyphicon glyphicon-chevron-right"></span>
								    <span class="sr-only">Next</span>
								  </a>
								</div>
													
						</div>
					</div>

					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
						<div class="sellBlock">
							<div class="titleHed">Funding</div>
							<div class="Sell_txt">
								<div class="innerTitle">
									<div class="lft_sid">
										<h3>{{$Property['name']}}</h3>
									</div>
									<div class="rit_sid loctin">
										<span class="clock">{{$Property['countryname']['name']}}</span>
									</div>
									<div class="rit_sid">
										<span class="clock">{{  \Carbon\Carbon::now()->DiffInDays( \Carbon\Carbon::parse($Property['end_date']) ) }} day’s Left</span>
									</div>
								</div>
								<div class="descrip_t">
									<p>{{$Property['description']}}</p>
								</div>								
							</div>
							<div class="social_img">
								<ul>
									<li><a href="https://www.facebook.com/sharer/sharer.php?u={{url()->current()}}" target="_blank"><img src="{{ asset('images/fb_img.png') }}" alt="fb"></a></li>
									<li><a href="http://twitter.com/share?url={{url()->current()}};text={{$Property['name']}};size=l&amp;count=none" target="_blank"><img src="{{ asset('images/twtr_img.png') }}" alt="twitter"></a></li>															
								</ul>
							</div>
							
							@if(str_replace(url('/'), '', url()->previous())=='/shop' || str_replace(url('/'), '', url()->previous())=='/' )
							<!-- Asked price and price bar -->
							
								<div class="fixProd_slid">
									<div class="rangSlider">
											<div class="prcTitle">
												<h4 class="lft_P">Asked Price: <span>{{number_format($Property['base_price'], 2, '.', ',')}} {{__('text.currency')}} /Raised: {{number_format($Property['investment']->sum('amount'), 2, '.', ',')}} {{__('text.currency')}}</span></h4>									
											</div>
											<div class="progress">
													<?php
														$percantage= round($Property['investment']->sum('amount')*100/$Property['base_price']);
														$prnt =  "<div class='progress-bar' role='progressbar' style='width: ".$percantage."%;' aria-valuenow='25' aria-valuemin='0'
														aria-valuemax='100'><span class='slideRang'>".$percantage."%</span>";
														echo $prnt;
													?>
												</div>
											</div>
									</div>									
								
								</div></br>
							<!--End  Asked price and price bar -->
							@endif
							<div class="col-sm-5">
								@if(str_replace(url('/'), '', url()->previous())!='/dashboard')
									<div class="morInfo_btn">
										<a href="#" class="moreB" data-toggle="modal" data-target="#investModal">Invest</a>
									</div>
								@endif
							</div>
							<div class="col-sm-7">
									@if(count($Property->file) > 0)
								  		@if($Property->file->contains('module', 'contracts'))
								  			<div class="morInfo_btn">
												<a href="#" class="moreB" data-toggle="modal" data-target="#myModal">Files & Documents</a>
											</div>
								    	@endif	
									@endif
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- productSec end html -->

		<!-- locationMap start html -->
		<div class="locationMap">
			<div class="container New">
				<div class="row">

					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="table_left">
							<div class="Innermelky">
								<h2>Listing Detail</h2>
							</div>

							<div class="detail_table">
								<table cellpadding="0" cellspacing="0" border="0" width="100%">
									<tbody>
										<tr>
											<td>Price</td>
											<td>{{number_format($Property['base_price'], 2, '.', ',')}} {{__('text.currency')}}</td>
										</tr>
										@if(!empty($Property->amenities))
										@foreach($Property->amenities as $key=>$val)

											<tr>
												<td>{{__('prop-amenities-form.'.$val->amenity)}}</td>
												@if($val->amenity == 'price-per-meter')
													<td>{{number_format($val->value, 2, '.', ',')}} {{__('text.currency')}}</td>
												@else
													<td>{{$val->value}}</td>
												@endif
											</tr>
										@endforeach
										@endif
									</tbody>
								</table>
							</div>
						</div>

					</div>

					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="mapRit_br">
							<div class="Innermelky">
								<h2>Location in Map</h2>
							</div>
							<div class="mapImg">
								<div class="mapouter">
									<iframe width="500" height="425" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7290567.006974257!2d26.383490765670597!3d26.84481279773019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14368976c35c36e9%3A0x2c45a00925c4c444!2sEgypt!5e0!3m2!1sen!2sin!4v1573795700160!5m2!1sen!2sin&t=&z=13&ie=UTF8&iwloc=&output=embed"
									 frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- locationMap end html -->

		<!-- aboutDev_cntr start html -->
		<div class="melkyGroup aboutDev_cntr">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<div class="Innermelky">
							<h2>About Developer</h2>
							<p>{!!$Property['about_developer']!!}</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- aboutDev_cntr start html -->

		<!-- aboutDev_cntr start html -->
		<div class="melkyGroup aboutDev_cntr last">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<div class="Innermelky">
							<h2>About Project</h2>
							<p>{!!$Property['about_project']!!}</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- aboutDev_cntr start html -->

<!---- Popup ---->

@if(count($Property->file) > 0)
								  	
	@if($Property->file->contains('module', 'contracts'))

     <!-- Modal -->
		  <div class="modal fade" id="myModal" role="dialog">
		    <div class="modal-dialog">
		    
		      <!-- Modal content-->
		      <div class="modal-content">
		        <div class="modal-header">
		          <button type="button" class="close" data-dismiss="modal">&times;</button>
		          <h4 class="modal-title">Files & Documents</h4>
		        </div>
		        <div class="modal-body">
		          <div class="detail_table">
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tbody>
								@foreach($Property->file as $value)
								@if(!empty($value->title))
									@if($value->module == 'contracts')
									<tr>
										<td>{{$value->title}}</td>
										<td> 
										<a href="{{url('/')}}/documents/contracts/{{$value->name}}" download>
										<span class="glyphicon glyphicon-download-alt"></span>
										</a>
									</td>
									</tr>
									@endif
								@endif
								@endforeach
							</tbody>
						</table>
					</div>
		        </div>
		        <div class="modal-footer">
		          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        </div>
		      </div>
		      
		    </div>
		  </div>
    
	@endif	
@endif

 <!-- Modal for Invest -->
		  <div class="modal fade" id="investModal" role="dialog">
		    <div class="modal-dialog">
		    
		      <!-- Modal content-->
		      <div class="modal-content">
		        <div class="modal-header">
		          <button type="button" class="close" data-dismiss="modal">&times;</button>
		          <h4 class="modal-title">Invest</h4>
		        </div>
		        <div class="modal-body">
		        	<h3>Total Amount</h3>
		          	<form class="form-inline investform" method="post" role="form" action="{{url('investment/confirm/')}}" >
		          		{{ csrf_field()}}
					  	<div class="input-group">
					  		<span class="input-group-addon"></span>
							<input type="number" name="inveramt" class="form-control" aria-label="Amount (rounded to the nearest dollar)" min="1" max="{{round($Property['base_price'] - $Property['investment']->sum('amount'))}}" required>
							<span class="input-group-addon">{{__('text.currency')}}</span>							
						</div>
						<input type="hidden" name="propertyID" value="{{$Property['id']}}">
						<input type="hidden" name="propertyName" value="{{$Property['name']}}">
					  	<button type="submit" class="btn btn-primary mb-2">Continue</button>
					  
					</form>
		        </div>
		        
		      </div>
		      
		    </div>
		  </div>

@stop
@section('page_scripts')
 <script src="{{ asset('js/shop.js') }}"></script>
@stop