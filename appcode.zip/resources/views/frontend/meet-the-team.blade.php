 @extends('layouts.guest-master')
@section('frontcontent')
		<!-- inside banner -->
		<section class="insideBanner">
			<!-- <div class="parallax-window" data-parallax="scroll" data-image-src="images/insdBanner.jpg" 0></div> -->
			<div class="wallPapr">
				@php 
					$backgroundImage = App\Helpers\ImagesHelper::backgroundImage();
				@endphp;

				@if(isset($backgroundImage->name))
				    <img src="{{ asset('images/background-image/'.$backgroundImage->name) }}">
				@else
				   <img src="images/insdBanner.jpg">
				@endif
			</div>
		</section>
		<!-- inside banner -->

		<!-- Hom_breadcrumb start html -->
		<div class="Hom_breadcrumb">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<ul class="breadcrumb">
							<li><a href="#">Home</a></li>
							<li>Meet the Team</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- Hom_breadcrumb end html -->

		<section class="listShop_sec">
			<!-- ShopList start html -->
			<div class="ShopList aboutList">
				<div class="container New">
					<div class="row">
						<div class="col-lg-12">
							<div class="Innermelky">
								<h2>{{__('menu.meet_the_team')}}</h2>
								<p class="fontP18">{{__('text.meet_the_team_desc')}}</p>
							</div>
						</div>
					</div>
				</div>
			</div>		
			<!-- ShopList end html -->
			
			<div class="container New">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="meet-team-block">
							<ul>
							@foreach($forms_serials as $key=>$val)
								@if(isset($val->file[0]->name) && !empty($val->file[0]->name))
									<li>
										<div class="img-block">
											<img src="images/team/{{$val->file[0]->name}}" alt="" title="" class="t_img" >
											<div class="soc-icons">
												<a href="#" class="icon01"></a>
												<a href="#" class="icon02"></a>
												<a href="https://twitter.com/{{$val->data->firstWhere('label', '=', $val->serial.'_twitter')['description']}}" class="icon03"></a>
												<a href="https://www.linkedin.com//{{$val->data->firstWhere('label', '=', $val->serial.'_linkedin')['description']}}" class="icon04"></a>
											</div>
										</div>
										<div class="textim_cont">
											<p class="t_name">{{$val->data->firstWhere('label', '=', $val->serial.'_name')['description']}}<span>{{$val->data->firstWhere('label', '=', $val->serial.'_designation')['description']}}</span></p>
											<p>{!! $val->data->firstWhere('label', '=', $val->serial.'_details')['description'] !!}.</p>									
										</div>
										</li>
								@endif
							@endforeach

								<!--<li>
									<div class="img-block">
										<img src="images/testimonials-img01.jpg" alt="" title="" class="t_img" >
										<div class="soc-icons">
											<a href="#" class="icon01"></a>
											<a href="#" class="icon02"></a>
											<a href="#" class="icon03"></a>
											<a href="#" class="icon04"></a>
										</div>
									</div>
									<div class="textim_cont">
										<p class="t_name">Robble White<span>Founder</span></p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
									</div>
								</li>
								<li>
									<div class="img-block">
										<img src="images/testimonials-img02.jpg" alt="" title="" class="t_img" >
										<div class="soc-icons">
											<a href="#" class="icon01"></a>
											<a href="#" class="icon02"></a>
											<a href="#" class="icon03"></a>
											<a href="#" class="icon04"></a>
										</div>
									</div>
									<div class="textim_cont">
										<p class="t_name">Riley Jones<span>Founder</span></p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
									</div>
								</li>
								<li>
									<div class="img-block">
										<img src="images/testimonials-img03.jpg" alt="" title="" class="t_img" >
										<div class="soc-icons">
											<a href="#" class="icon01"></a>
											<a href="#" class="icon02"></a>
											<a href="#" class="icon03"></a>
											<a href="#" class="icon04"></a>
										</div>
									</div>
									<div class="textim_cont">
										<p class="t_name">Payton Hillman<span>Founder</span></p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
									</div>
								</li>
								<li>
									<div class="img-block">
										<img src="images/testimonials-img01.jpg" alt="" title="" class="t_img" >
										<div class="soc-icons">
											<a href="#" class="icon01"></a>
											<a href="#" class="icon02"></a>
											<a href="#" class="icon03"></a>
											<a href="#" class="icon04"></a>
										</div>
									</div>
									<div class="textim_cont">
										<p class="t_name">Robble White<span>Founder</span></p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
									</div>
								</li>
								<li>
									<div class="img-block">
										<img src="images/testimonials-img02.jpg" alt="" title="" class="t_img" >
										<div class="soc-icons">
											<a href="#" class="icon01"></a>
											<a href="#" class="icon02"></a>
											<a href="#" class="icon03"></a>
											<a href="#" class="icon04"></a>
										</div>
									</div>
									<div class="textim_cont">
										<p class="t_name">Riley Jones<span>Founder</span></p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
									</div>
								</li>
								<li>
									<div class="img-block">
										<img src="images/testimonials-img03.jpg" alt="" title="" class="t_img" >
										<div class="soc-icons">
											<a href="#" class="icon01"></a>
											<a href="#" class="icon02"></a>
											<a href="#" class="icon03"></a>
											<a href="#" class="icon04"></a>
										</div>
									</div>
									<div class="textim_cont">
										<p class="t_name">Payton Hillman<span>Founder</span></p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
										<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
									</div>
								</li>-->
								
							</ul>
						</div>
					</div>
				</div>
			</div>
            
		</section>
@stop
