@extends('layouts.guest-master')
@section('frontcontent')
		<!-- Start bannerSection -->
		<section class="bannerSection">

			<div class="insdBanner">
				<div class="owl-carousel owl-theme topSlider">
				  @foreach($Sliders as $slide)
					<div class="item">
						<div class="insdItem">
							<img src="{{ asset('images/main-slider/'.$slide->name) }}">
							<div class="sliderTxt">
								<h1>{{__('text.slider-image-1-text')}}</h1>
								<a href="{{url('/about-us')}}">Know More</a>
							</div>
						</div>
					</div>
					@endforeach
					
				</div> 
				<a href="#" class="mouseBox"><span></span></a>
			</div>

		</section>
		<!-- End bannerSection -->



		<!-- Start logo slider -->
		<section class="logoSection">

			<div class="insdLogoCntr">
				<div class="owl-carousel owl-theme logo">
				
				  @foreach($Secondary as $logo)
					<div class="item">
						<div class="insdItem">
							<div class="logoBox">
								<img src="{{ asset('images/secondary-slider/'.$logo->name) }}">
							</div>
						</div>
					</div>
                  @endforeach
				

				</div>
			</div>
		</section>
		<!-- logo slider -->



		<!-- melkyGroup start html -->
		<div class="melkyGroup">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="Innermelky">
							<h2>{{__('text.melky-group')}}</h2>
							<p>{{__('text.melky-home-under-head-desc')}}</p>
							<div class="bodr"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- melkyGroup start html -->

		<!-- purposeShop start html -->
		<div class="purposeShop">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<div class="Innermelky">
							<h2>{{__('text.melky-home-purpose')}} <span>{{__('text.melky-home-myequity')}}</span></h2>
						</div>
					</div>
				</div>

				<div class="row">

					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="videoCntr">
							<a class="playBtn" href="javascript:void(0)">
								<img src="{{ asset('images/video_play.png') }}">
							</a>
							
							<video id="videoPlayer" width="100%" poster="{{ asset('images/video_poster.png') }}">
								@if(isset($videoData[0]->name))
								  <source src="{{asset('images/video-upload/'.$videoData[0]->name)}}" type="video/mp4">
								@else
								  <source src="video/demovideo.mp4" type="video/mp4">
								@endif
							</video>
						</div>
					</div>

					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<ul class="videoText">
							<li>{{__('text.home-purpose-bullet-1')}}</li>
							<li>{{__('text.home-purpose-bullet-2')}}</li>
							<li>{{__('text.home-purpose-bullet-3')}}</li>
						</ul>
					</div>

				</div>

			</div>
		</div>
		<!-- purposeShop start html -->

		<!-- top_seller_propertie start html -->
		<div class="top_seller_propertie">
			<div class="container New">
				<div class="row">
					<div class="col-lg-12">
						<div class="Innermelky">
							<h2>{{__('text.top-seller-prop')}}</h2>
						</div>
					</div>
				</div>

				<div class="row Hght_min homePageGrid">
				@foreach($Property as $key=>$val)
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
						<div class="sellBlock">
							<div class="Sell_img">
							@if(isset($val->file[0]->name) && $val->file[0]->module == 'property')
							<img src=" {{url('/')}}/images/properties/{{$val->file[0]->name}}" alt="{{$val->file[0]->name}}">
							@else
							<img src="{{ asset('images/Tsell_1.png') }}" alt="img">
							@endif
							</div>
							<div class="Sell_txt">
								<div class="innerTitle">
									<div class="lft_sid">
										<h3>{{$val['name']??''}}</h3>
										<p> {{$val['countryname']->name??''}}</p>
									</div>
									<div class="rit_sid">
										<span class="clock">{{  \Carbon\Carbon::now()->DiffInDays( \Carbon\Carbon::parse($val['end_date']) ) }} day’s Left</span>
									</div>
								</div>
								<div class="prcTitle">
									<h4 class="lft_P">Asked Price: <span>{{number_format($val['base_price'], 2, '.', ',')}} {{__('text.currency')}}</span></h4>
									
								</div>
								<div class="descrip_t">
									<p>{{$val['description']}}</p>
								</div>
								<div class="rangSlider">
									<cite class="dolrT">{{number_format($val['investment']->sum('amount'), 2, '.', ',')}} {{__('text.currency')}} Raised Of {{number_format($val['base_price'], 2, '.', ',')}} {{__('text.currency')}}</cite>
									<div class="progress">
									<?php
										$percantage= round($val['investment']->sum('amount')*100/$val['base_price']);
										$prnt =  "<div class='progress-bar' role='progressbar' style='width: ".$percantage."%;' aria-valuenow='25' aria-valuemin='0'
										 aria-valuemax='100'><span class='slideRang'>".$percantage."%</span>";
										 echo $prnt;
									?>
										 </div>
									</div>
								</div>
							</div>
							<div class="morInfo_btn">
								@php $url = '/shop/property/'. $val['id']; @endphp
								<a href="{{URL($url)}}" class="moreB">{{__('text.t-m-info')}}</a>
							</div>
						</div>
					</div>				
				@endforeach

				</div>

				<div class="morInfo_btn seProj">
					<a href="{{URL('/shop')}}" class="moreB">{{__('text.see-all-our-active-projects')}}</a>
				</div>

			</div>
		</div>
		<!-- top_seller_propertie start html -->

		<!-- Historical_cntr start html -->
		<div class="Historical_cntr">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="Innermelky">
							<h2>{{__('text.historical-returns')}}</h2>
							<ul class="inverstRetn">
								<li><span>0EGP</span>{{__('text.minimum-investment')}}</li>
								<li class="yerApl_img"><span>30%</span>{{__('text.yearly-appreciation')}}</li>
							</ul>
						</div>
					</div>
				</div>

			<!--	<div class="morInfo_btn seProj">
					<a href="#" class="moreB">{{__('text.see-more')}}</a>
				</div> -->

			</div>
		</div>
		<!-- Historical_cntr start html -->


		<!-- features -->
		<section class="featureSctn">
			<div class="features">

				<div class="titleCntr">
					<h1>{{__('text.our-mission-head')}}</h1>
					<h2>{{__('text.our-mission-under-head-tag')}}</h2>
					<p>{{__('text.our-mission-under-head-detail')}}
					</p>
				</div>

				<div class="container">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div class="feature-box">
								<div class="left-box">
									<img src="{{ asset('images/thumb1.png') }}" />
								</div>
								<div class="right-box">
									<h3>{{__('text.open-funding-through-the-public')}}:</h3>
									<p>{{__('text.open-funding-through-the-public-desc')}} </p>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div class="feature-box">
								<div class="left-box">
									<img src="{{ asset('images/thumb2.png') }}" />
								</div>
								<div class="right-box">
									<h3>{{__('text.affordability-and-gains')}}</h3>
									<p>{{__('text.affordability-and-gains-desc')}} </p>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div class="feature-box">
								<div class="left-box">
									<img src="{{ asset('images/thumb3.png') }}" />
								</div>
								<div class="right-box">
									<h3>{{__('text.simplycity-liquidity')}}</h3>
									<p>{{__('text.simplycity-liquidity-desc')}}</p>
								</div>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div class="feature-box">
								<div class="left-box">
									<img src="{{ asset('images/thumb4.png') }}" />
								</div>
								<div class="right-box">
									<h3>{{__('text.trust')}}</h3>
									<p>{{__('text.trust-desc')}} </p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- features -->

@stop