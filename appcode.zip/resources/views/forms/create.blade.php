@extends('adminlte::page')

@section('title', 'Melky Group')

@section('content_header')
    <h1>Add </h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="forms" method="post" role="form" action="{{url('forms/')}}" enctype="multipart/form-data">               
                {{ csrf_field()}}
                <input type="hidden" name="form_name" value="{{$form_name}}">
                  
                <div class="box-body"><!-- /.box-body -->                        
                  <div class="form-group">
                      <label for="exampleInputEmail1">Locale</label>
                        <select name="locale">
                            <option value="en">English</option>
                            <option value="fr">French</option>
                        </select>
                    </div>
                </div><!-- /.box-body -->


									@foreach($forms_fields as $val)
                  <div class="box-body"><!-- /.box-body -->                        
                  <div class="form-group has-feedback {{ $errors->has($val['label']) ? 'has-error' : '' }}">
                    <input type="{{$val['type']}}" name="{{$val['label']}}" class="form-control" value=""
                           placeholder="{{$val['label']}}" required>              
                  </div>                
                </div><!-- /.box-body -->

                @endforeach

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/forms.js') }}"></script>
@stop