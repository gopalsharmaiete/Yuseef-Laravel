@extends('adminlte::page')

@section('title', 'Melky Group')

@section('content_header')
    <h1>Edit </h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="forms" method="post" role="form" action="{{url('forms').'/'.$serial}}" enctype="multipart/form-data">               
                {{ csrf_field() }}
										{{ method_field('PATCH') }}
                <input type="hidden" name="form_name" value="{{$form_name}}">         
									@foreach($forms_data as $val)
                  
                  @if($val['label']!=$serial.'_locale')                  
                  <div class="box-body"><!-- /.box-body -->                        
                  <div class="form-group has-feedback {{ $errors->has($val['label']) ? 'has-error' : '' }}">
                    <input type="text" name="{{$val['label']}}" class="form-control" value="{{$val['description']}}"
                           placeholder="{{$val['label']}}" required>              
                  </div>                
                </div><!-- /.box-body -->
                @endif

                @endforeach
               
                
              
                @if($forms_serials->where('serial',$serial)->isNotEmpty())
                    @foreach($forms_serials->where('serial',$serial) as $key=>$val)
                    @if(isset($val->file[0]['id']))
                    <div class="row">
                    <div class="col-md-6">
                    <div class="box-body"><!-- /.box-body -->                        
                      <div class="form-group has-feedback {{ $errors->has($val['file']) ? 'has-error' : '' }}">
                    
                        <label for="file">Existing file : {{$val['name']}}</label>
                        <input type="file" name="file" id="file" class="form-control" value="" title=" {{$val->file[0]['name']}}" />                                  
                        <input type="hidden" name="old_image_id" value="{{$val->file[0]['id']}}"/>
                      </div>                
                    </div><!-- /.box-body -->
                    </div>
                      <div class="col-md-6">
                         @if(app('request')->input('form') == 'video-upload')
                         <video width="320" height="240" controls>
                            <source src="{{url('/')}}/images/{{$form_name}}/{{$val->file[0]['name']}}" type="video/mp4">
                           </video>
                         @else
                            <img src="{{url('/')}}/images/{{$form_name}}/{{$val->file[0]['name']}}" class="img-responsive">
                         @endif
                        </div>
                    </div>
                    @else
                      <div class="row">
                        <div class="col-md-6">
                        <div class="box-body"><!-- /.box-body -->                        
                          <div class="form-group has-feedback {{ $errors->has($val['file']) ? 'has-error' : '' }}">
                        
                            <label for="file">Image</label>
                            <input type="file" name="file" id="file" class="form-control" value="" title="Image" />                                                     
                          </div>                
                        </div><!-- /.box-body -->
                        </div>
                          <div class="col-md-6">
                          
                          </div>
                        </div>
                    @endif
                    @endforeach
                @else
                <div class="row">
                <div class="col-md-6">
                <div class="box-body"><!-- /.box-body -->                        
                  <div class="form-group has-feedback {{ $errors->has($val['file']) ? 'has-error' : '' }}">
                 
                    <label for="file">Image</label>
                    <input type="file" name="file" id="file" class="form-control" value="" title="Image" />                                                     
                  </div>                
                </div><!-- /.box-body -->
                </div>
                  <div class="col-md-6">
                  
                  </div>
                </div>
                @endif

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/forms.js') }}"></script>
@stop