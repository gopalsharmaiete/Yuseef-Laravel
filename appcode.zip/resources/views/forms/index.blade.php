@extends('adminlte::page')

@section('title', 'Melky')

@section('content_header')
    <h1>Stored</h1>
@stop

@section('content')
  <div class="container">
  <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">
      
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-body">
          <div class="row">
              <div class="col-md-12">
                  <div class="panel panel-default">
                      <div class="panel-heading">CSV Import<button type="button" class="close" data-dismiss="modal">&times;</button></div>
                      <div class="panel-body">
                          <form class="form-horizontal" method="POST" action="{{ URL('/form/importdata') }}" enctype="multipart/form-data">
                                   {{ csrf_field() }}

                              <div class="form-group{{ $errors->has('csv_file') ? ' has-error' : '' }}">
                                  <label for="csv_file" class="col-md-4 control-label">CSV file to import</label>
                                       <input type="hidden" name="form_name" value="{{ $module_id }}"/>
                                  <div class="col-md-6">
                                      <input id="csv_file" type="file" class="form-control" name="csv_file">

                                      @if ($errors->has('csv_file'))
                                          <span class="help-block">
                                          <strong>{{ $errors->first('csv_file') }}</strong>
                                      </span>
                                      @endif
                                  </div>
                              </div>
                              <div class="form-group">
                                  <div class="col-md-8 col-md-offset-4">
                                      <input type="submit" class="btn btn-primary" value="Upload CSV" name="submit"/>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
          </div>
        </div>
        
      </div>
    </div>
    
  </div>   

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing </h3>
                  <!-- Trigger the modal with a button -->
				          <button type="button" class="btn btn-info btn-primary pull-right" data-toggle="modal" data-target="#myModal">Import CSV</button>
                  <span class="samplecsv" style= "float: right;font-weight: bold; padding: 9px 14px 0px 0px;"><a href="{{URL('form/sample-csv/?form='.$module_id)}}">Download Sample</a></span>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                       <th>Lang</th>
                      @foreach($forms_fields as $key=>$val)                                            
                        @if($val['label']!='file')
                        <th>{{ucfirst($val['label'])}}</th>
                        @endif
                        
                      @endforeach   
                         
                      </tr>
                    </thead>
                    <tbody>
                      @php
                      $serial = '';
                      $i=0;
                      @endphp                      
                      @foreach($forms_data as $key=>$val)                        
                        @if($val['serial']!=$serial)                        
                          <tr>                        
                        @endif
                          @if($val['label']==$val['serial'].'_name' || $val['label']==$val['serial'].'_question' || strcasecmp($val['label'],$val['serial'].'_title') == 0 )
                            <td>
                              @if(RolesHelper::check('3',$module_id))
                                <a href="{{url('forms').'/'.$val['serial'].'/edit?form='.$val['group'].'&moduleID='.$module_id}}">{{ucfirst($val['description'])}}</a>
                               
                               @else  
                                 {{ucfirst($val['description'])}} 
                              @endif
                              
                              @php 
                                $uri = app('request')->input('form');
                                $URL = ["video-upload" ,"background-image"];
                              @endphp
                              @if(!in_array($uri, $URL))
                                &nbsp;<form action="{{ url('/forms'.'/'.$val['serial'])  }}" method="post">
                                    {{ csrf_field()}}
                                    @method('DELETE')
                                  <input type="hidden" name="module_id"  value="{{ $module_id }}">
                                        <input type="submit" value="Delete" />
                                  </form>
                              @endif
                            </td> 
                          
                          @else
                            <td>{{ucfirst($val['description'])}}</td>
                          @endif                          
                          @php
                           $serial = $val['serial'];
                          @endphp
                           @if($val['serial']!=$serial)
                         
                            </tr>
                          @endif 
                        @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
  <script>
    var name = '{{ app("request")->input("form") }}';
  </script>
@stop

@section('page_scripts')

<script src="{{ asset('js/forms.js') }}"></script>
@stop