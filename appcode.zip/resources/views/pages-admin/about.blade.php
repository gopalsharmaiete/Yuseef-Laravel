@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Upload About Us page images </h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  
                <!-- /.box-header -->
                <div class="col-md-6 col-sm-6">
                <!-- Form start -->
                <form name="roleSave" method="post" role="form" action="{{url('admin/images/save')}}" enctype="multipart/form-data">
                {{ csrf_field() }}
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">File</label>
                      <input name="file" type="file" class="form-control" id="file"  required>                      
                    </div>
                  </div><!-- /.box-body -->
                  <input name="uploadable_type" type="hidden" class="form-control" id="uploadable_type" value="about">
                  @foreach($imagesData as $key=>$val)
                    <input name="id" type="hidden" class="form-control" value="{{$val['id']}}">
                  @endforeach
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                <!--  End form -->
                </div>
                <div class="col-md-6 col-sm-6">
                  @foreach($imagesData as $key=>$val)
                        
                        <img src="{{url('/')}}/images/pages/{{$val['name']}}" class="img-responsive">
                        <!--<td><button type="button"  value="{{$val['id']}}" class="dtedit">Edit</button>&nbsp;<button type="button"  value="{{$val['id']}}" class="del">Delete</button></td>-->
                      @endforeach
                </div>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
                  </div>
              </div><!-- /.box -->

              


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/roles.js') }}"></script>
@stop