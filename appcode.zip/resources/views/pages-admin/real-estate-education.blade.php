@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Upload Real Estate Education Page Images </h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                 @for($i=0; $i<6; $i++)
                 <div class="row">
                <!-- /.box-header -->
                <div class="col-md-6 col-sm-6">
                <!-- Form start -->
                <form name="roleSave" method="post" role="form" action="{{url('admin/images/save')}}" enctype="multipart/form-data">
                {{ csrf_field() }}
                  <div class="box-body">
                    <div class="form-group">
                      <label for="title">Title</label>
                      @php $j = 0; @endphp
                        @foreach($imagesData as $key=>$val)
                        
                          @if($j==$i)
                            <input name="title" type="text" class="form-control" value="{{$val['title']}}" placeholder="Enter Title"   required>
                            @php $j++; @endphp
                          @else
                            @php $j++; @endphp
                            @php continue; @endphp
                          @endif
                        
                        @endforeach                      
                    </div>
                  </div><!-- /.box-body -->
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">File</label>
                      <input name="file" type="file" class="form-control">                      
                    </div>
                  </div><!-- /.box-body -->
                  <input name="uploadable_type" type="hidden" class="form-control" id="uploadable_type" value="real-estate-education">
                  
                  @php $k = 0; @endphp
                  @foreach($imagesData as $key=>$val)
                    @if($k==$i)
                    <input name="id" type="hidden" class="form-control" value="{{$val['id']}}">
                     @php $k++; @endphp
                    @else
                      @php $k++; @endphp
                      @php continue; @endphp
                    @endif
                 
                  @endforeach
                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                <!--  End form -->
                </div>
                <div class="col-md-6 col-sm-6">
                  @php $l = 0; @endphp
                  @foreach($imagesData as $key=>$val)
                        @if($l==$i)
                          <img src="{{url('/')}}/images/pages/{{$val['name']}}" class="img-responsive">
                           @php $l++; @endphp
                        @else
                          @php $l++; @endphp
                          @php continue; @endphp
                        @endif
                 
                  @endforeach
                </div>
              </div>
                @endfor
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
                  </div>
              </div><!-- /.box -->

              


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/roles.js') }}"></script>
@stop