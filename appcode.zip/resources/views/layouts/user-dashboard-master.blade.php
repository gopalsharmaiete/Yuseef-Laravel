<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>:: Melky Group ::</title>
	<link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
	<link href="{{ asset('css/owl.carousel.min.css') }}" rel="stylesheet">
	<link href="{{ asset('css/custom.css') }}" rel="stylesheet">
	<link href="{{ asset('css/devStyle.css') }}" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Barlow:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">
	<script>
		function token(){
			return "{{ csrf_token() }}";
		}
		function siteurl(){
			return "{{URL('/')}}";
		}
	</script>
</head>
@include('layouts.dashboard-sidebar')
@include('layouts.front-header')
@yield('frontcontent')
@include('layouts.front-footer')
