<body class="dashBoard dashBordOn">
<!-- dashBoardMenu -->
	<div class="dashBoardMenu active">

		<div class="dashbrdTrigger">
			<span class="openDashbord"><img src="{{ asset('images/menu-icon.png') }}"></span>
			<span class="closeDashbord"><img src="{{ asset('images/close.png') }}"></span>
		</div>
		<ul>
			<li>
				<a href="{{URL('/dashboard/pending-transactions')}}" data-toggle="tooltip" title="Pending Transaction">
					<i><img src="{{ asset('images/transaction.png') }}"></i><span>Pending Transaction</span>
				</a>
			</li>
			<li>
				<a href="{{URL('/dashboard')}}" data-toggle="tooltip" title="Portfolio">
						<i><img src="{{ asset('images/portfolio.png') }}"></i><span>Portfolio</span>
				</a>
			</li>
			<li>
				<a href="{{URL('/dashboard/transaction')}}" data-toggle="tooltip" title="Transaction">
					<i><img src="{{ asset('images/transaction.png') }}"></i><span>Transaction</span>
				</a>
			</li>
			<li>
				<a href="{{URL('/dashboard/secondary-market')}}" data-toggle="tooltip" title="Secondary Market">
					<i><img src="{{ asset('images/market.png') }}"></i><span>Secondary Market</span>
				</a>
			</li>
			<li>
				<a href="{{URL('/dashboard/place-bids')}}" data-toggle="tooltip" title="Placed Bid">
					<i><img src="{{ asset('images/place.png') }}"></i><span>Placed Bid</span>
				</a>
			</li>
			<li>
			<a href="{{ URL('/dashboard/transfer') }}" data-toggle="tooltip" title="Transfers">
					<i><img src="{{ asset('images/transfer.png') }}"></i><span>Transfers</span>
				</a>
			</li>
			<li>
				<a href="{{ URL('/dashboard/refer-a-friend') }}" data-toggle="tooltip" title="Refer a Friend">
					<i><img src="{{ asset('images/refer.png') }}"></i><span>Refer a Friend</span>
				</a>
			</li>
			<li>
				<a href="{{URL('/dashboard/property/create')}}" data-toggle="tooltip" title="Upload a property">
					<i><img src="{{ asset('images/manage_prop_ico.png') }}"></i><span>Upload a property</span>
				</a>
			</li>
			<li>
				<a href="{{ URL('/pmb') }}" data-toggle="tooltip" title="Personel Message Board">
							<i><img src="{{ asset('images/transfer.png') }}"></i><span>Message Board</span>
				</a>
			</li>
		</ul>
	</div>
<!-- dashBoardMenu -->
