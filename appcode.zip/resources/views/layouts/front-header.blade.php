@yield('header_scripts')
</head>

	<body>	
	<!-- Start wrapper -->
	<div class="wrapper">
		@auth
		<div class="dashBordOn">
		@endauth
		<!-- Start headerBox -->
		<section class="headerBox">
			<div class="container">
				<div class="row">

					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="logo">
							<a href="{{URL('/')}}"><img src="{{ asset('images/logo.png') }}"></a>
						</div>

						<div class="hdrRight">
							@if (str_contains(url()->current(), '/dashboard'))
							<span class="mobileDashTrigger"><img src="{{asset('images/menu-icon-hover.png')}}"></span>
							@endif
							<div class="navBar">
								<!-- <span class="closeButn"></span> -->
								<nav>
									<ul>
										<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
										<li><a href="{{URL('/shop')}}">{{__('menu.shop')}}</a></li>
										<li><a href="{{URL('/secondary-marketing')}}">{{__('menu.secondary_market')}}</a></li>
										<li><a href="{{URL('/real-estate-education')}}">{{__('menu.real_estate_education')}}</a></li>
										<li><a href="{{URL('/about-us')}}">{{__('menu.about_us')}}</a></li>
										<li><a href="{{URL('/contact-us')}}">{{__('menu.contact')}}</a></li>										
										
									</ul>
								</nav>
							</div>

							<div class="dropMenu">
								<a href="#" class="butnDrop"></a>
							</div>
							@guest
							<div class="investrBox">
								<a href="#" class="investorBtun">{{ __('menu.become_an_investor') }}</a>
								<ul>
									<li><a href="{{URL('/user-login')}}">{{__('menu.login_account')}}</a></li>
									<li><a href="{{URL('/invester-register')}}">{{__('menu.create_account')}}</a></li>
								</ul>
							</div>
							@endguest

							@php
								
								if(app()->getLocale()=='en')
								{
									$lang_img = 'images/lang.png';
									$active_eng = 'active';
									$active_fr = '';
								}
								else
								{
									$lang_img = 'images/french.png';
									$active_eng = '';
									$active_fr = 'active';
								}

							@endphp
							@guest
							@php 
							   $language = 1;
						    @endphp
								@if(isset($langSettings))
									@php
										$language = $langSettings[0]->value;
									@endphp
								
								@endif
							@if($language == 1)
								<div class="langBox">
									<a class="ion-ios-arrow-down dropLang" href="javascript:void(0)">
										<img src='{{ asset("$lang_img") }}'>
									</a>
									<ul>
										<li class="$active_eng"><a href="{{ url('locale/en') }}"><img src="{{ asset('images/lang.png') }}"></a></li>
										<li class="$active_fr"><a href="{{ url('locale/fr') }}"><img src="{{ asset('images/french.png') }}"></a></li>
									</ul>
								</div>
							@endif
							@endguest
							<div class="mobileMenu">
								<a href="javascript:void(0)"><span></span></a>
							</div>
							@auth
								
							<div class="loginSectn">								
								<div class="bellBar">								
									<a href="javascript:void(0)" class="bellIcon"></a>

									<div class="bellDropBox">
										<ul>
										@foreach (Auth::user()->notifications as $notification)  
                                        
											@if($notification->type == 'App\Notifications\NewMessage' )        						   			
												<li><a href="{{ isset($notification->data['URL']) ? $notification->data['URL'] : '#' }}"><img src="{{ asset('images/Real_Estate_Edu_ico01.png') }}"> <span>You have received an offer from  
												{{$notification->data['ByUserName']}} For {{$notification->data['shares']}} Shares Of {{$notification->data['property_name']}} </span></a></li>
											@elseif($notification->type == 'App\Notifications\ApproveShares')
											<li><a href="{{ isset($notification->data['URL']) ? $notification->data['URL'] : '#' }}"><img src="{{ asset('images/Real_Estate_Edu_ico01.png') }}"> <span>Your Purchase Request Has Been Accepted By {{$notification->data['ByUserName']}} For {{$notification->data['property_name']}}  </span></a></li>
											@elseif($notification->type == 'App\Notifications\BidsShares')
											<li><a href="{{ isset($notification->data['URL']) ? $notification->data['URL'] : '#' }}"><img src="{{ asset('images/Real_Estate_Edu_ico01.png') }}"> <span>Your You Received An Counter Bid From
											{{$notification->data['ByUserName']}} For {{$notification->data['property_name']}}  </span></a></li>											
											@endif
        								@endforeach											
										</ul>

										<span><a href="{{URL('/dashboard/notification')}}" class="seeMore">See More</a></span>

									</div>
								</div>

								<div class="dropLogin">
								<div class="insdLogin">									  
									   @if(isset(Auth::user()->file[0]->path))
										@if(file_exists(Auth::user()->file[0]->path))
										@php $url = asset('images/profile/'.Auth::user()->file[0]->name);  @endphp
											<a href="#"><img src="{{ asset('images/profile/'.Auth::user()->file[0]->name) }}"> <span>Hi {{ Auth::user()->name }}</span></a>
											@else
											<a href="#"><img src="{{ asset('images/profile.jpg') }}"> <span>Hi {{ Auth::user()->name }}</span></a>
											@endif										
											@else
											<a href="#"><img src="{{ asset('images/profile.jpg') }}"> <span>Hi {{ Auth::user()->name }}</span></a>
									    @endif
									</div>
									<div class="settingDrop">
										<ul>
											<li class="login"><a href="{{URL('/dashboard')}}">Dashboard</a></li>
											<li class="login"><a href="{{URL('/dashboard/settings/')}}/{{ Auth::user()->id }}">Setting</a></li>
											<li class="logout">
												@if(config('adminlte.logout_method') == 'GET' || !config('adminlte.logout_method') && version_compare(\Illuminate\Foundation\Application::VERSION, '5.3.0', '<'))
					                                <a href="{{ url(config('adminlte.logout_url', 'auth/logout')) }}">
					                                    <i class="fa fa-fw fa-power-off"></i> {{ trans('adminlte::adminlte.log_out') }}
					                                </a>
					                            @else
					                                <a href="#"
					                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
					                                >
					                                    <i class="fa fa-fw fa-power-off"></i> {{ trans('adminlte::adminlte.log_out') }}
					                                </a>
					                                <form id="logout-form" action="{{ url(config('adminlte.logout_url', 'auth/logout')) }}" method="POST" style="display: none;">
					                                    @if(config('adminlte.logout_method'))
					                                        {{ method_field(config('adminlte.logout_method')) }}
					                                    @endif
					                                    {{ csrf_field() }}
					                                </form>
					                            @endif
					                        </li>
										</ul>
									</div>
								</div>
								 @php 
								   $language = 1;
								 @endphp
								@if(isset($langSettings))
									@php
										$language = $langSettings[0]->value;
									@endphp
								
								@endif
								@if($language == 1)
									<div class="langBox">
										<a class="ion-ios-arrow-down dropLang" href="javascript:void(0)">
											<img src='{{ asset("$lang_img") }}'>
										</a>
										<ul>
											<li class="$active_eng"><a href="{{ url('locale/en') }}"><img src="{{ asset('images/lang.png') }}"></a></li>
											<li class="$active_fr"><a href="{{ url('locale/fr') }}"><img src="{{ asset('images/french.png') }}"></a></li>
										</ul>
									</div>
								@endif
							 </div>
						</div>
						
						@endauth

						</div>
					</div>

				</div>
			@guest
			</div>
			@endguest
		</section>
		<!-- Start headerBox -->
				<!-- fullMenu -->
		<div class="fullMenu">
			<ul>
				<li><a href="{{URL('/meet-the-team')}}"> {{__('menu.meet_the_team')}} </a></li>
				<li><a href="{{URL('/benefit')}}">{{__('menu.benefit')}} </a></li>
				<li><a href="{{URL('/faq')}}">{{__('menu.faq')}}</a></li>				
				<li><a href="{{URL('/testimonials')}}">{{__('menu.testimonial')}} </a></li>
				<li><a href="{{URL('/blog')}}">{{__('menu.blog')}}</a></li>
				<li><a href="{{URL('/price-guide')}}">{{__('menu.price-guide')}}</a></li>
				@guest
				<li><a href="{{URL('/invester-register')}}">{{__('menu.sign-up')}}</a></li>
				@endguest
			</ul>
		</div>
		<!-- fullMenu -->