		<!-- FOOTER START -->
		<div class="footer-section">
			<div class="container">
				<div class="logo-box">
					<img src="{{ asset('images/footer-logo.png') }}" />
				</div>
				<div class="quick-link">
					<h4>Quick links</h4>
					<ul>
						<li><a href="{{URL('/')}}">{{__('menu.home')}}</a></li>
						<li><a href="{{URL('/shop')}}">{{__('menu.shop')}}</a></li>
						<li><a href="{{URL('/secondary-marketing')}}">{{__('menu.secondary_market')}}</a></li>
						<!--<li><a href="#">{{__('menu.my_equity')}}</a></li>-->
						<li><a href="{{URL('/real-estate-education')}}">{!!__('menu.real_estate_education')!!}</a></li>
					</ul>
					<ul>
						<li><a href="{{URL('/')}}">{{__('menu.investment')}}</a></li>
						<li><a href="{{URL('/meet-the-team')}}">{{__('menu.meet_the_team')}} </a></li>
						<li><a href="{{URL('/benefit')}}">{{__('menu.benefit')}}</a></li>
						<li><a href="{{URL('/blog')}}">{{__('menu.blog')}}</a></li>
					</ul>
					<ul>
						<li><a href="{{URL('/testimonials')}}">{{__('menu.testimonial')}}</a></li>
						<li><a href="{{URL('/faq')}}">{{__('menu.faq')}}</a></li>
						<li><a href="{{URL('/price-guide')}}">{{__('menu.price-guide')}} </a></li>
						<li><a href="{{URL('/invester-register')}}">{{__('menu.sign-up')}}</a></li>
					</ul>
				</div>
				<div class="social-box">
					<h4>{{__('text.get-in-touch')}}</h4>
					<span>{{__('text.contact-address')}}</span>
					<span>{{__('text.contact-pincode')}}</span>
					<ul>
						<li><a href="#"><img src="{{ asset('images/facebook.png') }}" /></a></li>
						<li><a href="#"><img src="{{ asset('images/twitter.png') }}" /></a></li>
						<li><a href="#"><img src="{{ asset('images/youtube.png') }}" /></a></li>
						<li><a href="#"><img src="{{ asset('images/in.png') }}" /></a></li>
					</ul>
				</div>
				<div class="copyright">
					<div class="div1"></div>
					<div class="copyright1">
						<span>{{__('text.copyright')}}</span>
					</div>
				</div>
			</div>
		</div>
		<!-- FOOTER END -->
	@auth
	</div>
	@endauth

	</div>
	<!-- End wrapper -->
<div id="avangate-hero" class="hide"></div>

	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="{{ asset('js/jquery.min.js') }}"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="{{ asset('js/bootstrap.min.js') }}"></script>
	<script src="{{ asset('js/owl.carousel.min.js') }}"></script>
	<script src="{{ asset('js/parallax.js') }}"></script>
	<script src="{{ asset('js/custom.js') }}"></script>
	<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
	
@yield('page_scripts')
@yield('subpage_scripts')
		<script>
			$(document).ready(function(){
				$(".bellIcon").click(function(){				
					$(this).css("background-image", "url('<?php echo url("images/bell2.png")?>')");     
						$.ajax({url: "notificationmarkread", success: function(result){														
							$(this).css("background-image", "url('<?php echo url("images/bell2.png")?>')");             																		
						}});
						
				});
			});						
		</script>
@if(Auth::user())
		@if(Auth::user()->unreadNotifications()->count()==0)
			<script>
				$(document).ready(function(){
					$(".bellIcon").css("background-image", "url('<?php echo url("images/bell2.png")?>')");     
				});
			</script>
		@endif
@endif		
</body>

</html>