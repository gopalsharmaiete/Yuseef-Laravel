@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Multilinguals Cms</h1>
@stop


@section('content')
    
<div class="container">
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-body">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">CSV Import<button type="button" class="close" data-dismiss="modal">&times;</button></div>
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" action="{{ route('importdata') }}" enctype="multipart/form-data">
							{{ csrf_field() }}

                            <div class="form-group{{ $errors->has('csv_file') ? ' has-error' : '' }}">
                                <label for="csv_file" class="col-md-4 control-label">CSV file to import</label>

                                <div class="col-md-6">
                                    <input id="csv_file" type="file" class="form-control" name="csv_file">

                                    @if ($errors->has('csv_file'))
                                        <span class="help-block">
                                        <strong>{{ $errors->first('csv_file') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-8 col-md-offset-4">
                                    <input type="submit" class="btn btn-primary" value="Upload CSV" name="submit"/>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
      </div>
      
    </div>
  </div>
  
</div>
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              @if(RolesHelper::check('2','17'))
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="roleSave" method="post" role="form" action="{{url('multilingual')}}">
                {{ csrf_field() }}
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Locale</label>
                        <select name="locale">
                            <option value="en">English</option>
                            <option value="fr">French</option>
                        </select>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Add Group</label>
                      <input name="group" id="group" type="text" class="form-control" value="" placeholder="Enter" required  autocomplete="on">              
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Add Label</label>
                      <input name="label" id="label" type="text" class="form-control" value="" placeholder="Enter" required>              
                    </div>

                    <div class="form-group">
                      <label for="exampleInputEmail1">Value</label>
                      <textarea name="description" id="description" class="form-control" value="" required> </textarea>
                    </div>

                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
                    @if($errors->any())
                      <div class="alert alert-danger">
                        <ul>
                          @foreach($errors->all() as $error)
                             <li>{{ $error }}</li>
                          @endforeach
                        </ul>
                      </div>
                   @endif
              </div><!-- /.box -->
              @endif
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Stored </h3>
				  <!-- Trigger the modal with a button -->
				  <button type="button" class="btn btn-info btn-primary pull-right" data-toggle="modal" data-target="#myModal">Import CSV</button>
				  <span class="samplecsv" style= "float: right;font-weight: bold; padding: 9px 14px 0px 0px;"><a href="downloadsample/multilingual.csv">Download Sample</a></span>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Locale</th>  
                        <th>Group</th>
                        <th>Label</th>
                        <th>Value</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($MultilingualsData as $key=>$val)
                      <tr>
                      <td name="locale">{{$val['locale']}}</td>    
                      <td name="group">{{$val['group']}}</td>                      
                        <td name="label">{{$val['label']}}</td>
                        <td name="description">{{$val['description']}}</td>
                        <td>
                          @if(RolesHelper::check('3','17'))
                            <button type="button"  value="{{$val['id']}}" class="dtedit">Edit</button>@endif&nbsp;@if(RolesHelper::check('2','17'))<button type="button"  value="{{$val['id']}}" class="copy" title="Duplicate">
                             <i class="fa fa-clone" aria-hidden="true"></i>
                            </button>@endif&nbsp;
                          @if(RolesHelper::check('4','17'))
                             <form action="{{ URL('/multilingual').'/'.$val['id'] }}" method="post">
                                 @method('DELETE')
                                   {{ csrf_field() }}
                                 <button type="submit"  value="{{$val['id']}}" class="del" title="Delete"><i class="fa fa-trash" aria-hidden="true"></i></button>
                             </form>
                            @endif
                        </td>
                      </tr>
                      @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/multilinguals.js') }}"></script>
@stop

@if($errors->has('csv_file'))
	<script>
     
    </script>
@endif
