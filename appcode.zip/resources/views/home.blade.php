@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
    <p>You are logged in!</p>
    <a href="{{URL('/dashboard')}}">Click To Go To User Dashboard</a>
@stop