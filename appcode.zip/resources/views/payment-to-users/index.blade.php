@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    
<div class="container">

 
  
</div>
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing {{ucfirst(Request::path())}}</h3>
                 
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr> 
                        <th>Property</th>                       
                        <th>Shares</th>
                        <th>Unit Price</th>
                        <th>Total Amount</th>
                        <th>From User</th>
                        <th>To User</th>
                        <th>Transaction Id's</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    @if(!empty($secondaryInvestmentOffers))
                    @foreach($secondaryInvestmentOffers as $key=>$val)
                        
                        <tr>  
                        <td><a  href="{{ URL('shop/property/'.$val->property->id)}}"   target="popup" 
                            onclick="window.open('{{URL("shop/property/".$val->property->id)}}','popup','width=600,height=600'); return false;">{{ $val->property->name }}</a></td>
                            <td>{{ $val->shares}}</td>    
                            <td>{{ $val->unit_price}}</td>
                            <td>{{  number_format($val->shares*$val->unit_price) }}</td>
                        
                            <td>
                                @if(isset($val->fromUser->name))
                                    <a href="{{ URL('employee/'.$val->fromUser->id)}}">{{ $val->fromUser->name }} </a>
                                @endif
                            </td>
                            <td> 
                                @if(isset($val->toUser->name))
                                    <a href="{{ URL('employee/'.$val->toUser->id)}}">  {{ $val->toUser->name }} </a>
                                   
                                @endif
                            </td> 
                            <td >
                                @if(isset($val->fromUser->name))
                                @php 
                                  $i=0;
                                  $txnId = '';
                                @endphp
                                    <ul>
                                        @foreach($val->fromUser->gatewayTransaction($val->property_id)->get() as $trans)
                                          @if($i==0 && $trans->txn_id !='')
                                           @php 
                                            $txnId = $trans->txn_id;
                                            $i++;
                                            @endphp
                                          @endif
                                                <li style="display:inline">  {{ $trans->txn_id.',' }}</li>
                                        @endforeach
                                    <ul>      
                                @endif
                            </td>                   
                            <td>
                               @if($secondaryinvestmentOffersIds != null  && !in_array($val->id,$secondaryinvestmentOffersIds))
                                   <a class="btn btn-success" href="{{ URL('make-payment/').'?reference_id='.$val->id.'&reference_table=secondary_investment_offer&txn_id='.$txnId }}">Make Payment</a>
                               @else
                                 @php 
                                     $index = array_search($val->id,$secondaryinvestmentOffersIds);
                                     $date ='';
                                     if($index > 0){
                                       $date = date('Y-m-d',strtotime($secondaryinvestmentOffersIds[$index+1]));
                                    }
                                 @endphp
                                  <a href="#" class="btn btn-danger">Paid on ({{$date}})</a>
                               @endif
                             </td>
                        </tr>
                      @endforeach
                      @endif
                      @if(!empty($secondaryInvestmentRequest))
                      @foreach($secondaryInvestmentRequest as $key=>$val)
                        <tr>  
                            <td><a   href="{{ URL('shop/property/'.$val->property->id)}}"   target="popup" 
                                onclick="window.open('{{URL("shop/property/".$val->property->id)}}','popup','width=600,height=600'); return false;">{{ $val->property->name }}</a></td>
                                <td>{{ $val->shares}}</td>    
                                <td>{{ $val->unit_price}}</td>
                                <td>{{  number_format($val->shares*$val->unit_price) }}</td>
                                 
                                <td>
                                    @if(isset($val->fromUser->name))
                                        <a href="{{ URL('employee/'.$val->fromUser->id)}}">{{ $val->fromUser->name }} </a>
                                    @endif
                                </td>
                                <td> 
                                    @if(isset($val->fromUser->name))
                                        <a href="{{ URL('employee/'.$val->toUser->id)}}">  {{ $val->toUser->name }} </a>
                                    @endif
                                </td> 
                                <td>
                                  @if(isset($val->fromUser->name))
                                    @php 
                                      $i=0;
                                      $txnId = '';
                                    @endphp
                                        <ul>
                                            @foreach($val->fromUser->gatewayTransaction($val->property_id)->get() as $trans)
                                              @if($i==0 && $trans->txn_id !='')
                                                @php
                                                  $txnId = $trans->txn_id;
                                                  $i++;
                                                @endphp
                                              @endif
                                                    <li style="display:inline">  {{ $trans->txn_id.',' }}</li>
                                            @endforeach
                                        <ul>      
                                    @endif
                                    
                                </td>                       
                                <td>
                                  @if($secondaryinvestmentRequestIds != null  && !in_array($val->id,$secondaryinvestmentRequestIds))
                                       <a class="btn btn-success" href="{{ URL('make-payment/').'?reference_id='.$val->id.'&reference_table=secondary_investment_request&txn_id='.$txnId }}">Make Payment</a>
                                  @else
                                     @php 
                                        $index = array_search($val->id,$secondaryinvestmentRequestIds);
                                        $date ='';
                                        if($index > 0){
                                          $date = date('Y-m-d',strtotime($secondaryinvestmentRequestIds[$index+1]));
                                        }
                                     @endphp
                                     <a href="#" class="btn btn-danger">Paid on ({{$date}})</a>
                                  @endif
                              </td>
                        </tr>
                    @endforeach
                  @endif
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/employee.js') }}"></script>
@stop