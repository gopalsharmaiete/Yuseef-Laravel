@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Make Payment</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title">Make Payment</h3>
                  @if ($message = Session::get('success'))

                  <div>
                      <p>{{ $message }}</p>
                  </div>

                  @endif

                  @if ($message = Session::get('error'))

                  <div class="alert alert-error badge-danger-lighten">

                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                  <p>{{ $message }}</p></div>

                 @endif
                 @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="save" method="post" role="form" action="{{url('/add-payment')}}">               
                   {{ csrf_field()}}
                  <input type="hidden" name="refrence_id"  value="{{ $refrenceId }}" />
                  <input type="hidden" name="refrence_table"  value="{{ $refrenceTable }}" />				
                    <div class="box-body">
                            
                        <div class="form-group has-feedback {{ $errors->has('transaction_id') ? 'has-error' : '' }}">
                            <input type="text" name="transaction_id" class="form-control" value="{{ $txnId }}"  placeholder="Transaction Id" readonly required>
                           
                            @if ($errors->has('transaction_id'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('transaction_id') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group has-feedback {{ $errors->has('amount') ? 'has-error' : '' }}">
                            <input type="text" name="amount" class="form-control" value="{{ old('amount') }}"  placeholder="Amount" required>
                           
                            @if ($errors->has('amount'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('amount') }}</strong>
                                </span>
                            @endif
                        </div>

                        <div class="form-group has-feedback {{ $errors->has('remark') ? 'has-error' : '' }}">
                        <textarea name="remark" placeholder="Remark" class="form-control" required>{{ old('remark') }}</textarea>
                                
                                @if ($errors->has('remark'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('remark') }}</strong>
                                    </span>
                                @endif
                            </div>
                        
                    
                                        
                    

                    </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                 
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/employee.js') }}"></script>
@stop