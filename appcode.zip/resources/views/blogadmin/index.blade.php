@extends('adminlte::page')

@section('title', 'Melky Group')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing Blog </h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr> 
                        <th>Title</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      @foreach($Blog as $key=>$val)
                        <tr>
                          <td name="title">{{$val['title']}}</td>
                            <td name="act">
                              @if(RolesHelper::check('3','8'))
                                <a href="{{url('blogadmin/'.$val['id'].'/edit')}}" >
                                  <button type="button"  value="{{$val['id']}}">Edit</button>
                                </a><br/>
                                <form action="{{URL( 'blogadmin').'/'.$val['id'] }}" method="post">
                                   {{ csrf_field() }}
                                  @method('DELETE')
                                   <button type="submit" >Delete</button>
                                </form>
                               @endif
                            </td>
                        </tr>
                        @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/employee.js') }}"></script>
@stop