@extends('adminlte::page')

@section('title', 'Melky Group')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing {{ucfirst(Request::path())}}</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    
                      <tr>                        
                        <th>Name</th>
                        <td>{{$Employee->name}}</td>
                      </tr>
                      <tr>
                        <th>Email</th>
                        <td>{{$Employee->email}}</td>
                      </tr>  
                      <tr>
                        <th>Phone</th>
                        <td>{{$Employee->phone}}</td>
                      </tr>
                      <tr>
                        <th>Role</th>
                        <td>{{$Employee->rolename->name??'n/a'}}</td>
                      </tr>
                      <tr>
                        <th>Address</th>
                        <td>{{$Employee->address}}</td>
                      </tr>                        
                       
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/employee.js') }}"></script>
@stop