@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Update Blog</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="save" method="post" role="form" action="{{url('blogadmin/'.$Blog['id'])}}" enctype="multipart/form-data">               
                {{ csrf_field()}}
                {{ method_field('PATCH') }}					
                  <div class="box-body">
                        
                  <div class="form-group has-feedback {{ $errors->has('title') ? 'has-error' : '' }}">
                    <input type="text" name="title" class="form-control" value="{{ $Blog['title'] }}"
                           placeholder="title" required>                   
                    @if ($errors->has('title'))
                        <span class="help-block">
                            <strong>{{ $errors->first('title') }}</strong>
                        </span>
                    @endif
                </div>
                       
                <div class="form-group has-feedback {{ $errors->has('author') ? 'has-error' : '' }}">
                        <input type="text" name="author" class="form-control" value="{{ $Blog['author'] }}"
                               placeholder="title" required>                   
                        @if ($errors->has('author'))
                            <span class="help-block">
                                <strong>{{ $errors->first('author') }}</strong>
                            </span>
                        @endif
                    </div>
                <div class="form-group has-feedback {{ $errors->has('description') ? 'has-error' : '' }}">
                    <textarea name="description" class="form-control">{{ $Blog['description'] }}</textarea>
                    
                    @if ($errors->has('description'))
                        <span class="help-block">
                            <strong>{{ $errors->first('description') }}</strong>
                        </span>
                    @endif
                </div>
                              
            <div>
                <div class="col-md-6 col-sm-6 form-group has-feedback {{ $errors->has('file') ? 'has-error' : '' }}">
                <input type="file" name="file" class="form-control"  >                    
                    @if ($errors->has('file'))
                        <span class="help-block">
                            <strong>{{ $errors->first('file') }}</strong>
                        </span>
                    @endif
                </div>
                
                <div class="col-md-6 col-sm-6">
                    @if(isset($Blog->file[0]->name))                 
                          <img src="{{url('/')}}/images/blog/{{$Blog->file[0]->name}}" class="img-responsive">                        
                          <input type="hidden" name="image_id" value="{{$Blog->file[0]->id}}">
                    @endif
                </div>
          </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
@stop


@section('page_scripts')
<script src="{{ asset('js/blog.js') }}"></script>

<script src="{{ asset('js/roles.js') }}"></script>
<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> <script type="text/javascript">
//<![CDATA[
    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script>
@stop