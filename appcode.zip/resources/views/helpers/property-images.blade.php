<!-- Modal for login -->
      <div class="modal fade" id="{{$modalName}}" role="dialog">
        <div class="modal-dialog">
        
          <!-- Modal content-->
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h2>{{$heading}}</h2>
            </div>
            <div class="modal-body">
              <div class="row">
                
               
                @php $msg = 0; @endphp
                @php $msgg = 0; @endphp
                @if($imageData->where('module', $type))
                    @if($isdoc == 0)
                      @foreach($imageData as $value)
                        @if($value->module == $type)
                          <div class="col-sm-3 submitbox helper-delete-btn">
                            <img src="{{url('/')}}/{{$path}}/{{$value->name}}" class="w-100">
                              <button type="submit" class="btn btn-primary delete" data-name="{{$value->name}}" data-id="{{$value->id}}">Delete</button>
                          </div>
                            
                        @else
                          @php $msg = 1; @endphp
                        @endif
                      @endforeach
                    @else
                        <div class="detail_table">
                          <table cellpadding="0" cellspacing="0" border="0" width="100%">
                            <tbody>
                            
                              @foreach($imageData as $value)
                              @if($value->module == $type)

                              <tr>
                                <td>{{$value->title}}</td>
                                <td> 
                                <a href="{{url('/')}}/{{$path}}/{{$value->name}}" download>
                                      <span class="glyphicon glyphicon-download-alt"></span>
                                    </a>
                                </td>
                                <td><button type="submit" class="btn btn-primary delete" data-name="{{$value->name}}" data-id="{{$value->id}}">Delete</button>
                                </td>
                              </tr>
                              
                              @else
                                @php $msgg = 1; @endphp
                              @endif
                              @endforeach
                            </tbody>
                          </table>
                        </div>
                      @endif
                  
                  
                  
                  
                @else
                  <h4>No image/document associate with this property.</h4>
                @endif
                  
              </div>
            </div>
            
          </div>
          
        </div>
      </div>

@section('subpage_scripts')
<script src="{{ asset('js/bootbox.min.js') }}"></script>
<script src="{{ asset('js/userDashboard.js') }}"></script>
@stop