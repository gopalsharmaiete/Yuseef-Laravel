@extends('layouts.guest-master')
@section('frontcontent')
 
 		<section class="loginPage">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="loginForm">

							<div class="title_head">
								<h1>{{ trans('adminlte::adminlte.register_message') }}</h1>
							</div>
							<div class="innerform">
							<form action="{{ url(config('adminlte.register_url', 'register')) }}" method="post">
								{!! csrf_field() !!}

								<div class="input_row form-group has-feedback {{ $errors->has('name') ? 'has-error' : '' }}">
									<input type="text" name="name" class="fld_col" value="{{ old('name') }}"
										   placeholder="{{ trans('adminlte::adminlte.full_name') }}">
									<span class="userFld"><img src="images/userInput.png" alt="user_logo"></span>
									@if ($errors->has('name'))
										<span class="help-block">
											<strong>{{ $errors->first('name') }}</strong>
										</span>
									@endif
								</div>
								<div class="input_row form-group has-feedback {{ $errors->has('email') ? 'has-error' : '' }}">
									<input type="email" name="email" class="fld_col" value="{{ old('email') }}"
										   placeholder="{{ trans('adminlte::adminlte.email') }}">
									<span class="userFld"><img src="images/userInput.png" alt="user_logo"></span>
									@if ($errors->has('email'))
										<span class="help-block">
											<strong>{{ $errors->first('email') }}</strong>
										</span>
									@endif
								</div>
								<div class="input_row form-group has-feedback {{ $errors->has('password') ? 'has-error' : '' }}">
									<input type="password" name="password" class="fld_col"
										   placeholder="{{ trans('adminlte::adminlte.password') }}">
									<span class="userFld"><img src="images/paswrdIput.png" alt="pswrd_logo"></span>
									@if ($errors->has('password'))
										<span class="help-block">
											<strong>{{ $errors->first('password') }}</strong>
										</span>
									@endif
								</div>
								<div class="input_row form-group has-feedback {{ $errors->has('password_confirmation') ? 'has-error' : '' }}">
									<input type="password" name="password_confirmation" class="fld_col"
										   placeholder="{{ trans('adminlte::adminlte.retype_password') }}">
									<span class="userFld"><img src="images/paswrdIput.png" alt="pswrd_logo"></span>
									@if ($errors->has('password_confirmation'))
										<span class="help-block">
											<strong>{{ $errors->first('password_confirmation') }}</strong>
										</span>
									@endif
								</div>
								<div class="input_row form-group has-feedback {{ $errors->has('phone') ? 'has-error' : '' }}">
									<input type="tel" name="phone" class="fld_col" value="{{ old('phone') }}"
										   placeholder="{{ trans('form-label.phone') }}">
									<span class="userFld"><img src="images/userInput.png" alt="user_logo"></span>
									@if ($errors->has('phone'))
										<span class="help-block">
											<strong>{{ $errors->first('phone') }}</strong>
										</span>
									@endif
								</div>
								<div class="input_row form-group has-feedback {{ $errors->has('address') ? 'has-error' : '' }}">
									<input type="tel" name="address" class="fld_col" value="{{ old('address') }}"
										   placeholder="{{ trans('form-label.address') }}">
									<span class="userFld"><img src="images/userInput.png" alt="user_logo"></span>
									@if ($errors->has('address'))
										<span class="help-block">
											<strong>{{ $errors->first('address') }}</strong>
										</span>
									@endif
								</div>
								<input type="hidden" name="role" class="fld_col" value="4">
								<input type="hidden" name="user_type" class="fld_col" value="invester">
								<div class="morInfo_btn submitbtn">
								<input type="submit" class="moreB" value="{{ trans('adminlte::adminlte.register') }}">
								
								</div>
							</form>
								
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>
 
 
  @stop