@extends('layouts.guest-master')
@section('frontcontent')
 
 		<section class="loginPage">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="loginForm">
                           <div class="innerform">
                                <p class="login-box-msg">{{ trans('adminlte::adminlte.password_reset_message') }}</p>
                                @if (session('status'))
                                    <div class="alert alert-success">
                                        {{ session('status') }}
                                    </div>
                                 @endif
                            <form action="{{ url(config('adminlte.password_email_url', 'password/email')) }}" method="post">
                                {!! csrf_field() !!}
                                
                                <div class="input_row form-group has-feedback {{ $errors->has('email') ? 'has-error' : '' }}">
                                    <input type="email" name="email" class="fld_col" value="{{ isset($email) ? $email : old('email') }}"
                                        placeholder="{{ trans('adminlte::adminlte.email') }}">
                                        <span class="userFld"><img src="images/userInput.png" alt="user_logo"></span>
                                    @if ($errors->has('email'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('email') }}</strong>
                                        </span>
                                    @endif
                                </div>
                                <button type="submit"
                                        class="btn btn-primary btn-block btn-flat"
                                >{{ trans('adminlte::adminlte.send_password_reset_link') }}</button>
                            </form>
                           </div>
						</div>
					</div>
				</div>
			</div>
		</section>
 @stop