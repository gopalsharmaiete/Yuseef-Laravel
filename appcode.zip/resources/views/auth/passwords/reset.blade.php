@extends('layouts.guest-master')
@section('frontcontent')
 
 		<section class="loginPage">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="loginForm">

							<div class="title_head">
							   <h1>{{ trans('adminlte::adminlte.password_reset_message') }}</h1>
							</div>
							<div class="innerform">
							@if ($errors->has('email'))
										<span class="help-block" style="color:red">
											<strong>{{ $errors->first('email') }}</strong>
										</span>
							@endif
							@if ($errors->has('password'))
										<span class="help-block" style="color:red">
											<strong>{{ $errors->first('password') }}</strong>
										</span>
							@endif
							@if ($errors->has('password_confirmation'))
											<span class="help-block">
												<strong>{{ $errors->first('password_confirmation') }}</strong>
											</span>
							@endif
							<form  action="{{ url(config('adminlte.password_reset_url', 'password/reset')) }}" method="post">
								{!! csrf_field() !!}
								<input type="hidden" name="token" value="{{ $token }}">
								<div class="input_row form-group has-feedback {{ $errors->has('email') ? 'has-error' : '' }}">
									<input type="email" name="email" class="fld_col" value="{{ isset($email) ? $email : old('email') }}"
										placeholder="{{ trans('adminlte::adminlte.email') }}">
										<span class="userFld"><img src="{{asset('images/userInput.png')}}" alt="user_logo"></span>
                				</div>
								<div class=" input_row form-group has-feedback {{ $errors->has('password') ? 'has-error' : '' }}">
									<input type="password" name="password" class="fld_col"
										placeholder="{{ trans('adminlte::adminlte.password') }}"  >
										<span class="userFld"><img src="{{asset('images/paswrdIput.png')}}" alt="user_logo"></span>
               					 </div>
									<div class=" input_row form-group has-feedback {{ $errors->has('password_confirmation') ? 'has-error' : '' }}">
										<input type="password" name="password_confirmation" class="fld_col"
											placeholder="{{ trans('adminlte::adminlte.retype_password') }}">
											<span class="userFld"><img src="{{asset('images/paswrdIput.png')}}" alt="user_logo"></span>
									</div>
								
								<div class="morInfo_btn submitbtn">
								<button type="submit" class="btn btn-primary btn-block btn-flat" >{{ trans('adminlte::adminlte.reset_password') }}</button>
								
								</div>
							</form>
								
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>
 
 
  @stop