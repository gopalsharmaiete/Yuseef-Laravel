@extends('layouts.user-dashboard-master')
@section('frontcontent')
      

        <section class="listShop_sec">
            <!-- ShopList start html -->
            <div class="ShopList aboutList">
                <div class="container New">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="Innermelky">
                                <h2>{{ __('Verify Your Email Address') }}</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>      
            <!-- ShopList end html -->
                <div class="container New">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="bodr"></div>
                        </div>
                    </div>
                </div>            
            <!-- galryAbout start html -->
            <div class="galryAbout">
               <div class="container New">
                  <div class="row">

                      <div class="col-sm-12 col-xs-12">
                        <h3>
                          @if (session('resent'))
                        <div class="alert alert-success" role="alert">
                            {{ __('A fresh verification link has been sent to your email address.') }}
                        </div>
                    @endif

                    {{ __('Before proceeding, please check your email for a verification link.') }}
                    {{ __('If you did not receive the email') }}, <a href="{{ route('verification.resend') }}">{{ __('click here to request another') }}</a>..
                </h3>
                      </div>
                     

                  </div> 
               </div>
            </div>
            <!-- galryAbout start html -->
            
        </section>
@endsection
