@extends('layouts.guest-master')
@section('frontcontent')
 
 		<section class="loginPage">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="loginForm">

							<div class="title_head">
								<h1>{{ trans('adminlte::adminlte.login_message') }}</h1>
							</div>
							<div class="innerform">
							@if ($errors->has('email'))
										<span class="help-block" style="color:red">
											<strong>{{ $errors->first('email') }}</strong>
										</span>
							@endif
							@if ($errors->has('password'))
										<span class="help-block" style="color:red">
											<strong>{{ $errors->first('password') }}</strong>
										</span>
							@endif
							@if (Session::has('error'))
										<span class="help-block" style="color:red">
											<strong>{{ Session::get('error') }}</strong>
										</span>
							@endif
							<form action="{{ url(config('adminlte.login_url', 'login')) }}" method="post">
								{!! csrf_field() !!}
							
								<div class="input_row form-group has-feedback {{ $errors->has('email') ? 'has-error' : '' }}">
									<input type="email" name="email" class="fld_col" value="{{ old('email') }}"
										   placeholder="{{ trans('adminlte::adminlte.email') }}">
									<span class="userFld"><img src="images/userInput.png" alt="user_logo"></span>
									
								</div>
								<div class="input_row form-group has-feedback {{ $errors->has('password') ? 'has-error' : '' }}">
									<input type="password" name="password" class="fld_col"
										   placeholder="{{ trans('adminlte::adminlte.password') }}">
									<span class="userFld"><img src="images/paswrdIput.png" alt="user_logo"></span>
									
								</div>
								<div class="input_row form-group">
									<div class="checkbox icheck">
										<label>
											<input type="checkbox" name="remember"> {{ trans('adminlte::adminlte.remember_me') }}
										</label>
										<a href="{{url('/forgot-password')}}" class="forgt_pass" style="float:right">Forgotten your password?</a>
									</div>
								</div>
								
								<div class="morInfo_btn submitbtn">
								<input type="submit" class="moreB" value="{{ trans('adminlte::adminlte.sign_in') }}">
								<p><a href="{{URL('/invester-register')}}" class="signup">Sign Up</a> for new User</p>
								</div>
							</form>
								
							</div>

						</div>
					</div>
				</div>
			</div>
		</section>
 
 
  @stop