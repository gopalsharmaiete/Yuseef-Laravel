@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Contracts</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              @if(RolesHelper::check('2','13'))
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                
                <!-- Form start -->
                <form name="roleSave" method="post" role="form" action="{{url('contracts')}}" enctype="multipart/form-data">
                {{ csrf_field() }}
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Title</label>
                      <input name="title" type="text" class="form-control" id="title" placeholder="Enter Title" required>                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Description</label>
                      <input name="description" type="text" class="form-control" id="description" placeholder="Enter Description" required>                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-body">
                    <div class="form-group">
                          <select class="form-control" name='property_id' id='property_id'>
                              <option value="">Choose Proprty </option>
                              @foreach($Property as $key=>$val)
                              <option value={{$key}}>{{$val}}</option>
                              @endforeach
                          </select>
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">File</label>
                      <input name="file" type="file" class="form-control" id="file"  required>                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                <!--  End form -->
                
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->
              @endif
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Stored</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Title</th>
                       <th>Description</th>
                       <th>Property</th>
                       <th>File</th>
                        <!--<th>Actions</th>-->
                      </tr>
                    </thead>
                    <tbody>
                    @if(count($ContractsData)>0)
                    @foreach($ContractsData as $key=>$val)
                      <tr>                      
                        <td name="title">{{$val['title']}}</td>
                        <td name="description">{{$val['description']}}</td>
                        <td name="property_id">{{$Property[$val['uploadable_id']]}}</td>
                        <td name="file"><a href="{{url('/')}}/documents/contracts/{{$val['name']}}" download><i class="fa fa-download" aria-hidden="true"></i></a></td>
                        <!--<td><button type="button"  value="{{$val['id']}}" class="dtedit">Edit</button>&nbsp;<button type="button"  value="{{$val['id']}}" class="del">Delete</button></td>-->
                      </tr>
                      @endforeach
                    @endif
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/roles.js') }}"></script>
@stop