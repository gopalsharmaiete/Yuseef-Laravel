@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Assign/Remove Permission(s) To Role(s)</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
          <form name="map-role-permission" method="post" action="{{url('roles-permissions')}}"> 
                  {{ csrf_field() }}

                  <div class="box-body">
                  <div class="row">
                    <div class="col-xs-3">
                    <div class="form-group">
                          <!--<label>Role</label>-->
                          <select class="form-control" name='roles' id='roles'>
                              <option value="">Choose Role </option>
                              @foreach($roles as $key=>$val)
                              <option value={{$key}}>{{$val}}</option>
                              @endforeach
                          </select>
                      </div>
                    </div>
                    <div class="col-xs-4">
                        <div class="form-group">
                             <!--<label for="validationCustom02">Module</label>-->
                              <select class="form-control select2"  name='modules' id='modules'>
                                  <option value="">Choose Module</option>
                                    @foreach($modules as $key=>$val)
                                    <option value={{$key}}>{{$val}}</option>
                                    @endforeach
                              </select>
                          </div>
                    </div>

                    <div class="col-xs-4">
                          <div class="form-group">
                              <select class="form-control select2"  name='permission' id='permission'>
                                  <option value="">Permission Type</option>
                                    @foreach($permission as $key=>$val)
                                    <option value={{$key}}>{{$val}}</option>
                                    @endforeach
                              </select>
                          </div>
                    </div>

                    <div class="col-xs-1">
                          <div class="form-group">
                          <button class="btn btn-info btn-flat" type="submit">Go</button>                          
                          </div>
                    </div>
                  </div><!--row -->
                </div><!-- /.box-body -->
                @if ($message = Session::get('success'))
                    <div>
                        <p>{{ $message }}</p>
                   </div>
                    @endif

                    @if($errors->any())
                    <label class="control-label" for="inputError"><i class="fas fa-fw fa-times-circle-o"></i>{{$errors->first()}}</label>
                    @endif
        </form>						

              
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Stored Roles</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Role Name</th>
                        <th>Permission Name</th>
                        <th>Module Name</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($RolesPermissions as $key=>$val)
                      <tr>
                        <td>{{$loop->iteration}}</td>                      
                        <td name="role_id">{{$roles[$val['role_id']]}}</td>
                        <td name="permission_id">{{$permission[$val['permission_id']]}}</td>
                        <td name="module_id">{{$modules[$val['module_id']]}}</td>
                        <td><button type="button"  value="{{$val['id']}}" class="del">Delete</button></td>
                      </tr>
                      @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script type="text/javascript">
$(document).ready(function(){  

  $("#example1").dataTable();


});

$(document).ready(function () {
      $('.del').click(function () {
           var sid = $(this).val();
           var pdata = {"_token":"{{ csrf_token() }}"};
                      $.ajax({
                          type:"DELETE",
                          url:"roles-permissions/"+sid,
                          data: pdata,
                          success: function (data, status, xhr) {// success callback function
                        alert("Deleted Successfully");
                        location.reload();
                        }
                          
                      });
           });
  });

</script>
@stop