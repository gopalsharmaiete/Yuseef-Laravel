@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Email Templates</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              @if(RolesHelper::check('2','7'))
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="templateSave" method="POST" role="form" action="{{url('mailtemplate')}}">
                {{ csrf_field() }}
                <div class="box-body">
                    <div class="form-group">
                      <label>Template Title : </label>
                      <input type="text" name="title" value="" required>
                    </div>
                </div>
                 
                 
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Define Email Templates</label>
                      <textarea name="description" rows="10" cols="150"></textarea>                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->
              @endif
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Stored </h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th> Name</th>
                       <!-- <th>Assigned Value</th>-->
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($Mailtemplate as $key=>$val)
                      <tr>                      
                        <td name="title">{{$val['title']}}</td>
                        <!-- <td name="value">{{$val['value']}}</td>-->
                        <td>@if(RolesHelper::check('3','7'))<a href="{{url('mailtemplate/'.$val['id'].'/edit')}}" ><button type="button"  value="{{$val['id']}}">Edit</button></a>@endif<!--&nbsp;<button type="button"  value="{{$val['id']}}" class="del">Delete</button>--></td>
                      </tr>
                      @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/roles.js') }}"></script>
<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> <script type="text/javascript">
//<![CDATA[
    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script>
@stop