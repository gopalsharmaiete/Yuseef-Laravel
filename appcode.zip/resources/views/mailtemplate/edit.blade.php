@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Email Templates</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="templateSave" method="POST" role="form" action="{{url('mailtemplate/'.$EditMailtemplate['id'])}}">
                {{ csrf_field() }}
                {{ method_field('PATCH') }}
                <div class="box-body">
                    <div class="form-group">
                      <label>Template Title : </label>
                      <input type="text" name="title" value="{{$EditMailtemplate['title']}}" required>
                    </div>
                </div>
                 
                 
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Define Email Templates</label>
                      <textarea name="description" rows="10" cols="150">{{$EditMailtemplate['description']}}</textarea>                      
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/roles.js') }}"></script>
<script type="text/javascript" src="http://js.nicedit.com/nicEdit-latest.js"></script> <script type="text/javascript">
//<![CDATA[
    bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
  </script>
@stop