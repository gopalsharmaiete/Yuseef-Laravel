@component('mail::message')

<h4>Hello!<h4>
<p>Please click the button below to verify your email address.</p>

@component('mail::button', ['url' => $url])
Verify Email
@endcomponent

<p>If you did not create an account, no further action is required.</p>
Regards,<br>
{{ config('app.name') }}

@endcomponent