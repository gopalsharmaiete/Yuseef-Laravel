@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Permission</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="roleSave" method="post" role="form" action="{{url('permissions')}}">
                {{ csrf_field() }}
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Add new Permission by entering name</label>
                      <input name="name" type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Permission Name" required>
                      <input name="value" type="hidden" class="form-control" id="exampleInput" placeholder="Enter Permission id" value="{{$rolesData->max->value +1}}">
                    </div>
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Stored Permission(s)</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>Permission Name</th>
                       <!-- <th>Assigned Value</th>-->
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($rolesData as $key=>$val)
                      <tr>                      
                        <td name="name">{{$val['name']}}</td>
                        <!--<td name="value">{{$val['value']}}</td>-->
                        <td><button type="button"  value="{{$val['id']}}" class="dtedit">Edit</button>&nbsp;<button type="button"  value="{{$val['id']}}" class="del">Delete</button></td>
                       </tr>
                      @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->


          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/permission.js') }}"></script>
@stop