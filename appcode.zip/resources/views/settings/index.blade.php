@extends('adminlte::page')

@section('title', 'Melky')

@section('content_header')
    <h1>Stored</h1>
@stop

@section('content')
  <div class="container">
  <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
      <div class="modal-dialog">
      
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-body">
          <div class="row">
              <div class="col-md-12">
                 
              </div>
          </div>
          </div>
        </div>
        
      </div>
    </div>
    
  </div>   

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                   <h3 class="box-title">Settings </h3>
                  <!-- Trigger the modal with a button -->
				          </div><!-- /.box-header -->
                <div class="box-body">
                    <div class="box box-widget">
                    <form action="{{ URL('/settings/update') }}" method="post">
                            {{ csrf_field() }}
                              <div class="form-group has-feedback {{ $errors->has($Settings[0]->setting_type) ? 'has-error' : '' }}">
                                <label>Language Show/Hide Toggle Settings</label>
                                <label class="">
                                 
                                  <div class="iradio_flat-green checked" aria-checked="true" aria-disabled="false" style="position: relative;">
                                      ON <input type="radio" name="{{ $Settings[0]->setting_type }}" class="flat-red"  value="1" {{ ($Settings[0]->value == 1) ? 'checked':'' }} >
                                      <ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;">
                                        </ins>
                                    </div>
                                </label>
                                <label class="">
                                 
                                  <div class="iradio_flat-green" aria-checked="false" aria-disabled="false" style="position: relative;">
                                      Off  <input type="radio" name="{{ $Settings[0]->setting_type }}" class="flat-red"  value="0" {{ ($Settings[0]->value == 0) ? 'checked':'' }} >
                                    <ins class="iCheck-helper" style="position: absolute; top: 0%; left: 0%; display: block; width: 100%; height: 100%; margin: 0px; padding: 0px; background: rgb(255, 255, 255); border: 0px; opacity: 0;"></ins>
                                  </div>
                                </label>
                                
                                  @if ($errors->has($Settings[0]->setting_type))
                                    <span class="help-block">
                                        <strong>{{ $errors->first($Settings[0]->setting_type) }}</strong>
                                    </span>
                                @endif
                          </div>

                          <div class="box-footer">
                            <input type="submit"  name="submit" class="btn btn-primary" />
                          </div>

                        
                        </form>
                    </div>
                 </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
 
@stop

@section('page_scripts')

<script src="{{ asset('js/forms.js') }}"></script>
@stop