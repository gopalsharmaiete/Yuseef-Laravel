@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>{{ucfirst(Request::path())}}</h1>
@stop

@section('content')
    
	<div class="container">
	<!-- Modal -->
		<div class="modal fade" id="myModal" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-default">
									<div class="panel-heading">CSV Import<button type="button" class="close" data-dismiss="modal">&times;</button></div>
									<div class="panel-body">
										<form class="form-horizontal" method="post" action="{{ URL('property/import-property') }}" enctype="multipart/form-data">
										{{ csrf_field() }}
											<div class="form-group{{ $errors->has('csv_file') ? ' has-error' : '' }}">
												<label for="csv_file" class="col-md-4 control-label">CSV file to import</label>
												<div class="col-md-6">
												<input id="csv_file" type="file" class="form-control" name="csv_file">

												@if ($errors->has('csv_file'))
												<span class="help-block">
												<strong>{{ $errors->first('csv_file') }}</strong>
												</span>
												@endif
												</div>
											</div>
											<div class="form-group">
												<div class="col-md-8 col-md-offset-4">
													<input type="submit" class="btn btn-primary" value="Upload CSV" name="submit"/>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
               
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
              </div><!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Existing {{ucfirst(Request::path())}}</h3>
				   <button type="button" class="btn btn-info btn-primary pull-right" data-toggle="modal" data-target="#myModal">Import CSV</button>
				  <span class="samplecsv" style= "float: right;font-weight: bold; padding: 9px 14px 0px 0px;"><a href="downloadsample/property.csv">Download Sample</a></span>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>                        
                        <th>Name</th>
                        <th>Country</th>
                        <th>Landmark</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Added by</th>
                        <th>Created At</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach($Property as $key=>$val)
                      <tr>                      
                        <td name="name">{{$val['name']}}</td>
                        <td name="countryname">{{$val['countryname']->name??'n/a'}}</td>
                        <td name="landmark">{{$val['landmark']}}</td>
                        <td name="description">{{$val['description']}}</td>
                        <td name="price">{{$val['base_price']}}</td>                        
                        <td><a href="{{url('/employee').'/'.$val['created_by']}}">{{$val->user->name}}</a></td>
                        <td name="created_at">{{$val['created_at']}}</td>                        
                        <td>
                          @if($val['status'] == 1)
                             <a href="{{  URL('/property/toggle/'.$val['id']) }}" class="badge btn-success">Disable</a>
                          @else
                            <a href="{{  URL('/property/toggle/'.$val['id']) }}" class="badge  btn-danger">Enable</a>
                           @endif
                          <a href="{{URL('/dashboard/property/edit/'.$val['id'])}}" class="badge btn-warning" target="popup" onclick="window.open('{{URL('/dashboard/property/edit/'.$val['id'])}}','popup','width=600,height=600'); return false;">Edit</a>
                          <!--<button type="button"  value="{{$val['id']}}" class="edit">Edit</button><button type="button"  value="{{$val['id']}}" class="dtedit">Edit</button>&nbsp;<button type="button"  value="{{$val['id']}}" class="del">Disable</button>-->
                        </td>
                       </tr>
                      @endforeach
                      
                    </tbody>                   
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/property.js') }}"></script>
@stop