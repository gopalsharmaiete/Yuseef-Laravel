@extends('adminlte::page')

@section('title', 'PropApp')

@section('content_header')
    <h1>Add Property</h1>
@stop

@section('content')
    

   <!-- Main content -->
   <section class="content">
          <div class="row">
            <!-- left column -->
            <div class="col-md-12">
              <!-- general form elements -->
              <div class="box box-primary">
                <div class="box-header">
                  <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form name="save" method="post" role="form" action="{{url('property/')}}" enctype="multipart/form-data">               
                {{ csrf_field()}}
									
                  <div class="box-body">
                        
                  <div class="form-group has-feedback {{ $errors->has('name') ? 'has-error' : '' }}">
                    <input type="text" name="name" class="form-control" value="{{ old('name') }}"
                           placeholder="name" required>
                    
                    @if ($errors->has('name'))
                        <span class="help-block">
                            <strong>{{ $errors->first('name') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="form-group has-feedback {{ $errors->has('description') ? 'has-error' : '' }}">
                    <input type="text" name="description" class="form-control" value="{{ old('description') }}"
                           placeholder="description" required|email>
                   
                    @if ($errors->has('description'))
                        <span class="help-block">
                            <strong>{{ $errors->first('description') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="form-group has-feedback {{ $errors->has('base_price') ? 'has-error' : '' }}">
                    <input type="text" name="base_price" class="form-control"
                           placeholder="base price" required>
                  
                    @if ($errors->has('base_price'))
                        <span class="help-block">
                            <strong>{{ $errors->first('base_price') }}</strong>
                        </span>
                    @endif
                </div>        

                <div class="form-group has-feedback {{ $errors->has('landmark') ? 'has-error' : '' }}">
                    <input type="text" name="landmark" class="form-control"
                           placeholder="landmark" required>
                  
                    @if ($errors->has('landmark'))
                        <span class="help-block">
                            <strong>{{ $errors->first('landmark') }}</strong>
                        </span>
                    @endif
                </div>                        
                
                <div class="form-group">
                    <!--<label>Role</label>-->
                    <select class="form-control" name='country' id='country'>
                        <option value="">Choose Country </option>
                        @foreach($country as $key=>$val)
                        <option  value={{$key}} >{{$val}}</option>
                        @endforeach
                    </select>
                </div>

                
                <div class="form-group has-feedback {{ $errors->has('end_date') ? 'has-error' : '' }}">  
                    <input type="text" name="end_date" id="end_date"  class="form-control"
                           placeholder="end date" autocomplete="off" required>
                  
                    @if ($errors->has('end_date'))
                        <span class="help-block">
                            <strong>{{ $errors->first('end_date') }}</strong>
                        </span>
                    @endif
                </div>                        
                

                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>
                @if ($message = Session::get('success'))

                    <div>
                        <p>{{ $message }}</p>
                    </div>

                    @endif

                    @if ($message = Session::get('error'))

                    <div class="alert alert-error badge-danger-lighten">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>

                    <p>{{ $message }}</p></div>

                    @endif
          </div>
       </div>
    </section>
@stop

@section('page_scripts')
<script src="{{ asset('js/employee.js') }}"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">  
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
  $( function() {
    $( "#end_date" ).datepicker({ dateFormat: 'yy-mm-dd' });
  } );
  </script>
@stop