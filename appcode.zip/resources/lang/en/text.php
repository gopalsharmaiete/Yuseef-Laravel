<?php

return $data = \App\Models\Multilingual::where(['locale'=>'en','status'=>'1','group'=>'text'])->pluck('description','label');
