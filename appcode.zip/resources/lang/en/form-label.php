<?php

return $data = \App\Models\Multilingual::where(['locale'=>'en','status'=>'1','group'=>'form-label'])->pluck('description','label');
