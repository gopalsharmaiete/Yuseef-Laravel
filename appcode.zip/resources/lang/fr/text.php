<?php

return $data = \App\Models\Multilingual::where(['locale'=>'fr','status'=>'1','group'=>'text'])->pluck('description','label');
