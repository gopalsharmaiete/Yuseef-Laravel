<?php

return $data = \App\Models\Multilingual::where(['locale'=>'fr','status'=>'1','group'=>'prop-amenities-form'])->pluck('description','label');
