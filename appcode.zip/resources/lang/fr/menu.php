<?php
return $data = \App\Models\Multilingual::where(['locale'=>'fr','status'=>'1','group'=>'menu'])->pluck('description','label');
/*return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    /*'home' => 'Accueil',
    'shop' => 'Boutique',
    'secondary_market' => 'Secondary Market',
    'my_equity' => 'My Equity',
    'real_estate' => 'Real Estate',
    'investment' => 'Investment',
    'education' => 'Education',
    'become_a_investor' => 'Become a Investor',
    'login_account' => 'Login Account',
    'create_account' => 'Create Account',
];*/
