<?php

$vendor_code = "250215386771";
$date_time = date("Y-m-d h:m:s");
$HASH = LEN($vendor_code)+$vendor_code+LEN($date_time)+$date_time;


$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://api.2checkout.com/rest/5.0/orders/");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_HEADER, FALSE);

curl_setopt($ch, CURLOPT_POST, TRUE);

curl_setopt($ch, CURLOPT_POSTFIELDS, "{
  \"Currency\": \"usd\",
  \"Language\": \"en\",
  \"Country\": \"us\",
  \"CustomerIP\": \"91.220.121.21\",
  \"Source\": \"testAPI.com\",
  \"ExternalReference\": \"REST_API_AVANGTE\",
  \"Items\": [
    {
      \"Code\": null,
      \"Quantity\": \"1\",
      \"IsDynamic\": true,
      \"Tangible\": false,
      \"PurchaseType\": \"PRODUCT\",
      \"Price\": {
        \"Amount\": \"100\",
        \"Type\": \"CUSTOM\"
      },
      \"Name\": \"Dynamic product\",
      \"Description\": \"Test description\",
      \"PriceOptions\": [
        {
          \"Name\": \"Price option 1\",
          \"Value\": \"Price option value 1\",
          \"Surcharge\": \"100\"
        }
      ],
      \"RecurringOptions\": {
        \"CycleLength\": 1,
        \"CycleUnit\": \"MONTH\",
        \"CycleAmount\": 444,
        \"ContractLength\": 4,
        \"ContractUnit\": \"YEAR\"
      }
    },
    {
      \"IsDynamic\": true,
      \"Quantity\": \"1\",
      \"PurchaseType\": \"SHIPPING\",
      \"Price\": {
        \"Amount\": \"20\"
      },
      \"Name\": \"Shipping item\"
    },
    {
      \"IsDynamic\": true,
      \"Quantity\": \"1\",
      \"PurchaseType\": \"TAX\",
      \"Price\": {
        \"Amount\": \"10\"
      },
      \"Name\": \"Tax item\",
      \"RecurringOptions\": {
        \"CycleLength\": 1,
        \"CycleUnit\": \"MONTH\",
        \"CycleAmount\": 12,
        \"ContractLength\": 4,
        \"ContractUnit\": \"YEAR\"
      }
    },
    {
      \"IsDynamic\": true,
      \"Quantity\": \"1\",
      \"PurchaseType\": \"COUPON\",
      \"Price\": {
        \"Amount\": \"50\"
      },
      \"Name\": \"Discount item\"
    }
  ],
  \"BillingDetails\": {
    \"Address1\": \"Test Address\",
    \"City\": \"LA\",
    \"State\": \"California\",
    \"CountryCode\": \"US\",
    \"Email\": \"testcustomer@2Checkout.com\",
    \"FirstName\": \"Customer\",
    \"LastName\": \"2Checkout\",
    \"Zip\": \"12345\"
  },
  \"PaymentDetails\": {
    \"Type\": \"CC\",
    \"Currency\": \"USD\",
    \"CustomerIP\": \"91.220.121.21\",
    \"PaymentMethod\": {
      \"CardNumber\": \"4111111111111111\",
      \"CardType\": \"VISA\",
      \"ExpirationYear\": \"2018\",
      \"ExpirationMonth\": \"12\",
      \"CCID\": \"123\",
      \"HolderName\": \"John Doe\",
      \"RecurringEnabled\": true,
      \"HolderNameTime\": \"12\",
      \"CardNumberTime\": \"12\",
      \"Vendor3DSReturnURL\": \"http://myreturnurl.com\",
      \"Vendor3DSCancelURL\": \"http://cancelurl.com\"
    }
  }
}");

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  "Content-Type: application/json",
  "Accept: application/json",
  "VENDOR_CODE": $vendor_code,
  "REQUEST_DATE_TIME": $date_time,
  "HASH": $HASH
));

$response = curl_exec($ch);
curl_close($ch);

var_dump($response);