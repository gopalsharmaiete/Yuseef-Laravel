<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Setting language variable*/
Route::get('locale/{locale}', function ($locale){
    Session::put('locale', $locale);
    return redirect()->back();
});





/*Setting routes to localization*/
Route::group(['middleware' => 'Localization'], function () {

   Route::get('/', 'HomeController@welcome')->name('welcome');
   Route::get('/shop','HomeController@shop')->name('shop');
   Route::get('/shop/load','HomeController@shopload');
   Route::get('/secondary/load','HomeController@secondaryload');
   Route::get('/secondary-offer/load','HomeController@secondaryOfferLoad');
   Route::get('/invester-register','HomeController@register')->name('register');
   Route::get('/user-login','HomeController@login')->name('userlogin');
   Route::get('/forgot-password','HomeController@forgotPassword')->name('forgotPassword');
   Route::get('/shop/property/{id}', 'HomeController@propertyDetail');   
   Route::get('/shop/secondary-property/{id}', 'HomeController@SecondarypropertyDetail');  
   Route::get('/shop/secondary-offer-property/{id}', 'HomeController@SecondaryOfferpropertyDetail');  
   Route::get('/about-us', 'PageController@about');
   Route::get('/contact-us', 'PageController@contact');
   Route::get('/benefit', 'PageController@benefit');
   Route::get('/faq', 'PageController@faq');
   Route::get('/meet-the-team', 'PageController@meetTheTeam');
   Route::get('/price-guide', 'PageController@priceGuide');
   Route::get('/real-estate-education', 'PageController@realEstateEducation');
   Route::get('/testimonials', 'PageController@testimonials');
   Route::post('/contact-us', 'PageController@SendContactMail');
   Route::post('/investment/blogadmin', 'InvestCheckoutController@index');
   Route::post('/investment/confirm', 'InvestCheckoutController@index');
   Route::any('/investment/checkout', 'InvestCheckoutController@checkout');
   Route::any('/gateway-return', 'InvestCheckoutController@GatewayReturn');
   Route::any('/secondary-gateway-return', 'InvestCheckoutController@SecondaryGatewayReturn');

   Route::get('/stripe', 'InvestCheckoutController@stripe');
   Route::post('/stripe-pay', 'InvestCheckoutController@stripePost')->name('stripe-pay');
   Route::get('/braintree', 'InvestCheckoutController@braintree')->name('braintree-pay');
   Route::get('/braintree-pay', 'InvestCheckoutController@braintreePay')->name('braintree-pay');
   Route::post('/investment/paymentgateway', 'InvestCheckoutController@selectGateway');
   Route::post('/investment/finalCheckout', 'InvestCheckoutController@finalCheckout');
   Route::get('/gateway-transfer/{id}', 'InvestCheckoutController@GatewayTransfer');
    // Route::get('/investment/finalCheckout', 'InvestCheckoutController@finalCheckout');
    Route::post('/investment/loginajax', 'InvestCheckoutController@loginAjax');
    Route::any('/investment/ValidateEmail', 'InvestCheckoutController@ValidateEmail');
    Route::any('/payment/success', 'InvestCheckoutController@paymentSuccess');
    Route::any('/payment/wire-transfer', 'InvestCheckoutController@wireTransfer');
    Route::any('/save-wire-reference', 'InvestCheckoutController@saveWireReference');	  
   Route::get('/secondary-marketing','HomeController@secondaryMarketing')->name('secondary-marketing');
   Route::get('/secondary-marketing-offers','HomeController@secondaryOffers')->name('secondaryOffers');
   Route::post('/secondary-investment/proceed','InvestCheckoutController@ProceesSecondaryInvestment');   
});

Auth::routes(['verify' => true]);

Route::post('/login', [
    'uses'          => 'Auth\LoginController@login',
    'middleware'    => 'checkstatus',
]);
Route::group(['middleware' => ['Localization', 'auth', 'verified']], function () {
  Route::get('/dashboard', 'UserDashboardController@index');
  Route::get('/dashboard/property/create', 'UserDashboardController@addProperty');
  Route::post('/dashboard/property/save', 'UserDashboardController@saveProperty');
  Route::get('/dashboard/property/edit/{id}', 'UserDashboardController@propertyEdit');
  Route::post('/dashboard/property/SaveUpdateProperty', 'UserDashboardController@SaveUpdateProperty');
  Route::get('/dashboard/pending-transactions', 'UserDashboardController@pendingTransactions');
  Route::post('/deletefile', 'UserDashboardController@deleteFiles');
  Route::get('/dashboard/settings/{id}', 'UserDashboardController@userSettings');
  Route::any('/dashboard/paymentinfo/{id?}', 'UserDashboardController@paymentInfo');
  Route::post('/dashboard/paymentinfo/update/{id}', 'UserDashboardController@updatePaymentInfo');
  Route::get('/dashboard/secondary-market','UserDashboardController@SecondaryMarketDashboard');
  Route::get('/AcceptSharesAjax','UserDashboardController@SecondaryMarketAcceptAjax');
  Route::get('/RejectSharesAjax','UserDashboardController@SecondaryMarketRejectAjax'); 
  Route::get('/CounterBidAjax','UserDashboardController@CounterBidAjax'); 
  Route::post('/dashboard/secondary-market/shares-bid','UserDashboardController@SharesBid'); 
  Route::post('/dashboard/secondary-market/shares-bid-main','UserDashboardController@SharesBidMain'); 
  Route::any('/dashboard/secondary-market/final-payment/{id}','InvestCheckoutController@SecondaryFinalPayment'); 
  Route::get('/dashboard/transaction','UserDashboardController@transaction'); 
  Route::any('/pmb', 'PmbController@index');
  Route::get('/pmb/chat', 'PmbController@show');
  Route::post('/pmb/save', 'PmbController@store');
  Route::get('/dashboard/transfer', 'UserDashboardController@transfer');
  Route::get('/dashboard/place-bids', 'UserDashboardController@placeBids');    
  Route::get('/notificationmarkread', 'UserDashboardController@NotificationRead');
});



Route::get('/blog-load','BlogController@blogload');
Route::Resource('/blog', 'BlogController');


//**********  Admin Panel Routes  *******************

Route::get('/home', 'HomeController@index')->name('home');

Route::Resource('/roles', 'RolesController');

Route::Resource('/permissions', 'PermissionController');

Route::Resource('/roles-permissions', 'MapRolesPermissions');

Route::Resource('/employee', 'EmployeeController');
Route::post('/employee/store', 'EmployeeController@store');

Route::Resource('/investor', 'EmployeeController');

Route::Resource('/entrepreneur', 'EmployeeController');

Route::Resource('/mailtemplate', 'MailtemplateController');

Route::Resource('/cms', 'CmsController');

Route::Resource('/property', 'PropertyController');

Route::Resource('/multilingual', 'MultilingualsController');

Route::Resource('/contracts', 'ContractsController');

Route::Resource('/forms', 'FormsController');

Route::get('/about-us-images', 'PageController@aboutAdmin');
Route::get('/real-estate-education-images', 'PageController@realEstateEducationAdmin');
Route::get('/benefit-images', 'PageController@benefitAdmin');

Route::post('/admin/images/save', 'PageController@saveImages');

Route::get('/investment-history','InvestmentsAdminController@InvestmentHistory');
Route::get('/investments-pending','InvestmentsAdminController@InvestmentPending');
Route::get('/commission-percentage','InvestmentsAdminController@CommissionPercentage');
Route::post('/set-commission-percentage','InvestmentsAdminController@SetCommissionPercentage');
Route::Resource('/blogadmin','BlogAdminController');
Route::post('/update-investment-status','InvestmentsAdminController@UpdateInvestmentStatus');
Route::any('/dashboard/refer-a-friend', 'UserDashboardController@referfriend');
Route::get('/dashboard/notification', 'UserDashboardController@notification');
Route::post('/multilingual/importdata', 'MultilingualsController@importdata')->name('importdata');
Route::get('form/sample-csv', 'FormsController@sampleCSV');
Route::post('/form/importdata', 'FormsController@importData');
Route::post('/employee/importdata', 'EmployeeController@importData');
Route::post('/property/import-property', 'PropertyController@importproperty');
Route::get('/settings','SettingsController@index');
Route::post('/settings/update','SettingsController@update');
Route::get('/property/toggle/{id}', 'PropertyController@toggle');
Route::get('/employee/toggle/{id}', 'EmployeeController@toggle');
Route::get('/payment-to-users', 'PaymentToUsersController@index');
Route::get('/make-payment', 'PaymentToUsersController@show');
Route::post('/add-payment', 'PaymentToUsersController@store');
Route::get('/pending-failed-payments', 'InvestmentsAdminController@failedPayment');
Route::get('/failed-payments/status/{id}', 'InvestmentsAdminController@failedStatusChange');
//************* End Admin Controller *******************

Route::post('/type/{imagetype}', function ($imagetype){
    Session::put('type', $imagetype);
    return redirect()->back();
});



Route::put('/items/sort',       'MainController@sortItems');
Route::post('/validateToken',   'MainController@validateToken');

Route::resource('/items',       'MainController');

Route::get('/message', function () {
    return view('frontend/pusher-message');
});