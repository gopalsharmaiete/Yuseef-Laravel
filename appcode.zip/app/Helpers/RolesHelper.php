<?php
namespace App\Helpers;
use App\User;
use App\Models\RolesPermissions;
use Auth;
class RolesHelper {

public static function check($type='',$module_id=''){
  if($type!='' && $module_id!=''){
  $role_name = Auth::user()->role;
  
    if($role_name=='1')
    {
      return 'administrator';
    }

    if($type=='all' && $module_id=='all')
    {
      return 'all';
    }

	    return $res = RolesPermissions::where([['role_id',$role_name],['permission_id',$type],['module_id',trim($module_id)]])->first();
      
}
  return false;
} 



}

?>