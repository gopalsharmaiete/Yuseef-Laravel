<?php
namespace App\Helpers;
use App\User;
use App\Models\GatewayTransaction;
use Auth;
use App\functions\checkoutphpmaster\lib\Twocheckout;
use App\functions\checkoutphpmaster\lib\Twocheckout\Twocheckout_Charge;

class GatewayHelper {

public static function paymentInfo($request=''){
  if($request!=''){
      // Card info
            $user_id = Auth::id();  
            $card_num = $request->card_num;
            $card_cvv = $request->cvv;
            $card_exp_month = $request->exp_month;
            $card_exp_year = $request->exp_year;
            
            // Buyer info
            $name = $request->name;
            $email = $request->email;
            $phoneNumber = '555-555-5555';
            $addrLine1 = $request->address;
            /*$city = 'Columbus';
            $state = 'OH';
            $zipCode = '43123';
            $country = 'USA';*/
            
            // Item info
            $itemName = $request->property_name;
            $itemNumber = $request->property_id;
            $itemPrice = $request->amount;
            $currency = 'USD';

            $latestOrder = GatewayTransaction::orderBy('created_at','DESC')->first();
            if($latestOrder){
              $orderID = '#'.str_pad($latestOrder->id + 1, 8, "0", STR_PAD_LEFT);
            }
            else{
              $orderID = '#'.str_pad(1, 8, "0", STR_PAD_LEFT);;
            }
            
            $privateKey = Twocheckout::privateKey('C656E7AB-3061-49CF-9DA3-91CA432B1F2D');
            Twocheckout::sellerId('901414359');
            Twocheckout::sandbox(true);
            Twocheckout::verifySSL(false);
           
            
            try {
                // Charge a credit card
                $charge = Twocheckout_Charge::auth(array(
                    "merchantOrderId" => $orderID,
                    "token"      => $request->token,
                    "currency"   => $currency,
                    "total"      => $itemPrice,
                    "billingAddr" => array(
                        "name" => $name,
                        "addrLine1" => $addrLine1,
                        "city" => '',
                        "state" => '',
                        "zipCode" => '',
                        "country" => '',
                        "email" => $email,
                        "phoneNumber" => $phoneNumber
                    )
                ));

                $orderData['user_id'] = $user_id;
                $orderData['card_num'] = $card_num;
                $orderData['card_cvv'] = $card_cvv;
                $orderData['card_exp_month'] = $card_exp_month;
                $orderData['card_exp_year'] = $card_exp_year;
                $orderData['property_id'] = $itemNumber;
                $orderData['amount'] = $charge['response']['total'];
                $orderData['currency'] = $charge['response']['currencyCode'];
                $orderData['order_number'] = $charge['response']['orderNumber'];
                $orderData['txn_id'] = $charge['response']['transactionId'];
                $orderData['payment_status'] = $charge['response']['responseCode']??'PENDING';
                $orderData['payment_status_code'] = '';
                $orderData['created_at'] = date('Y-m-d H:i:s');

                
                // Check whether the charge is successful
                if ($charge['response']['responseCode'] == 'APPROVED') {
                    
                    // Order details
                    $orderNumber = $charge['response']['orderNumber'];
                    $total = $charge['response']['total'];
                    $transactionId = $charge['response']['transactionId'];
                    $currency = $charge['response']['currencyCode'];
                    $status = $charge['response']['responseCode'];
                    
                    $orderData['amount'] = $charge['response']['total'];
                    $orderData['currency'] = $charge['response']['currencyCode'];
                    $orderData['order_number'] = $charge['response']['orderNumber'];
                    $orderData['txn_id'] = $charge['response']['transactionId'];
                    $orderData['payment_status'] = $charge['response']['responseCode']??'PENDING';

                    
                    $statusMsg = '<h2>Thanks for your Order!</h2>';
                    $statusMsg .= '<h4>The transaction was successful. Order details are given below:</h4>';
                    $statusMsg .= "<p>Order ID: {$insert_id}</p>";
                    $statusMsg .= "<p>Order Number: {$orderNumber}</p>";
                    $statusMsg .= "<p>Transaction ID: {$transactionId}</p>";
                    $statusMsg .= "<p>Order Total: {$total} {$currency}</p>";
                     $res = $statusMsg;
                     
                      $response = GatewayTransaction::create($orderData);
                      return $res;
                }
            } catch (Twocheckout_Error $e) {
                 $orderData['user_id'] = $user_id;
                $orderData['card_num'] = $card_num;
                $orderData['card_cvv'] = $card_cvv;
                $orderData['card_exp_month'] = $card_exp_month;
                $orderData['card_exp_year'] = $card_exp_year;
                $orderData['property_id'] = $itemNumber;
                $orderData['amount'] = $itemPrice;
                $orderData['currency'] = $currency;
                $orderData['order_number'] = $orderID;
                $orderData['txn_id'] = '';
                $orderData['payment_status'] = 'FAILED';
                $orderData['payment_status_code'] = '';
                $orderData['created_at'] = date('Y-m-d H:i:s');


                $response = GatewayTransaction::create($orderData);
                $statusMsg = '<h2>Transaction failed!</h2>';
                $statusMsg .= '<p>'.$e->getMessage().'</p>';
               return $res = $statusMsg;
            }

    	  } 
    return false;
  } 



}

?>