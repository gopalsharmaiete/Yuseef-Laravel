<?php
namespace App\Helpers;
use App\User;
use App\Models\Mailtemplate;
use App\Models\Employee;
use Auth;
use Mail;

class TemplateHelper {

public static function SendMailTemplate($tempalte_id='',$mails_to=[],$mails_cc=[],$constant_to='',$constant_cc='',$data=[],$logo=0){
  if($tempalte_id!=''){

   
   $main_content = Mailtemplate::where([['status','1'],['id',$tempalte_id]])->first();

   $mail_body = $main_content['description'];

   $to  = env('ADMINEMAIL');

   if(!empty($mails_to))
   {
     foreach($mails_to as $uid=>$to)
     {

      $muser = Employee::where('id',$uid)->get()->toArray();
   
      $mail_body = $main_content['description'];
      foreach($muser[0] as $key => $value){
       $mail_body = str_replace('{'.strtoupper($key).'}', $value, $mail_body);
       }

       if(count($data)>0){
         foreach($data as $key=>$value){
          $mail_body = str_replace('{'.strtoupper($key).'}', $value, $mail_body);   
         }
       }
        if($logo!=0){
          $mail_body.="<img src='".url('images/mail-logo.jpeg')."' />";
        }
       $responce = Mail::send(array(),array(), function($message) use ($main_content,$mail_body,$to) {             
        $message->to($to, $to)->subject($main_content['title']);
        $message->from('noreply@melkygroup.com', 'Melky Group')->setBody($mail_body, 'text/html');;
        });  
      }
   }

   if($constant_to!=''){
      $to = $constant_to;
      $mail_body = $main_content['description'];
      
      if(count($data)>0){
          foreach($data as $key=>$value){
          $mail_body = str_replace('{'.strtoupper($key).'}', $value, $mail_body);   
          }
        }
        if($logo!=0){
          $mail_body.="<img src='".url('images/mail-logo.jpeg')."' />>";
        }

        $responce = Mail::send(array(),array(), function($message) use ($main_content,$mail_body,$to) {             
        $message->to($to, $to)->subject($main_content['title']);
        $message->from('noreply@melkygroup.com', 'Melky Group')->setBody($mail_body, 'text/html');;
        });
    
    }

    return $responce;
}
  return false;
} 


}

?>