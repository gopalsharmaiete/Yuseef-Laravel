<?php
namespace App\Helpers;
use App\User;
use App\Models\Upload;
use Auth;

class ImagesHelper {

public static function upload($id='',$requestedImage, $path='', $uploadable_id='', $module='', $uploadable_type='', $title='', $description=''){
  if($requestedImage!=''){

      $user_id = Auth::id();  
      $imageName = time().'-'.$requestedImage->getClientOriginalName();
      $extension = $requestedImage->getClientOriginalExtension();
      $size = $requestedImage->getSize();
    
        if($size > (1024*1024*40)) {
          return false;
        }


        $image_data['name'] = $imageName;
        $image_data['title'] = $title;
        $image_data['description'] = $description;
        $image_data['path'] = $path;
        $image_data['module'] = $module;
        $image_data['extension'] = $extension;
        $image_data['uploadable_id'] = $uploadable_id;
        $image_data['uploadable_type'] = $uploadable_type;
        $image_data['status'] = 1;
        $image_data['created_by'] = $user_id;
        
        $requestedImage->move($path, $imageName);
        if(!empty($id))
        {
          return $response = Upload::where('id', $id)->update($image_data);
        } else{
          $image_data['created_at'] = date('Y-m-d H:i:s');
          return $response = Upload::create($image_data);
        }
      
  }
    return false;
  }


  public static function backgroundImage()
  {

       return $imageData = Upload::where(['uploadable_type' =>'background-image','uploadable_id'=>1])->first();

  }




}

?>