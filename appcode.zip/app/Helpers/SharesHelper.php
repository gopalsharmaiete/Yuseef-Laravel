<?php
namespace App\Helpers;
use App\User;
use App\Models\shares_history;
use Auth;

class SharesHelper {

public static function Credit($shares=0,$property=0,$user_id=0,$unit_price=1){
    
    shares_history::create(array('share'=>$shares,'type'=>'credit','property_id'=>$property,'unit_price'=>$unit_price,'user_id'=>$user_id,'created_by'=>Auth::id(),'created_at'=>date('Y-m-d h:i:s')));
    
}

public static function Debit($shares=0,$property=0,$user_id=0,$unit_price=1){
    shares_history::create(array('share'=>$shares,'type'=>'debit','property_id'=>$property,'unit_price'=>$unit_price,'user_id'=>$user_id,'created_by'=>Auth::id(),'created_at'=>date('Y-m-d h:i:s')));
}

public static function Balance($property=0,$user_id=0){
    $shares_history = shares_history::query();
    
    if($property>0)
    {
        $shares_history->where('property_id',$property);
    }

    if($property>0)
    {
        $shares_history->where('user_id',$user_id);
    }
    return $shares_history->get();
}

public static function Rate_of_return($property=0,$user_id=0){
    
    $AvgPur = shares_history::where(['user_id'=>Auth::id()])->where('type','credit')->get()->avg('unit_price');

    $AvgSell = shares_history::where(['user_id'=>Auth::id()])->where('type','debit')->get()->avg('unit_price');

    $ShareSold = shares_history::where(['user_id'=>Auth::id()])->where('type','debit')->get()->sum('share');

    $begineeing_amount = $ShareSold*$AvgPur;

    $ending_amount = $ShareSold*$AvgSell;
    
    $rate_of_return = 0;
    
    if($begineeing_amount>0){
    $rate_of_return = (($ending_amount - $begineeing_amount)/$begineeing_amount*100);
    }

return $rate_of_return;

}


}

?>