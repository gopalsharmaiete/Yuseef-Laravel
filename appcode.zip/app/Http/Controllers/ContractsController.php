<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\roles as Role;
use Illuminate\Support\Facades\Validator;
use App\Models\Property;
use App\Models\Upload;
use Auth;

class ContractsController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,13']);
    }
    /**
     * Display a listing of the Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $ContractsData = Upload::where(['module'=>'contracts','uploadable_type'=>'property'])->get();
       $Property = Property::pluck('name','id');
       return view('contracts.index',compact('ContractsData','Property'));
    }

    /**
     * Show the form for creating a new Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    /**
     * Store a newly created Roles in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'title' => ['required', 'string'],
            'file' => 'required',
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }

        $imageName = time().'-'.request()->file->getClientOriginalName();
        $path = public_path('documents/contracts');
        
        request()->file->move($path, $imageName);

        $image_data['name'] = $imageName;
        $image_data['title'] = $request->title;
        $image_data['description'] = $request->description;
        $image_data['path'] = public_path('documents/contracts');
        $image_data['module'] = 'contracts';
        $image_data['extension'] = request()->file->getClientOriginalExtension();
        $image_data['uploadable_id'] = $request->property_id;
        $image_data['uploadable_type'] = 'property';
        $image_data['status'] = 1;
        $image_data['created_at'] = date('Y-m-d H:i:s');
        $image_data['created_by'] = $user_id;
        
        Upload::create($image_data);
        
        return redirect()->back()->with('success','created successfully');
    }

    /**
     * Display the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
       
    }

    /**
     * Update the specified Role in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $update_data = $request->toArray();
        unset($update_data['_token']);
        Role::where('id',$id)->update($update_data);
        return 'done';
    }

    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        Role::destroy($id);
        return 'done';
    }
}
