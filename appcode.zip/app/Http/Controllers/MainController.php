<?php namespace App\Http\Controllers;

use Request;
use GuzzleHttp\Client as httpClient;
use Illuminate\Support\Facades\Session;
use DB;
use App\Http\Controllers\Controller;
use App\Item;

class MainController extends Controller {

    protected $authInfo   = false;
    protected $userInfo   = false;
    protected $apiBaseUrl = 'http://sandbox40.avangate.local/api/proxyApp/';

    protected $isLogged     = false;

    public function __construct()
    {
        if (Session::has('authInfo') && Session::has('userInfo')) {
            $this->authInfo = Session::get('authInfo');
            $this->userInfo = Session::get('userInfo');
            $this->isLogged = true;
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function showMainPage()
    {
        return view('items', [
            'isLogged'  => $this->isLogged ? 1 : 0,
            'authToken' => $this->isLogged ? $this->authInfo['authToken'] : ''
        ]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $this->checkLogin();

        $items = Item::select('id', 'name', 'description', 'color')->where(['account' => $this->userInfo['VendorInfo']['ClientCode']])->orderBy('order')->get();
        echo json_encode(['success' => true, 'value' => $items]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return Response
     */
    public function store()
    {
        $this->checkLogin();

        $success = Item::create([
            'account'       => $this->userInfo['VendorInfo']['ClientCode'],
            'name'          => Request::input('name'),
            'description'   => Request::input('description'),
            'color'         => Request::input('color'),
            'order'         => 0
        ]);

        echo json_encode(['success' => !is_null($success), 'value' => null]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        $this->checkLogin();

        $item = Item::find($id);
        echo json_encode(['success' => true, 'value' => $item]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function update($id)
    {
        $this->checkLogin();

        $success    = false;
        $item     = Item::find($id);
        if ($item) {
            $item->name           = Request::input('name');
            $item->description    = Request::input('description');
            $item->url            = Request::input('url');
            $item->color          = Request::input('color');
            $success = $item->save();
        }

        echo json_encode(['success' => $success, 'value' => null]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        $this->checkLogin();

        $success    = false;
        $item     = Item::find($id);
        if ($item) {
            $success = Item::destroy($id);
        }

        echo json_encode(['success' => $success, 'value' => null]);
    }

    public function sortItems()
    {
        $this->checkLogin();

        $success    = true;
        $itemsOrder = Request::input('item');
        if (is_array($itemsOrder) && !empty($itemsOrder)) {
            foreach ($itemsOrder as $orderValue => $itemId) {
                $success = DB::table('items')
                    ->where(['id' => $itemId, 'account' => $this->userInfo['VendorInfo']['ClientCode']])
                    ->update(['order' => $orderValue]);

                if (!$success) {
                    break;
                }
            }
        }

        echo json_encode(['success' => $success, 'value' => null]);
    }

    public function validateToken()
    {
        $authToken = Request::input('authToken');
        if ($this->authInfo && ($this->authInfo === $authToken)) {
            echo json_encode(['success' => true, 'value' => null]);
        } else {
            Session::forget('authInfo');
            Session::forget('userInfo');

            $success = false;
            $this->authInfo = [
                'authToken'         => Request::input('authToken'),
                'expirationDate'    => Request::input('expirationDate'),
            ];

            try {
                $httpClient = $this->getHttpClient();
                $response   = $httpClient->put('verify/');
            } catch (\Exception $e) {
                $response = $e->getResponse();
            }

            if ($response->json() == true) {
                $this->userInfo = $this->getAuthUserInfo();
                if (!empty($this->userInfo)) {
                    Session::put('authInfo', $this->authInfo);
                    Session::put('userInfo', $this->userInfo);
                    $success = true;
                }
            }

            echo json_encode(['success' => $success, 'value' => null]);
        }
    }

    public function logout()
    {
        Session::forget('authInfo');
        Session::forget('userInfo');

        echo json_encode(['success' => true, 'value' => null]);
    }

    private function checkLogin()
    {
        if (!$this->isLogged) {
            echo json_encode(['success' => 'reload']);
            die();
        }
    }

    private function getAuthUserInfo()
    {
        try {
            $httpClient = $this->getHttpClient();
            $response   = $httpClient->get('user_info/');
        } catch (\Exception $e) {
            $response = $e->getResponse();
        }

        return $response->json();
    }

    private function getHttpClient()
    {
        return new httpClient([
            'base_url'  => $this->apiBaseUrl,
            'timeout'  => 2.0,
            'defaults' => [
                'proxy'     => '',
                'verify'    => false,
                'headers'   => [
                    'authToken' => $this->authInfo['authToken'],
                    'secretID'  => env('APP_SECRET'),
                    'Accept'    => 'application/json'
                ]
            ]
        ]);
    }
}
