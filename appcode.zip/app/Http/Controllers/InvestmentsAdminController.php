<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use \App\Models\PropertyInvestment;
use \App\Models\SecondaryPropertyInvestment;
use \App\Models\Masters;
use \App\Models\GatewayTransaction;
use Auth;
use App\Models\Employee;
use App\Models\secondary_investment_request;
use App\Models\secondary_investment_offer;
use App\Jobs\PropertyFunctions;
use App\Helpers\SharesHelper;

class InvestmentsAdminController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,10']);
    }
    /**
     * Display a listing of the Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
       return view('multilinguals.index',compact('MultilingualsData'));
    }

    /**
     * Show the form for creating a new Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        
    }

    /**
     * Store a newly created Roles in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        
    }

    /**
     * Display the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
       
    }

    /**
     * Update the specified Role in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        
    }

    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
       
    }

    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function InvestmentHistory(Request $request)
    { 
        $Investment = PropertyInvestment::query();
        $Investment->where('status','1');
        
        if($request->has('invester'))
        {
            $Investment->where('created_by',$request->invester);
        }

        if($request->has('start_date') && $request->has('end_date'))
        {            
            $from = date($request->start_date);
            $to = date($request->end_date);
            $Investment->whereBetween('created_at', [$from, $to]);
        }


        $Investment = $Investment->with('property','user','transaction')->get();
        $gateways = Masters::where('master_id',5)->pluck('name','option_value');
        $invester = Employee::where('user_type','invester')->pluck('name','id');
        return view('investment.index',compact('Investment','gateways','invester','request'));
       
    }

    public function InvestmentPending(Request $request)
    {
        $gateways = Masters::where('master_id',5)->pluck('name','option_value');
        $GatewayTransaction = GatewayTransaction::where('payment_status','0')->get();
        return view('investment.pending',compact('GatewayTransaction'));
    }

    public function CommissionPercentage(Request $request)
    {
        $commission = Masters::where('master_id',6)->pluck('filled_value','option_value');
        return view('investment.commission',compact('commission'));
    }

    public function SetCommissionPercentage(Request $request)
    {
        $update = array("filled_value"=>$request->commission);
        Masters::where('master_id',6)->update($update);
        $commission = Masters::where('master_id',6)->pluck('filled_value','option_value');
        return view('investment.commission',compact('commission'));
    }

    public function UpdateInvestmentStatus(Request $request)
    { 
       $id = $request->id;
       $GatewayTransaction = GatewayTransaction::where('id',$id)->first();        
      
       $orderData['payment_status'] = ($request->status=='approve')?1:2;     
          
        if(GatewayTransaction::where('id', $id)->update($orderData))
        {
            if($orderData['payment_status']=='1')
            {
                $invest_data['amount'] = $GatewayTransaction->amount;
                $invest_data['property_id'] = $GatewayTransaction->property_id;
                $invest_data['user_id'] = $GatewayTransaction->user_id;
                $invest_data['payment_ref_id'] = $id;            
                $invest_data['created_by'] = $request->user_id;
                if($GatewayTransaction->payment_source=='secondary')
                {
                    if(SecondaryPropertyInvestment::create($invest_data))
                    {
                        if($GatewayTransaction['secondary_request_table']=='secondary_investment_request')
                        {
                            secondary_investment_request::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('is_paid'=>'1','status'=>'1'));
                            $secondary_investment_request = secondary_investment_request::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                            SharesHelper::Credit($secondary_investment_request['shares'],$invest_data['property_id'],$invest_data['user_id'],$secondary_investment_request['unit_price']);   
                            SharesHelper::Debit($secondary_investment_request['shares'],$invest_data['property_id'], $secondary_investment_request ['accepted_by'],$secondary_investment_request['unit_price']);     
                        }
                        else
                        {
                            secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('is_paid'=>'1','status'=>'1'));
                            $secondary_investment_offer = secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                            $user_id = $secondary_investment_offer['to_user'];
                            if( $user_id == 0) {
                                $user_id =  $GatewayTransaction->user_id;
                                secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('to_user'=>$user_id,'accepted_by' => $user_id));
                            }

                            SharesHelper::Credit($secondary_investment_offer['shares'],$invest_data['property_id'],$user_id,$secondary_investment_offer['unit_price']);    
                            SharesHelper::Debit($secondary_investment_offer['shares'],$invest_data['property_id'],$secondary_investment_offer['user_id'],$secondary_investment_offer['unit_price']);    
                        }
                        
                        return 'success';
                    }
                    
                }
                else
                {
                    if(PropertyInvestment::create($invest_data))
                    {
                        $PropertyFunctions = new PropertyFunctions();
                        $PropertyFunctions->MoveToSecondary($GatewayTransaction['property_id']);
                        SharesHelper::Credit($invest_data['amount'],$invest_data['property_id'],$invest_data['user_id']);
                        return 'success';
                    }
                    
                }
                
            }
            else
            {
                return 'rejected';
            }            
            
        }

        return 'failed';
        
    }
    

    
  public function failedPayment(Request $request) 
  {
      $gatewayTransaction = GatewayTransaction::query();
      
      if(isset($request->invester)){
          $gatewayTransaction =  $gatewayTransaction->where('user_id',$request->invester);
      }

      if(isset($request->start_date) && isset($request->end_date)) {
        $from = date('Y-m-d',strtotime($request->start_date));
        $to = date('Y-m-d',strtotime($request->end_date));
        $gatewayTransaction =  $gatewayTransaction->whereBetween('created_at',[$from,$to]);
      }

      $gatewayTransaction = $gatewayTransaction->where(['payment_status'=>'2','gateway_id'=>1])->get();
      $gateways = Masters::where('master_id',5)->pluck('name','option_value');
      $invester = Employee::where('user_type','invester')->pluck('name','id');
    
      return view('investment.failed',compact('gatewayTransaction','invester'));
         
  }

 
 public function failedStatusChange($id) {
     
     $GatewayTransaction = GatewayTransaction::find($id);
     $invest_data['amount'] = $GatewayTransaction['amount'];
     
     $invest_data['property_id'] = $GatewayTransaction['property_id'];
     $invest_data['user_id'] = $GatewayTransaction['user_id'];
     $invest_data['payment_ref_id'] = $GatewayTransaction['id'];            
     $invest_data['status'] = '1';
     $invest_data['created_by'] = $GatewayTransaction['user_id'];
    
     $GatewayTransaction->payment_status = '1';
     if($GatewayTransaction->save()) {
            if($GatewayTransaction['payment_source'] == 'secondary') {
                
                    $invest_data['request_reference_id'] = $GatewayTransaction['secondary_request_reference_id'];
                    SecondaryPropertyInvestment::create($invest_data);

                if($GatewayTransaction['secondary_request_table']=='secondary_investment_request')
                {
                    secondary_investment_request::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('is_paid'=>'1','status'=>'1'));
                    $secondary_investment_request = secondary_investment_request::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                    SharesHelper::Credit($secondary_investment_request['shares'],$invest_data['property_id'],$invest_data['user_id'],$secondary_investment_request['unit_price']);
                    SharesHelper::Debit($secondary_investment_request['shares'],$invest_data['property_id'],$secondary_investment_request['accepted_by'],$secondary_investment_request['unit_price']);
                }
                else
                {                        
                    secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('is_paid'=>'1','status' => '1'));
                    $secondary_investment_offer = secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                    $user_id = $secondary_investment_offer['to_user'];
                    if( $user_id == 0) {
                          $user_id = $GatewayTransaction->user_id;
                          secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('to_user'=>$user_id,'accepted_by' => $user_id));
                    }
                    SharesHelper::Credit($secondary_investment_offer['shares'],$invest_data['property_id'],$user_id,$secondary_investment_offer['unit_price']);    
                    SharesHelper::Debit($secondary_investment_offer['shares'],$invest_data['property_id'],$secondary_investment_offer['user_id'],$secondary_investment_offer['unit_price']);    
                }

            } else {
                PropertyInvestment::create($invest_data);
                $PropertyFunctions = new PropertyFunctions();
                $PropertyFunctions->MoveToSecondary($GatewayTransaction['property_id']);
                SharesHelper::Credit($invest_data['amount'],$invest_data['property_id'],$invest_data['user_id']);
            }
 
    } else {
        return redirect()->back()->with(['error'=>'There is some problem in updating status']);
    }

   
    return redirect()->back()->with(['success'=>'Status Changed Successfully']);

}







}
