<?php

namespace App\Http\Controllers;
use App\Models\Property;
use App\Models\PropertyInvestment;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use \App\Models\Masters;
use Illuminate\Support\Facades\Input;
use App\Models\Upload;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
	
	public function welcome(Request $request)
    {
		$Property = Property::query();
        $Property = $Property->where(['secondary_target'=>'0','status'=>1])->with(['countryname','investment',"file" => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->orderBy('id', 'desc')->limit(3)->get();  
        $Sliders = Upload::where(['module' =>'main-slider'])->get();
        $Secondary = Upload::where(['module' =>'secondary-slider'])->get();
        $videoData = Upload::where(['uploadable_type'=>'video-upload','uploadable_id' =>2])->get();
		return view('welcome',compact('Property','Sliders','Secondary','videoData'));
    }

    public function shop(Request $request)
    {
        $Property = Property::query();
        if (Input::has('s'))
              {
                $queryString = Input::get('s');
                 // simple where here or another scope, whatever you like
                 $Property->where('name','like', "%$queryString%");
              }

              if (Input::has('funded_status') && Input::get('funded_status') != '')
              {
                $status = Input::get('funded_status');
                 $Property->where('funded_status', '=', $status);
              }

              if (Input::has('offering_type') && Input::get('offering_type') != '')
              {
                $type = Input::get('offering_type');
                 $Property->where('offering_type', '=', $type);
              }

              if (Input::has('country') && Input::get('country') != '')
              {
                $type = Input::get('country');
                 $Property->where('country', '=', $type);
              }

        $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value'); 
        $Property = $Property->where(['secondary_target'=>'0','status'=>1])->with(['countryname','investment',"file" => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->orderBy('id', 'desc')->limit(9)->get();        
        $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
        $Status = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','4')->get()->pluck('name', 'option_value');
        return view('frontend.shop',compact('Property','Category','Status','country'));
    }
	
	 public function secondaryMarketing(Request $request)
      {
        $desgin = 'grid';
        $Property = Property::query();
        if (Input::has('s'))
              {
                $queryString = Input::get('s');
                 // simple where here or another scope, whatever you like
                 $Property->where('name','like', "%$queryString%");
              }

              if (Input::has('funded_status') && Input::get('funded_status') != '')
              {
                $status = Input::get('funded_status');
                 $Property->where('funded_status', '=', $status);
              }

              if (Input::has('offering_type') && Input::get('offering_type') != '')
              {
                $type = Input::get('offering_type');
                 $Property->where('offering_type', '=', $type);
              }

              if (Input::has('country') && Input::get('country') != '')
              {
                $type = Input::get('country');
                 $Property->where('country', '=', $type);
              }
           
            if($request->input('design')) {  
                $desgin = $request->input('design');
            }
        

        $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value'); 
        $Property = $Property->where(['secondary_target'=>'1','status' => 1])->with(['countryname','investment','SecondaryInvestment',"file" => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->orderBy('id', 'desc')->limit(9)->get();
        $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
        $Status = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','4')->get()->pluck('name', 'option_value');
        
        if( $desgin == 'list'){
            return view('frontend.secondary-marketing-list',compact('Property','Category','Status','country'));
        } 
        return view('frontend.secondary-marketing',compact('Property','Category','Status','country'));
    }

    public function secondaryOffers(Request $request)
    {
      $desgin = 'grid';
      $Property = Property::query();
      if (Input::has('s'))
            {
              $queryString = Input::get('s');
               // simple where here or another scope, whatever you like
               $Property->where('name','like', "%$queryString%");
            }

            if (Input::has('funded_status') && Input::get('funded_status') != '')
            {
              $status = Input::get('funded_status');
               $Property->where('funded_status', '=', $status);
            }

            if (Input::has('offering_type') && Input::get('offering_type') != '')
            {
              $type = Input::get('offering_type');
               $Property->where('offering_type', '=', $type);
            }

            if (Input::has('country') && Input::get('country') != '')
            {
              $type = Input::get('country');
               $Property->where('country', '=', $type);
            }
         
          if($request->input('design')) {  
              $desgin = $request->input('design');
          }
      

      $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value'); 
      $Property = $Property->where(['secondary_target'=>'1','status' => 1])->with(['countryname','investment','SecondaryInvestment',"file" => function($q) {
          $q->where(['uploadable_type'=>'property']);
      }])->whereHas('SecondaryInvestmentBidsOffer',function($q){$q->where('to_user','0');})->orderBy('id', 'desc')->limit(9)->get();
      $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
      $Status = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','4')->get()->pluck('name', 'option_value');
      
      if( $desgin == 'list'){
          return view('frontend.secondary-market-offers',compact('Property','Category','Status','country'));
      } 
      return view('frontend.secondary-market-offers',compact('Property','Category','Status','country'));
  }

    
    public function register(Request $request)
    {
        if (Auth::check()) {
            // $Property = Property::query();
            // $Property = $Property->with('countryname','investment')->orderBy('id', 'desc')->limit(3)->get();        
            // return view('welcome')->with('Property',$Property);
            return redirect('/');
        } else{
            return view('auth.user-register');
        }
    }

    public function login(Request $request)
    {
        return view('auth.user-login');
    }

    public function forgotPassword()
    {
        
        return view('auth.passwords.email');
    }

    public function shopload(Request $request)
    {

        $Property = Property::query();

        if (Input::has('s'))
              {
                $queryString = Input::get('s');
                 // simple where here or another scope, whatever you like
                 $Property->where('name','like', "%$queryString%");
              }

              if (Input::has('funded_status') && Input::get('funded_status') != '')
              {

                $status = Input::get('funded_status');
                 $Property->where('funded_status', '=', $status);
              }

              if (Input::has('offering_type') && Input::get('offering_type') != '')
              {
                $type = Input::get('offering_type');
                 $Property->where('offering_type', '=', $type);
              }
        $Property = $Property->where('secondary_target','0')->with('countryname','investment')->orderBy('id', 'desc')->skip($request->offset)->take($request->limit)->get();                
        $view = view('frontend.shop.load',compact('Property','Category','Status'))->render();
        return response()->json(['html'=>$view]);
    }

    public function secondaryload(Request $request)
    {

        $Property = Property::query();
        $desgin = 'grid';
        if (Input::has('s'))
              {
                $queryString = Input::get('s');
                 // simple where here or another scope, whatever you like
                 $Property->where('name','like', "%$queryString%");
              }

              if (Input::has('funded_status') && Input::get('funded_status') != '')
              {

                $status = Input::get('funded_status');
                 $Property->where('funded_status', '=', $status);
              }

              if (Input::has('offering_type') && Input::get('offering_type') != '')
              {
                $type = Input::get('offering_type');
                 $Property->where('offering_type', '=', $type);
              }
        
            if($request->input('design')) {  
                $desgin = $request->input('design');
            }
       
        $Property = $Property->where('secondary_target','1')->with('countryname','investment')->orderBy('id', 'desc')->skip($request->offset)->take($request->limit)->get();                
        if($desgin == 'list')
           $view = view('frontend.secondary.load-list',compact('Property','Category','Status'))->render();
        else
           $view = view('frontend.secondary.load',compact('Property','Category','Status'))->render();
        
           return response()->json(['html'=>$view]);
    }
    

    /**
     * Display the specified resource.
     *
     * @param  \App\property  $property
     * @return \Illuminate\Http\Response
     */
    public function propertyDetail($id)
    {
        $Property = Property::with(['amenities','file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->where("id",$id)->first();
        
        return view('frontend.property-details',compact('Property'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\property  $property
     * @return \Illuminate\Http\Response
     */
    public function SecondarypropertyDetail($id)
    {
        $Property = Property::with(['amenities','file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->where("id",$id)->first();
        
        return view('frontend.secondary-property-details',compact('Property'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\property  $property
     * @return \Illuminate\Http\Response
     */
    public function SecondaryOfferpropertyDetail($id)
    {
        $Property = Property::with(['SecondaryInvestment','amenities','file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->where("id",$id)->whereHas('SecondaryInvestmentBidsOffer',function($q){$q->where('to_user','0');})->first();
        
        return view('frontend.secondary-offer-property-details',compact('Property'));
    }


   public function secondaryOfferLoad(Request $request) 
   {

            $desgin = 'grid';
            $Property = Property::query();
            //print_r($request->all());
            if (Input::has('s'))
                {
                    $queryString = Input::get('s');
                    // simple where here or another scope, whatever you like
                    $Property->where('name','like', "%$queryString%");
                }

                if (Input::has('funded_status') && Input::get('funded_status') != '')
                {
                    $status = Input::get('funded_status');
                    $Property->where('funded_status', '=', $status);
                }

                if (Input::has('offering_type') && Input::get('offering_type') != '')
                {
                    $type = Input::get('offering_type');
                    $Property->where('offering_type', '=', $type);
                }

                if (Input::has('country') && Input::get('country') != '')
                {
                    $type = Input::get('country');
                    $Property->where('country', '=', $type);
                }
            
                if($request->input('design')) {  
                    $desgin = $request->input('design');
                }
            

           
            $Property = $Property->where(['secondary_target'=>'1','status' => 1])->whereHas('SecondaryInvestmentBidsOffer',function($q){$q->where('to_user','0');})->with(['countryname','investment','SecondaryInvestment',"file" => function($q) {
                $q->where(['uploadable_type'=>'property']);
            }])->orderBy('id', 'desc')->skip($request->offset)->take($request->limit)->get();
           
            
            if( $desgin == 'list')
                $view = view('frontend.secondary-offer.load',compact('Property'))->render();
            else
               $view = view('frontend.secondary-offer.load-grid',compact('Property'))->render();
               
              return response()->json(['html'=>$view]);
   }

 

   
}
