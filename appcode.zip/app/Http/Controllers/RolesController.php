<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\roles as Role;
use Illuminate\Support\Facades\Validator;
use Auth;

class RolesController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,1']);
    }
    /**
     * Display a listing of the Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $rolesData = Role::get();
       return view('roles.index',compact('rolesData'));
    }

    /**
     * Show the form for creating a new Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    /**
     * Store a newly created Roles in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'name' => ['required', 'string'],
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }
        $insertedData = array('name'=>$request->name,
                              'value'=>$request->value,
							'created_at'=>date('Y-m-d H:i:s'),
							'created_by'=>$user_id,
							'updated_by'=>$user_id
							);
		$data = Role::create($insertedData);
        
        return redirect('roles')->with('success','Role created successfully');
    }

    /**
     * Display the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
       
    }

    /**
     * Update the specified Role in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $update_data = $request->toArray();
        unset($update_data['_token']);
        Role::where('id',$id)->update($update_data);
        return 'done';
    }

    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        Role::destroy($id);
        return 'done';
    }
}
