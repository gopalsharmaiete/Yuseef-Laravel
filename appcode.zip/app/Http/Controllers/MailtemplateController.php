<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use \App\Models\Masters;
use App\Models\Mailtemplate;
use Illuminate\Support\Facades\Validator;
use App\Helpers\TemplateHelper;
use Auth;

class MailtemplateController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,7']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Mailtemplate = Mailtemplate::get();
        return view('mailtemplate.index',compact('Mailtemplate'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'title' => ['required', 'string'],
            'description' => ['required', 'string']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }
        
        $update_data = $request->toArray();
        $update_data['created_at'] = date('Y-m-d H:i:s');
		$update_data['created_by'] = $user_id;					
        unset($update_data['_token']);

        Mailtemplate::create($update_data);

        return redirect('mailtemplate')->with('success','created successfully');
     
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        return TemplateHelper::SendMailTemplate('1',$mails_to=[array("rockingteamf@gmail.com"=>"rockingteamf@gmail.com")],$mails_cc=[]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $EditMailtemplate = Mailtemplate::find($id);
        return view('mailtemplate.edit',compact('EditMailtemplate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validatedData = Validator::make($request->all(), [
            'title' => ['required', 'string'],
            'description' => ['required', 'string']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();           
        }

        $update_data = $request->toArray();
        unset($update_data['_token']);
        unset($update_data['_method']);
        Mailtemplate::where('id',$id)->update($update_data);
        return redirect('mailtemplate')->with('success','Updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        RolesPermissions::destroy($id);
        return 'done';
    }
}
