<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\secondary_investment_offer;
use App\Models\UserPayment;
use App\Models\secondary_investment_request;
use Auth;

class PaymentToUsersController extends Controller
{

    
    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
       
    }
    /**
     * Display a listing of the Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $secondaryInvestmentOffers = secondary_investment_offer::where('is_paid','1')->get();
       $secondaryInvestmentRequest = secondary_investment_request::where('is_paid','1')->get();
       
       $secondaryinvestmentOffersIds = UserPayment::select('reference_id','created_at')->where(['reference_table'=>'secondary_investment_offer'])->get();
       $secondaryinvestmentOffersIds = collect($secondaryinvestmentOffersIds->toArray())->flatten()->all();
       $secondaryinvestmentRequestIds = UserPayment::select('reference_id','created_at')->where(['reference_table'=>'secondary_investment_request'])->get();
       $secondaryinvestmentRequestIds = collect($secondaryinvestmentRequestIds->toArray())->flatten()->all();
       return view('payment-to-users.index',compact('secondaryInvestmentOffers','secondaryInvestmentRequest','secondaryinvestmentRequestIds','secondaryinvestmentOffersIds'));
    }

    /**
     * Show the form for creating a new Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        
    }

    /**
     * Store a newly created Roles in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $request->validate([
             'refrence_id' => 'required|numeric',
             'refrence_table' => 'required',
             'transaction_id' => 'required',
             'remark' => 'required',
             'amount' => 'required'
         ]);

         //dd($request->refrence_table);
         $amount = number_format((float)$request->amount,2,'.','');
        // $data['merchant_email'] = env("PAYTABMERCHANTEMAIL");
        // $data['secret_key'] =  env("PAYTABSECRETKEY");
        // $data['refund_amount'] =  $amount;
        // $data['refund_reason'] = $request->remark;
        // $data['transaction_id'] =  $request->transaction_id;
        // $url = 'https://www.paytabs.com/apiv2/refund_process';
        //  $result = json_decode($this->runPost($url,$data),true);

       //  if($result['response_code'] == '812') {
        
                UserPayment::create([
                    'transaction_id' => $request->transaction_id,
                    'remarks' => $request->remark,
                    'reference_table' => $request->refrence_table,
                    'reference_id' => $request->refrence_id,
                    'refund_reference_id' => '', // $result['refund_request_id']
                    'amount' => $amount,
                    'created_by' => Auth::id(),
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ]);

                     return redirect()->back()->with('success','Payment Added Successfully');
        //}

    }

    /**
     * Display the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $refrenceId = $request->reference_id;
        $refrenceTable = $request->reference_table;
        $txnId = $request->txn_id;
        $validate = $request->validate([
           'reference_id' => 'required|numeric',
           'reference_table' => 'required'
        ]);

 
        return view('payment-to-users.payment',compact('refrenceId','refrenceTable','txnId'));
    }

    /**
     * Show the form for editing the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        
    }

    /**
     * Update the specified Role in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
       
    }


     
    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
       
    }

  /**
   *  Paytabs Api for refund
   *  @param $url
   *  @param $fields
   *  return object
   * 
   */
    function runPost($url, $fields) {
        $fields_string = "";
        foreach ($fields as $key => $value) {
            $fields_string .= $key . '=' . $value . '&';
        }
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        $ip = $_SERVER['REMOTE_ADDR'];
        $ip_address = array(
            "REMOTE_ADDR" => $ip,
            "HTTP_X_FORWARDED_FOR" => $ip
        );
		curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_HEADER, false);
          curl_setopt($ch, CURLOPT_TIMEOUT, 30);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($ch, CURLOPT_VERBOSE, true);
		/*
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $ip_address);
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_REFERER, 1);
*/
        $result = curl_exec($ch);
        curl_close($ch);
        
        return $result;
    }
}
