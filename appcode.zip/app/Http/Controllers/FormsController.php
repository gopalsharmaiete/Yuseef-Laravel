<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\forms;
use App\Models\FormsData;
use App\Models\forms_serials;
use App\Helpers\ImagesHelper;
use App\Models\Upload;
use Auth;

class FormsController extends Controller
{

    protected $user;
    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
        if($request['form']=='testimonial')
            {
                $this->middleware(['ValidateRole:1,12']);
            }
            else if($request['form']=='faq')
            {
                $this->middleware(['ValidateRole:1,13']);
            }
            else if($request['form']=='team')
            {
                $this->middleware(['ValidateRole:1,11']);
            }
            else if($request['form']=='priceguide')
            {
                $this->middleware(['ValidateRole:1,14']);    
            }
    }
    /**
     * Display a listing of the Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request['form']=='testimonial')
            {
                $module_id = 12;
            }
            else if($request['form']=='faq')
            {
                $module_id = 13;
            }
            else if($request['form']=='team')
            {
                $module_id = 11;
            }
            else if($request['form']=='priceguide')
            {
                $module_id = 14;    
            }
            else if($request['form']=='main-slider')
            {
                $module_id = 20;    
            }
            else if($request['form']=='secondary-slider')
            {
                $module_id = 21;    
            }
            else if($request['form']=='confirmInvestment')
            {
                $module_id = 22;    
            }
            else if($request['form']=='video-upload')
            {
                $module_id = 24;    
            }
            else if($request['form']=='background-image')
            {
                $module_id = 25;    
            }
            
        $forms_data = $forms_fields = array();
        $form_name = '';
        if($request->has('form')){
            $form_name = $request->form;
            $forms_fields = forms::where('form',$request->form)->get();
            $forms_data = FormsData::where('group',$request->form)->get();    
        }
        $forms_serials = forms_serials::where('form',$form_name)->with('data')->get();
       return view('forms.index',compact('forms_serials','forms_fields','forms_data', 'module_id'));
    }

    /**
     * Show the form for creating a new Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if($request['form']=='testimonial')
            {
                $this->middleware(['ValidateRole:2,12']);
            }
            else if($request['form']=='faq')
            {
                $this->middleware(['ValidateRole:2,13']);
            }
            else if($request['form']=='team')
            {
                $this->middleware(['ValidateRole:2,11']);
            }
            else if($request['form']=='priceguide')
            {
                $this->middleware(['ValidateRole:2,14']);    
            }
        $forms_fields   =   array();
        $form_name = '';
        if($request->has('form')){
        $form_name = $request->form;
        $forms_fields = forms::where('form',$request->form)->get();
        }
       
        return view('forms.create',compact('forms_fields','form_name'));
    }

    /**
     * Store a newly created Roles in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $user_id = Auth::id();	
        /*$validatedData = Validator::make($request->all(), [
            'title' => ['required', 'string'],
            'description' => ['required', 'string']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }*/
        $request_data = $request->toArray();
        unset($request_data['_token']);
        unset($request_data['form_name']);
        unset($request_data['file']);
        $form_name = $request->form_name;
        $serial = forms_serials::where('form',$form_name)->max('serial');        
        $serial =$serial+1;
        forms_serials::create(array("serial"=>$serial,"form"=>$form_name));
        $uploadPath = $uploadPath = public_path("images/$form_name");
        ImagesHelper::upload('',request()->file,$uploadPath,$serial,"$form_name","$form_name");
        $update_data_main = array();
        foreach($request_data as $key=>$val)
        {
            $update_data['label'] =  $serial.'_'.$key;
            $update_data['group'] = $form_name;
            $update_data['serial'] = $serial;
            $update_data['description'] =  $val;
            $update_data['locale'] =  $request->locale;
            $update_data['created_at'] = date('Y-m-d H:i:s');
            $update_data['created_by'] = $user_id;	
            $update_data_main [] = $update_data;				             
        }
       

 

        FormsData::insert($update_data_main);

        return redirect()->back()->with('success','created successfully');
    }

    /**
     * Display the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $forms_fields   =   array();
        $form_name = '';
        if($request->has('form')){
        $form_name = $request->form;
        $forms_fields = forms::where('form',$request->form)->get();
        }
        $forms_data = FormsData::where(['group'=>$request->form,'serial'=>$id])->get(); 
       
        $forms_serials = forms_serials::where('form',$form_name)->with(["file" => function($q) use($form_name,$id){
            $q->where('uploadable_type',$form_name);
        }])->get();
        
        $serial = $id;
        return view('forms.edit',compact('forms_fields','form_name','serial','forms_data','forms_serials'));
    }

    /**
     * Update the specified Role in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $request_data = $request->toArray();
        unset($request_data['_token']);
        unset($request_data['_method']);
        unset($request_data['form_name']);
        unset($request_data['serial']);
        unset($request_data['file']);
        
        foreach($request_data as $key=>$val)
        {
           FormsData::where(["serial"=>$id,"group"=>$request->form_name,"label"=>$key])->update(array("description"=>$val));
        }

        if($request->has('file')){
        $uploadPath = $uploadPath = public_path("images/$request->form_name");
        ImagesHelper::upload($request->old_image_id,request()->file,$uploadPath,$id,"$request->form_name","$request->form_name");
        }
        return redirect()->back()->with('success','updated successfully');
    }

    /**
     *  Generate sample CSV file for importing data
     * @param  \Illuminate\Http\Request  $request
     * @return void
     * 
    */

    public function sampleCSV(Request $request)
    {
        $form_name = '';
        if($request->has('form')) {
            $id = $request->form;
            switch($id) {

                  case 11:  $form_name = 'team';  break;
                  case 12:  $form_name = 'testimonial'; break;
                  case 13:  $form_name = 'faq'; break;
                  case 14:  $form_name = 'priceguide'; break;
                  case 22:  $form_name = 'confrimInvestment'; break;
             }


            $arrayTitle = array();
            $forms_fields = forms::where('form',$form_name)->get();
            $filename = ucfirst($form_name).'-sample-csv.csv';
            foreach($forms_fields  as $key => $data){
                $arrayTitle[] = $data['type'] == 'file' ? ucfirst($data['label']. ' Name') :  ucfirst($data['label']);
            }

            $arrayTitle[] = 'Locale';
            $fp = fopen('php://memory', 'w'); 

            fputcsv($fp,$arrayTitle);
            fseek($fp, 0);
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename="'.$filename.'";');
            fpassthru($fp);

       }
 
    }

     /**
     * Import Data from the CSV uploaded
     * @param  \Illuminate\Http\Request  $request
     * @return void
     * 
    */

    public function importData(Request $request)
    {
        
        
        $request->validate([
            'csv_file'          => 'required|file|max:500000',
       ]);
        
        $user_id = Auth::id();	
        $file = $request->file('csv_file');
        $ext = $file->getClientOriginalExtension();

        if(strtolower($ext) !== 'csv'){
          return redirect()->back()->with('error','Invalid File Extension');
        }


        // File Details 
        $id = $request->form_name;
        $form_name = '';
        switch($id) {

              case 11:  $form_name = 'team';  break;
              case 12:  $form_name = 'testimonial'; break;
              case 13:  $form_name = 'faq'; break;
              case 14:  $form_name = 'priceguide'; break;
         }

     
       try{
            $tempPath = $file->getPathName();
            $fp = fopen($tempPath,'r');
            $arrayTitle = fgetcsv($fp, 10000, ","); // Getting titles from the CSV 
            $count = count($arrayTitle); // Counting total rows in the CSV 
            while(($csvData = fgetcsv($fp, 10000, ",")) !== false) {
                    $i = 0;
                    $serial = forms_serials::where('form',$form_name)->max('serial'); 
                    $serial =$serial+1;
                    forms_serials::create(array("serial"=>$serial,"form"=>$form_name));
                    // Storing Localeon the forst row
                    $locale = ($csvData[$count-1] == '') ? 'en' : strtolower($csvData[$count-1]);
                    $update_data['label'] =  $serial.'_locale';
                    $update_data['group'] = $form_name;
                    $update_data['serial'] = $serial;
                    $update_data['description'] =   $locale;
                    $update_data['locale'] =   $locale;
                    $update_data['created_at'] = date('Y-m-d H:i:s');
                    $update_data['created_by'] = $user_id;	
                    $update_data_main [] = $update_data;
                    
                        foreach($csvData as $key =>$data) {
                
                             //  Uploading file and mapping it
                                if($arrayTitle[$key] == 'File Name'){
                                        
                                        $image_data['name'] = $data;
                                        $image_data['title'] = '';
                                        $image_data['description'] = '';
                                        $image_data['path'] = '';
                                        $image_data['module'] = $form_name;
                                        $image_data['extension'] = '';
                                        $image_data['uploadable_id'] =  $serial;
                                        $image_data['uploadable_type'] = $form_name;
                                        $image_data['status'] = 1;
                                        $image_data['created_by'] = $user_id;
                                        $upload = Upload::create($image_data);
                                        echo $upload->id;
                                        continue;
                                    }
                                    
                                    if($arrayTitle[$key]== 'Locale'){
                                    break;
                                    }

                                
                                
                                    $update_data['label'] =  $serial.'_'.strtolower($arrayTitle[$key]);
                                    $update_data['group'] = $form_name;
                                    $update_data['serial'] = $serial;
                                    $update_data['description'] =  $data;
                                    $update_data['locale'] =  $locale;
                                    $update_data['created_at'] = date('Y-m-d H:i:s');
                                    $update_data['created_by'] = $user_id;	
                                    $update_data_main [] = $update_data;	
                                    $i++;
                            
                        }
            }

            FormsData::insert($update_data_main);
             return redirect()->back()->with('success','created successfully');

        } catch(\Exception $e){
            abort(404);
        }

      // dd($update_data_main);
       
       
 
    }

    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        $module_id = $request->module_id;
     
        switch($module_id)
        {
             case 11: $module = 'team'; break;
             case 12: $module = 'testimonial'; break;
             case 13: $module = 'faq'; break;
             case 14: $module = 'priceguide'; break;
             case 20: $module = 'main-slider'; break;
             case 21: $module = 'secondary-slider'; break;
             case 22: $module = 'confirmInvestment'; break;
             case 24: $module = 'video-upload'; break;
             case 25: $module = 'background-image'; break;

        }
        
        $formsData = FormsData::where(['serial'=>$id,'group' => $module]);
        
        $Upload  = Upload::where(['uploadable_type' =>$module,'uploadable_id' => $id]);

        $formsData->delete();
        $Upload->delete();
      
         
      
        return redirect()->back()->with('success','Data Deleted SuccessFully');
    }
}
