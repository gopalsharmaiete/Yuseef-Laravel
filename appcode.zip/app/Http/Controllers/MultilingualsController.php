<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use App\Models\Multilingual;
use Illuminate\Support\Facades\Validator;
use Auth;
use Illuminate\Validation\Rule;

class MultilingualsController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,17']);
    }
    /**
     * Display a listing of the Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $MultilingualsData = Multilingual::whereIn('group', ['menu','text', 'prop-amenities-form', 'form-label'])->get();
       return view('multilinguals.index',compact('MultilingualsData'));
    }

    /**
     * Show the form for creating a new Roles.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return Multilingual::where('id',$request->id)->get();
    }

    /**
     * Store a newly created Roles in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'group' => ['required', 'string'],
            'label' => ['required',
                         Rule::unique('multilinguals')->where(function ($query) use($request){
                          return $query->where(['locale'=>$request->locale,'label'=>$request->label]);
                     })]
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }

        $insertedData = $request->toArray();
        unset($insertedData['_token']);

        $insertedData['created_at'] = date('Y-m-d H:i:s');
        $insertedData['created_by'] = $user_id;
        
 		$data = Multilingual::create($insertedData);
        
        return redirect('multilingual')->with('success',' created successfully');
    }

    /**
     * Display the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified Role.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
       
    }

    /**
     * Update the specified Role in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $update_data = $request->toArray();
        unset($update_data['_token']);
        Multilingual::where('id',$id)->update($update_data);
        return 'done';
    }

    /**
     * Remove the specified Role from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        Multilingual::destroy($id);
        return redirect()->back()->with('success','Deleted successfully');
    }
    /**
     * Parse CSV file to import.
     *
     * @param  requested file name
     * @return Response
     */	

	public function importdata(Request $request)
	{
	   $user_id = Auth::id();
	   if ($request->input('submit')){


		  $file = $request->file('csv_file');

		  // File Details 
		  $filename = $file->getClientOriginalName();
		  $extension = $file->getClientOriginalExtension();
		  $tempPath = $file->getRealPath();
		  $fileSize = $file->getSize();
		  $mimeType = $file->getMimeType();

		  // Valid File Extensions
		  $valid_extension = array("csv");

		  // 2MB in Bytes
		  $maxFileSize = 2097152; 

		  // Check file extension
		  if(in_array(strtolower($extension),$valid_extension)){

			// Check file size
			if($fileSize <= $maxFileSize){

			  // File upload location
			  $location = public_path('uploads'); 
			  // Upload file
			  $file->move($location,$filename);

			  // Import CSV to Database
			  $filepath = $location."/".$filename;

			  // Reading file
			  $file = fopen($filepath,"r");

			  $importData_arr = array();
			  $i = 0;

			  while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
				 $num = count($filedata );
				 
				 // Skip first row (Remove below comment if you want to skip the first row)
				 if($i == 0){
					$i++;
					continue; 
				 }
				 for ($c=0; $c < $num; $c++) {
					$importData_arr[$i][] = $filedata [$c];
				 }
				 $i++;
			  }
			  fclose($file);
			  // Insert to MySQL database
			  //dd($importData_arr);
			  foreach($importData_arr as $importData){

				$insertedData = array(
				   "locale"=>$importData[0],
				   "label"=>$importData[1],
				   "description"=>$importData[2],
				   "group"=>'text',
				   "created_at" => date('Y-m-d H:i:s'),
				   "created_by" => $user_id
				   );
				
				$data = Multilingual::create($insertedData);
              }
              unlink($location."/".$filename);
				return redirect('multilingual')->with('success',' Import Successful.');
			}else{
			  return redirect('multilingual')->with('error','File too large. File must be less than 2MB.');
			  
			}

		  }else{
			 return redirect('multilingual')->with('error','Invalid File Extension.');
		  }

		}
	}
}
