<?php

namespace App\Http\Controllers;
use App\Models\Property;
use App\Models\PropertyInvestment;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use \App\Models\Masters;
use App\Helpers\ImagesHelper;
use App\Models\Upload;
use App\Models\FormsData;
use App\Models\forms_serials;
use App\Helpers\TemplateHelper;

class PageController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(Request $request)
    {
        if($request->path()=='real-estate-education-images' || $request->path()=='about-us-images' || $request->path()=='benefit-images')
            {
                $this->middleware(['ValidateRole:1,15']);
            }
            
    }

    /**
     * Show the about us page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function about()
    {
        $imagesData = Upload::where(['uploadable_type'=>'about'])->get();
        return view('frontend.about-us',compact('imagesData'));
    }

    /**
     * Show the about us page in admin.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function aboutAdmin()
    {
        $imagesData = Upload::where(['uploadable_type'=>'about'])->get();
        return view('pages-admin.about',compact('imagesData'));
    }

      /**
     * Show the contact us page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function contact()
    {
        return view('frontend.contact-us');
    }

      /**
     * Show the Faq page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function faq()
    {
        $form_name = 'faq';
        $locale = app()->getLocale();
        if($locale!='en')
        {
            if(FormsData::where(['group'=>$form_name,'locale'=>$locale])->doesntExist())
            {
                $locale = 'en';
            }
        }

        $forms_serials = forms_serials::where('form',$form_name)->with(["data"=> function($q) use($form_name,$locale){
            $q->where(['group'=>$form_name,'locale'=>$locale]);
        },"file" => function($q) use($form_name){
            $q->where('uploadable_type',$form_name);
        }])->get();
        return view('frontend.faq',compact('forms_serials'));        
    }

      /**
     * Show the Meet The Team page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function meetTheTeam()
    {   $form_name = 'team';
        $locale = app()->getLocale();
        if($locale!='en')
        {
            if(FormsData::where(['group'=>$form_name,'locale'=>$locale])->doesntExist())
            {
                $locale = 'en';
            }
        }

        $forms_serials = forms_serials::where('form',$form_name)->with(["data"=> function($q) use($form_name,$locale){
            $q->where(['group'=>$form_name,'locale'=>$locale]);
        },"file" => function($q) use($form_name){
            $q->where('uploadable_type',$form_name);
        }])->get();
        return view('frontend.meet-the-team',compact('forms_serials'));
    }

      /**
     * Show the Price Guide page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function priceGuide()
    {
        $form_name = 'priceguide';
        $locale = app()->getLocale();
        if($locale!='en')
        {
            if(FormsData::where(['group'=>$form_name,'locale'=>$locale])->doesntExist())
            {
                $locale = 'en';
            }
        }

        $forms_serials = forms_serials::where('form',$form_name)->with(["data"=> function($q) use($form_name,$locale){
            $q->where(['group'=>$form_name,'locale'=>$locale]);
        },"file" => function($q) use($form_name){
            $q->where('uploadable_type',$form_name);
        }])->get();
        return view('frontend.price-guide',compact('forms_serials'));        
    }

      /**
     * Show the Real Estate Education page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function realEstateEducation()
    {
        $imagesData = Upload::where(['uploadable_type'=>'real-estate-education'])->get();
        $videoData = Upload::where(['uploadable_type'=>'video-upload','uploadable_id' =>1])->get();
       
        return view('frontend.real-estate-education',compact('imagesData','videoData'));
    }

    /**
     * Show the testimonial page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function testimonials()
    {
        $form_name = 'testimonial';
        $locale = app()->getLocale();
        if($locale!='en')
        {
            if(FormsData::where(['group'=>$form_name,'locale'=>$locale])->doesntExist())
            {
                $locale = 'en';
            }
        }

        $forms_serials = forms_serials::where('form',$form_name)->with(["data"=> function($q) use($form_name,$locale){
            $q->where(['group'=>$form_name,'locale'=>$locale]);
        },"file" => function($q) use($form_name){
            $q->where('uploadable_type',$form_name);
        }])->get();
        return view('frontend.testimonials',compact('forms_serials'));
    }

      /**
     * Show the benefit page.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function benefit()
    {
        $imagesData = Upload::where(['uploadable_type'=>'benefit'])->get();
        return view('frontend.benefit',compact('imagesData'));
    }

    /**
     * Show the about us page in admin.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function benefitAdmin()
    {
        $imagesData = Upload::where(['uploadable_type'=>'benefit'])->get();
        return view('pages-admin.benefit',compact('imagesData'));
    }


    /**
     * Show the Real Estate Education Admin in admin.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function realEstateEducationAdmin()
    {
        $imagesData = Upload::where(['uploadable_type'=>'real-estate-education'])->get();
        return view('pages-admin.real-estate-education',compact('imagesData'));
    }

    /**
     * Save the images.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function saveImages(Request $request)
    {
        $uploadPath = public_path('images/pages');
        if(!empty(request()->id))
        {
            $id=request()->id;
        }
        else{
            $id='';
        }
        ImagesHelper::upload($id,request()->file,$uploadPath,0,'imageUpload',request()->uploadable_type, request()->title);

        return redirect()->back()->with('success','Image uploaded successfully');
    }

    public function SendContactMail(Request $request){

        $to='ybadawi@melkygroup.com';
        
        $data['CONTACTNAME'] = $request->name;
        $data['CONTACTMAIL'] = $request->email;
        $data['CONTACTMESSAGE'] = $request->description;

        return TemplateHelper::SendMailTemplate('3',[],$mails_cc=[],$to,'',$data);
    }    

}
