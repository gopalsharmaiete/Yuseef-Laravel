<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\roles;
use Illuminate\Support\Facades\Validator;
use App\Helpers\TemplateHelper;
use Auth;
use Hash;
use App\Helpers\ImagesHelper;
use App\Models\Upload;



class EmployeeController extends Controller
{

    protected $user;
    public function __construct(Request $request)
    {
        $this->middleware(['auth']);
        
           /* if($request->path()=='investor')
            {
                $this->middleware(['ValidateRole:1,5']);
            }
            else if($request->path()=='entrepreneur')
            {
                $this->middleware(['ValidateRole:1,6']);
            }
            else
            {
                $this->middleware(['ValidateRole:1,4']);    
            }*/
        
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {  
       $Employee = Employee::query();
      
       if($request->path()=='investor')
       {
        $Employee->where('user_type','invester');
       }
       else if($request->path()=='entrepreneur')
       {
        $Employee->where('user_type','entrepreneur'); 
       }
       else
       {
        $Employee->where('user_type','')->orWhere('user_type','employee');    
       }
       $Employee = $Employee->get();
       return view('employee.index',compact('Employee'));
    }

    /**
     * Show the form for creating a new Permission.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        if($request->path()=='investor')
            {
                $this->middleware(['ValidateRole:2,5']);
            }
            else if($request->path()=='entrepreneur')
            {
                $this->middleware(['ValidateRole:2,6']);
            }
            else
            {
                $this->middleware(['ValidateRole:2,4']);    
            }   
        $Employee = [];//Employee::where('id',$id)->get();
        $roles = roles::whereNotIn('value',[1,3,4])->pluck('name','value');
        return view('employee.add',compact('roles','Employee'));
    }

    /**
     * Store a newly created Permission in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {         
        $request = $request->toArray();
        $validatedData =  Validator::make($request, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'role' => ['required', 'integer'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();           
        }
        
        $e_id = Employee::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'user_type' => $request['user_type'],
            'role' => $request['role'],
            'password' => Hash::make($request['password']),
        ]);
        
        //$mails_to[$request['email']] = $request['email'];

        TemplateHelper::SendMailTemplate('1',array($e_id->id=>$request['email']),$mails_cc=[]);
        
        return redirect('employee')->with('success','Added successfully');
        
    }


    /**
     * Display the specified Permission.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request,$id)
    {
        $Employee = Employee::where('id',$id)->first();
        $roles = roles::pluck('name','value');
        return view('employee.view',compact('roles','Employee'));
    }

    /**
     * Show the form for editing the specified Permission.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {   
        if($request->path()=='investor')
            {
                $this->middleware(['ValidateRole:3,5']);
            }
            else if($request->path()=='entrepreneur')
            {
                $this->middleware(['ValidateRole:3,6']);
            }
            else
            {
                $this->middleware(['ValidateRole:3,4']);    
            }
        $Employee = Employee::where('id',$id)->get();
        $roles = roles::whereNotIn('value',[1,3,4])->pluck('name','value');
        return view('employee.edit',compact('roles','Employee'));
    }

    /**
     * Update the specified resource in Permission.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validatedData = Validator::make($request->all(), [
            'role' => ['required', 'integer'],
          ]);
          
        if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();           
        }
        $update_data = $request->toArray();

        if($request->password == '') {
            unset($update_data['password']);         
        }else
        {
            if($update_data['password']==$update_data['password_confirmation'])
            {
            $update_data['password'] = Hash::make($update_data['password']);
            }
            else
            {
                return redirect()->back()->with('error','Password and confirm password must be same');
            }
        }
        unset($update_data['password_confirmation']);

        
        unset($update_data['_token']);
        unset($update_data['_method']);
        unset($update_data['redirectpoint']);
        unset($update_data['userimage']);
        Employee::where('id',$id)->update($update_data);

        //update profile image
        $uploadPath = public_path('images/profile');

        if($request->has('userimage')){
             $imagesData = Upload::where(['uploadable_type'=>'profile', 'uploadable_id' =>$request->id])->first();
            if ($imagesData === null) {
                $image_id = '';
            } else{
                $image_id = $imagesData->id;
                $file_path = $imagesData->path.'/'.$imagesData->name;
                unlink($file_path);
            }
            ImagesHelper::upload($image_id,request()->userimage,$uploadPath,$request->id,'profile','profile'); 
        }

        if($request->redirectpoint == 'frontend/user-dashboard/settings'){
            return redirect('dashboard/settings/'.$request->id)->with('success','Updated successfully');
        } else{
            return redirect('employee')->with('success','Updated successfully');
        }
    }

    /**
     * Import Employee Data From the CSV 
     * 
     * @param \App\Request
     * @return \Illuminate\Http\Reponse 
     * 
     * **/

     public function importData(Request $request)
     {
          
        $request->validate([
            'csv_file'          => 'required|file|max:500000',
         ]);



         $file = $request->file('csv_file');
         $tempPath = $file->getPathName();
         $ext = $file->getClientOriginalExtension();
          if(strtolower($ext) !== 'csv'){
            return redirect('employee')->with('error','Invalid File Extension');
          }
        
        try 
        {
              
             $fp = fopen($tempPath,'r');
             fgetcsv($fp,10000,',');
             $employeeID = [];
             $data = [];
             while(($csvData = fgetcsv($fp,10000,',')) !== False )
              {
               
                  list($data['name'],$data['email'],$data['role'],$data['password']) = $csvData;

                 $validate = Validator::make($data,[
                    'name' => ['required', 'string', 'max:255'],
                    'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                    'role' => ['required', 'integer'],
                    'password' => ['required', 'string', 'min:8'],
                   ]
                 );

                 if ($validate->fails()) {
                    return redirect()->back()->withErrors($validate)->withInput();           
                }
                 
                 
                  $employeeID[] = Employee::create([
                     'name' => $csvData[0],
                     'email' => $csvData[1],
                     'user_type' => 'employee',
                     'role' => $csvData[2],
                     'password' => Hash::make($csvData[3]),
                  
                     ]);
                
                //$mails_to[$request['email']] = $request['email'];
        
                //TemplateHelper::SendMailTemplate('1',array($e_id->id=>$request['email']),$mails_cc=[]);
             }

             return redirect('employee')->with('success','Employess Added successfully');


        } catch(\Exception $e) {
           // dd($e); 
           return redirect('employee')->with('error',$e->getMessage());
        }

     }

    
    /**
     * Enable/Disable toggling of the user 
     * @param $id  
     * @return  \Illuminate\Http\Response
     * 
    **/
   
     public function toggle($id)
     {
         $employee = Employee::find($id);
         if($employee->user_type == 'admin') {
            return redirect()->back()->with('success','Admin Status can\'t be changed');
         }
         
         $employee->toggleIsActive()->save();

         return redirect()->back()->with('success','User Disabled Successfully');

     }
   
   
     /**
     * Remove the specified Permission from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        
    }
}
