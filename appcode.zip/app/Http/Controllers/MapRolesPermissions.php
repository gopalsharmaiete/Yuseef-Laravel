<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\RolesPermissions;
use App\Models\Permissions;
use \App\Models\Masters;
use App\Models\roles;
use Illuminate\Support\Facades\Validator;
use Auth;

class MapRolesPermissions extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,3']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $RolesPermissions = RolesPermissions::get();
        $roles = roles::pluck('name','value');
        $permission = Permissions::pluck('name','value');
        $modules = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','1')->get()->pluck('name', 'option_value');
        return view('map-roles-permissions.index',compact('RolesPermissions','roles','permission','modules'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'roles' => ['required', 'integer'],
            'modules' => ['required', 'Integer'],
            'permission' => ['required', 'Integer']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }

        $insertedData = array('role_id'=>$request->roles,
        'module_id'=>$request->modules,
        'permission_id'=>$request->permission,
        'created_at'=>date('Y-m-d H:i:s'),
        'created_by'=>$user_id,
        'updated_by'=>$user_id,
        'status'=>'1',
        );

        $data = RolesPermissions::firstOrCreate(
            ['role_id'=>$request->roles,'module_id' => $request->modules,'permission_id'=>$request->permission],
            $insertedData
        );
        return redirect('roles-permissions')->with('success','Role created successfully');
     
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        RolesPermissions::destroy($id);
        return 'done';
    }
}
