<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Property;
use \App\Models\Masters;
use App\Models\CMS;
use App\Models\Upload;
use App\Models\Employee;
use App\User;
use App\Models\PropertyAmenities;
use App\Models\PropertyInvestment;
use App\Models\GatewayTransaction;
use App\Models\secondary_investment_offer;
use App\Models\secondary_investment_request;
use App\Helpers\ImagesHelper;
use App\Helpers\GatewayHelper;
use App\Traits\TwoCheckoutTrait;
use Session;
use Redirect;
use App\Models\forms_serials;
use App\Notifications\NewMessage;
use Stripe;
use Braintree_Transaction;
use App\Controllers\EmployeeController;
use App\Helpers\TemplateHelper;
use App\Helpers\SharesHelper;
use Illuminate\Support\Facades\Validator;
use Hash;
use Auth;
use App\Jobs\Paytabs; 
use App\Jobs\PropertyFunctions;
use App\Models\SecondaryPropertyInvestment;
class InvestCheckoutController extends Controller
{
    use TwoCheckoutTrait;
    public function __construct()
    {
        //$this->middleware(['auth']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $investAmt = $request->inveramt;
        $propertyID = $request->propertyID;
        $propertyName = $request->propertyName;
        $form_name = 'confirmInvestment';
        $locale = app()->getLocale();
        if($locale!='en')
        {
            if(FormsData::where(['group'=>$form_name,'locale'=>$locale])->doesntExist())
            {
                $locale = 'en';
            }
        }

        $forms_serials = forms_serials::where('form',$form_name)->with(["data"=> function($q) use($form_name,$locale){
            $q->where(['group'=>$form_name,'locale'=>$locale]);
        }])->get();
        return view('frontend.checkout.confirm-investment',compact('investAmt', 'propertyID', 'propertyName', 'forms_serials'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    

    /**
     * Display the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {

    }

    /**
     * Show the form for checkout.
     *
     * @return \Illuminate\Http\Response
     */
    public function checkout(Request $request)
    {
        $amount = $request->amount;
        $property_id = $request->property_id;
        $property_name = $request->propertyName;

            $user = Auth::user();
        $commission_percent = Masters::where('master_id',6)->pluck('filled_value','option_value');
        $commission = $amount*$commission_percent['1']/100;
        return view('frontend.checkout.checkout',compact('amount', 'property_id', 'property_name', 'user', 'forms_serials','commission','commission_percent'));
    }


    public function stripe()
    {   //return $this->getloginsession();
        return view('frontend.checkout.stripe');
    }
    
  
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function stripePost(Request $request)
    {
        Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        Stripe\Charge::create ([
                "amount" => 100 * 100,
                "currency" => "usd",
                "source" => $request->stripeToken,
                "description" => "Test payment " 
        ]);
  
        Session::flash('success', 'Payment successful!');
          
        return back();
    }
    
    public function braintree()
    {
        return view('frontend.checkout.braintree');
    }
  
    /**
     * success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function braintreePay(Request $request)
    {
        $payload = $request->input('payload', false);
        $nonce = $payload['nonce'];
        $status = Braintree_Transaction::sale([
                                'amount' => '10.00',
                                'paymentMethodNonce' => $nonce,
                                'options' => [
                                           'submitForSettlement' => True
                                             ]
                  ]);
        return response()->json($status);
    }

    /**
     * Payment Gateway response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function selectGateway(Request $request)
    {
        if($request->gateway == 'paypal'){
            $view = view('frontend.checkout.paypal')->render();
        } elseif($request->gateway == 'braintree'){
            $view = view('frontend.checkout.braintree')->render();
        }

        return response()->json(['html'=>$view]);
    }

    public function finaltwocheckout(Request $request)
    {   //return $request;
        return $this->getloginsession();        
    }

    public function finalCheckout(Request $request)
    {
         if($request->islogin == 'Y')
         {
            $payment_data['user_id'] = $request->user_id;
            
        }else{
            $user_data = $request->toArray();
            $user_data['user_type'] = 'invester';
            $user_data['role'] = 4;
            $rand_string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $password = substr(str_shuffle(str_repeat($rand_string, 9)), 0, 9);
            $user_data['password'] = $password;
            $user_data['register_from'] = 'checkout';

            // Create invester user
                $validatedData =  Validator::make($user_data, [
                    'name' => ['required', 'string', 'max:255'],
                    'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
                    'role' => ['required', 'integer'],
                    'password' => ['required', 'string', 'min:8'],
                ]);

                if ($validatedData->fails()) {
                    
                    return redirect()->back()->withErrors($validatedData);           
                }
                
                $e_id = Employee::create([
                    'name' => $user_data['name'],
                    'email' => $user_data['email'],
                    'user_type' => $user_data['user_type'],
                    'role' => $user_data['role'],
                    'password' => Hash::make($user_data['password']),
                ])->id;
             
            $payment_data['user_id'] = $e_id;
            TemplateHelper::SendMailTemplate('1',array($e_id=>$user_data['email']),$mails_cc=[]);
            //$userid = EmployeeController::store($request);
            
        }

            $payment_data['property_id'] = $request->property_id;
            
            $payment_data['amount'] = $request->amount;
            $payment_data['currency'] = $request->currency;
            $payment_data['commission_amount'] = $request->commission_amount;
            $payment_data['commission_percentage'] = $request->commission_percentage;
            $payment_data['total'] = $request->total;

            if($request->transfer == 'wiretransfer'){
                $payment_data['gateway_id'] = 2;
            } else{
                $payment_data['gateway_id'] = 1;
            }
            $latestOrder = GatewayTransaction::orderBy('created_at','DESC')->first();
            if($latestOrder){
              $orderID = '#'.str_pad($latestOrder->id + 1, 8, "0", STR_PAD_LEFT);
            }
            else{
              $orderID = '#'.str_pad(1, 8, "0", STR_PAD_LEFT);;
            }
            $payment_data['order_number'] = $orderID;
            $payment_data['payment_status'] = 0;
            $payment_data['created_at'] = date('Y-m-d H:i:s');
            

            $id = GatewayTransaction::create($payment_data)->id;

            /*if($id != ''){
             $msg = array(
                    'status' => 'success',
                    'id' => $id,
                    'orderID' => $orderID,
                    'userID' => $payment_data['user_id'],
                    'message' => 'Information saved successfully'
                );
                return response()->json($msg);

            } else {
                $msg = array(
                    'status' => 'error',
                    'message' => 'There is some error please try again.'
                );
                return response()->json($msg);
            }*/

            if($id != '')
            {
                    if( $payment_data['gateway_id'] == 2)
                    {
                        return redirect('payment/wire-transfer?id='.$id);
                    }
                    else
                    {
                        return redirect('gateway-transfer/'.$id);
                    }
            }
            else
            {
                
            }
    }

    public function GatewayTransfer(Request $request,$id)
    {
        $GatewayTransaction = GatewayTransaction::where('id',$id)->first();
        return view('frontend.checkout.gateway-transfer',compact('GatewayTransaction'));
    }

    public function SecondaryFinalPayment(Request $request,$id)
    {           
        $secondary_request_table = 'secondary_investment_request';
        $SecondaryInvestmentRequest = secondary_investment_request::where('id',$id)->first();

        if($request->has('table'))
        {            
                if($request->table=='offer')
                {
                $secondary_request_table = 'secondary_investment_offer';
                $SecondaryInvestmentRequest = secondary_investment_offer::where('id',$id)->first();
                }
                
        }
       
        
        $payment_data['gateway_id'] = 1;
        if($request->mode=='wiretransfer')
        {
            $payment_data['gateway_id'] = 2;
        }        
     
        $payment_data['user_id'] = Auth::id();     
        $payment_data['property_id'] = $SecondaryInvestmentRequest['property_id'];        
        $payment_data['amount'] = $SecondaryInvestmentRequest['shares']*$SecondaryInvestmentRequest['unit_price'];
        $payment_data['currency'] = 'EGP';
        $commission_percent = Masters::where('master_id',6)->pluck('filled_value','option_value');
        $commission_amount = $payment_data['amount']*$commission_percent['1']/100;
        $payment_data['commission_amount'] = $commission_amount;
        $payment_data['commission_percentage'] = $commission_percent['1'];
        $payment_data['total'] = $payment_data['amount']+$payment_data['commission_amount'];        
        $payment_data['payment_source'] = 'secondary';

       
        $latestOrder = GatewayTransaction::orderBy('created_at','DESC')->first();
        if($latestOrder){
          $orderID = '#'.str_pad($latestOrder->id + 1, 8, "0", STR_PAD_LEFT);
        }
        else{
          $orderID = '#'.str_pad(1, 8, "0", STR_PAD_LEFT);;
        }

        $payment_data['order_number'] = $orderID;
        $payment_data['payment_status'] = 0;
        $payment_data['created_at'] = date('Y-m-d H:i:s');
        $payment_data['secondary_request_reference_id'] = $SecondaryInvestmentRequest['id'];
        $payment_data['secondary_request_table'] = $secondary_request_table;
        
        $id = GatewayTransaction::create($payment_data)->id;
       
        if($request->mode=='wiretransfer')
        {
        $transaction_detail = GatewayTransaction::where('id', $id)->with('property')->get();
        return view('frontend/checkout/wire-transfer',  compact('transaction_detail', 'transaction_id'));
        }
        else
        {
        $GatewayTransaction = GatewayTransaction::where('id',$id)->first();
        $GatewayTransaction['return_url'] = url('/secondary-gateway-return');        
        return view('frontend.checkout.gateway-transfer',compact('GatewayTransaction'));
        }
    }

    public function SecondaryGatewayReturn(Request $request)
    {   
        $receipt_content = CMS::where('id',1)->first();
        $payment_reference = $request->payment_reference;
        $pt = new Paytabs(env("PAYTABMERCHANTEMAIL"), env("PAYTABSECRETKEY"));
        
        $result = $pt->verify_payment($payment_reference);         
        
        /*$result->reference_no;
        $result->transaction_id;
        $result->result;
        $result->response_code;
        $result->pt_invoice_id;
        $result->amount;
        $result->currency;*/


        if($result->response_code=='100')
        {
                $GatewayTransaction = GatewayTransaction::where('order_number', $result->reference_no)->first();
                $orderData['currency'] = $result->currency;
                $orderData['txn_id'] =  $result->transaction_id;
                $orderData['payment_status_code'] =  $result->response_code;
                $orderData['payment_status'] = '1';
                $id = $GatewayTransaction['id'];
         
                if(GatewayTransaction::where('id', $id)->update($orderData))
                {
                    $GatewayTransaction = GatewayTransaction::where('id', $id)->first();
                    $invest_data['amount'] = $GatewayTransaction['amount'];
                    $invest_data['request_reference_id'] = $GatewayTransaction['secondary_request_reference_id'];
                    $invest_data['property_id'] = $GatewayTransaction['property_id'];
                    $invest_data['user_id'] = Auth::id();
                    $invest_data['payment_ref_id'] = $GatewayTransaction['id'];            
                    $invest_data['status'] = '1';
                    $invest_data['created_by'] = $GatewayTransaction['user_id'];
                    SecondaryPropertyInvestment::create($invest_data);
                    
                    

                    if($GatewayTransaction['secondary_request_table']=='secondary_investment_request')
                    {
                    secondary_investment_request::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('is_paid'=>'1'));
                    
                    $secondary_investment_request = secondary_investment_request::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                    SharesHelper::Credit($secondary_investment_request['shares'],$invest_data['property_id'],$invest_data['user_id'],$secondary_investment_request['unit_price']);
                    SharesHelper::Debit($secondary_investment_request['shares'],$invest_data['property_id'],$secondary_investment_request['accepted_by'],$secondary_investment_request['unit_price']);
                    }
                    else
                    {                        
                    secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('is_paid'=>'1','status'=>'1'));
                    $secondary_investment_offer = secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                    $user_id = $secondary_investment_offer['to_user'];
                    if( $user_id == 0) {
                        $user_id = Auth::id();
                        secondary_investment_offer::where('id',$GatewayTransaction['secondary_request_reference_id'])->update(array('to_user'=>$user_id,'accepted_by' => $user_id));
                       
                    }
                    SharesHelper::Credit($secondary_investment_offer['shares'],$invest_data['property_id'],$user_id,$secondary_investment_offer['unit_price']);    
                    SharesHelper::Debit($secondary_investment_offer['shares'],$invest_data['property_id'],$secondary_investment_offer['user_id'],$secondary_investment_offer['unit_price']);    
                    }
                }
                
        }
         else
         {
             $GatewayTransaction = GatewayTransaction::where('order_number', $result->reference_no)->first();
             $orderData['currency'] = $result->currency;
             $orderData['txn_id'] =  $result->transaction_id;
             $orderData['payment_status_code'] =  $result->response_code;
             $orderData['payment_status'] = '2';
             $id = $GatewayTransaction['id'];

            GatewayTransaction::where('id', $id)->update($orderData);
         }   

        return view('frontend.checkout.paytabs-return',compact('result','receipt_content'));
    }


    public function GatewayReturn(Request $request)
    {
        
        $receipt_content = CMS::where('id',1)->first();
        $payment_reference = $request->payment_reference;
        $pt = new Paytabs(env("PAYTABMERCHANTEMAIL"), env("PAYTABSECRETKEY"));
        
        $result = $pt->verify_payment($payment_reference);
        /*$result->reference_no;
        $result->transaction_id;
        $result->result;
        $result->response_code;
        $result->pt_invoice_id;
        $result->amount;
        $result->currency;*/   
        
        if($result->response_code=='100')
        {
                $GatewayTransaction = GatewayTransaction::where('order_number', $result->reference_no)->first();
                $orderData['currency'] = $result->currency;
                $orderData['txn_id'] =  $result->transaction_id;
                $orderData['payment_status_code'] =  $result->response_code;
                $orderData['payment_status'] = '1';
                $id = $GatewayTransaction['id'];
         
                if(GatewayTransaction::where('id', $id)->update($orderData))
                {
                    $GatewayTransaction = GatewayTransaction::where('id', $id)->first();
                    $invest_data['amount'] = $GatewayTransaction['amount'];
                    $invest_data['property_id'] = $GatewayTransaction['property_id'];
                    $invest_data['user_id'] = Auth::id();
                    $invest_data['payment_ref_id'] = $GatewayTransaction['id'];            
                    $invest_data['created_by'] = $GatewayTransaction['user_id'];
                    PropertyInvestment::create($invest_data);
                }
                $PropertyFunctions = new PropertyFunctions();
                $PropertyFunctions->MoveToSecondary($GatewayTransaction['property_id']);
               
                SharesHelper::Credit($invest_data['amount'],$invest_data['property_id'],$invest_data['user_id']);
        }
         else
          {
              $GatewayTransaction = GatewayTransaction::where('order_number', $result->reference_no)->first();
              $orderData['currency'] = $result->currency;
              $orderData['txn_id'] =  $result->transaction_id;
              $orderData['payment_status_code'] =  $result->response_code;
              $orderData['payment_status'] = '2';
              $id = $GatewayTransaction['id'];

             GatewayTransaction::where('id', $id)->update($orderData);
          }   

        return view('frontend.checkout.paytabs-return',compact('result','receipt_content'));
    }
    

    /**
     * login with ajax call response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function loginAjax(Request $request)
    {

          if(Auth::attempt(['email' => trim($request->username), 'password' => trim($request->password)])) {
                $msg = array(
                    'status' => 'success',
                    'message' => 'Login Successful'
                );
                return response()->json($msg);

            } else {
                $msg = array(
                    'status' => 'error',
                    'message' => 'Login failed wrong user credentials.'
                );
                return response()->json($msg);
            }
    }


    /**
     * Validate Email response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function ValidateEmail(Request $request)
    {
        
         if (User::where('email', '=', $request->email)->exists()) {
                $msg = array(
                    'status' => 'error',
                    'message' => 'Email already exist.'
                );
                return response()->json($msg);

            } else {
                $msg = array(
                    'status' => 'success',
                    'message' => 'Email not exist'
                );
                return response()->json($msg);
            }
    }

    /**
     * Payment Success response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function paymentSuccess(Request $request)
    {
       
        $orderData['amount'] = $request->total;
        $orderData['currency'] = $request->currencyCode;
        $orderData['order_number'] = $request->orderID;
        $orderData['txn_id'] = $request->order_number;
        $orderData['payment_status'] = 1;
        $id = $request->tableid;
         
        if(GatewayTransaction::where('id', $id)->update($orderData))
        {   $GatewayTransaction = GatewayTransaction::where('id', $id)->first();
            $invest_data['amount'] = $GatewayTransaction['amount'];
            $invest_data['property_id'] = $request->property_id;
            $invest_data['user_id'] = $request->user_id;
            $invest_data['payment_ref_id'] = $id;            
            $invest_data['created_by'] = $request->user_id;
            PropertyInvestment::create($invest_data);
            
            if($GatewayTransaction['secondary_request_table']!='')
            {
                $transaction_request_data = $GatewayTransaction['secondary_request_table']::where('id',$GatewayTransaction['secondary_request_reference_id'])->first();
                SharesHelper::Credit($transaction_request_data['shares'],$invest_data['property_id'],$invest_data['user_id']);
            }
            else
            {
                $PropertyFunctions = new PropertyFunctions();
                $PropertyFunctions->MoveToSecondary($GatewayTransaction['property_id']);
                SharesHelper::Credit($invest_data['amount'],$invest_data['property_id'],$invest_data['user_id']);
            }
        }


         return view('frontend/checkout/payment-confirmation',  compact('request') );
    }

     /**
     * Wire transfer response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function wireTransfer(Request $request)
    {
       $transaction_id = $request->id;
        $transaction_detail = GatewayTransaction::where('id', $transaction_id)->with('property')->get();
        return view('frontend/checkout/wire-transfer',  compact('transaction_detail', 'transaction_id'));
    }

     /**
     * Wire transfer response method.
     *
     * @return \Illuminate\Http\Response
     */
    public function saveWireReference(Request $request)
    {
        $orderData['txn_id'] = $request->refno;
        $orderData['remark'] = $request->remark;
        $id = $request->transaction_id;
        
        if($id != ''){
            if (GatewayTransaction::where('id', $id)->update($orderData)) {
                $msg = array(
                    'status' => 'success',
                    'message' => 'Transaction id saved.'
                );
                return response()->json($msg);

            } else {
                $msg = array(
                    'status' => 'error',
                    'message' => 'There is some error please try again.'
                );
                return response()->json($msg);
            }
        }

        
    }

    /**
     * Secondary market confirmation
     *
     * @return \Illuminate\Http\Response
     */
    public function ProceesSecondaryInvestment(Request $request)
    {
        
        /*foreach ($notify_user->notifications as $notification) {
            echo $notification->type;
        }*/
        $property_id = $request->property_id;
        $property_name = $request->property_name;
        $shares = $request->shares;
        $unit_price = $request->unit_price;
        $user_id = Auth::user()->id;
        $user_name = Auth::user()->name;
        $url = url('/dashboard/secondary-market');
        secondary_investment_request::create(array("shares"=>$shares,"unit_price"=>$unit_price,"user_id"=>$user_id,"property_id"=>$property_id,"created_by"=>$user_id));
        $arr = array("shares"=>$shares,"ByUserId"=>$user_id,"ByUserName"=>$user_name,"property_id"=>$property_id,"property_name"=>$property_name,"URL" => $url);
        $propertyInvesters = PropertyInvestment::select('user_id')->where('property_id',$property_id)->groupBY('user_id')->get();
        foreach($propertyInvesters as $propertyInvester) {
            $notify_user = User::find($propertyInvester->user_id);
            $notify_user->notify(new NewMessage($arr));
         }
         
         
        if($property_id != ''){
            return view('frontend.checkout.secondary-proceed-confirm');
        }
        
    }

}
