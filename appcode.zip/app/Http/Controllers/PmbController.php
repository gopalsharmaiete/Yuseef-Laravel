<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use \App\Models\Masters;
use App\Models\Employee;
use App\Models\PMB;
use Illuminate\Support\Facades\Validator;
use Auth;

class PmbController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
      
    }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $id = Auth::id();
        if(!isset($request->user)) {
                $Users = Employee::select('id','name')->/*where('user_type','!=','admin')->*/orderBy('name','ASC')->get();
                $Recents = PMB::selectRaw('COUNT(id) as count,id,from_id,to_id,created_at,message')->orWhere(['to_id' => $id,'from_id'=>$id])->groupBy('from_id')->get();
                
                return view('frontend.pmb.index',compact('Users','Recents','id'));
        }

        $user = $request->user;
        return view('frontend.pmb.index',compact('user'));
    }
    
    
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
         $to = $request->to;
         $from = $request->from;
        
         $request->validate([
             'to' => 'required|numeric',
             'from' => 'required|numeric',
         ]);

       $chatData = $this->getChats($to,$from);
       return response()->json($chatData);


    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
         $message = $request->message;
         $request->validate([
             'message' => 'required',
             'from' => 'required|numeric',
             'to' => 'required|numeric'
         ]);
         $date = date('Y-m-d H:i:s');
         $pmb =PMB::create([
                'from_id' => $request->from,
                'to_id' => $request->to,
                'message' => $request->message,
                'created_at' => $date,
                'upadated_at' => $date
         ]);

         
        if(isset($pmb->id) && $pmb->id != null){
             $chatData = $this->getChats($request->to,$request->from);
             return response()->json($chatData);

        }

        return response()->json(['error'=>'There is some problem']);

   


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
     
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
       
    }


    /*** 
     *  Fetch Chat data from data base
     * @param int $to
     * @param int $from
     * 
     * @return Array $chatData
     * 
    */

    private function getChats(int $to, int $from) {
        $chatData = [];
        $chats = PMB::select('id','created_at','from_id','to_id','message')->where(['to_id' => $to,'from_id'=>$from])
               ->orWhere(function($query) use($to,$from){
                   $query->where(['to_id' => $from,'from_id' => $to]);
               })->orderBy('created_at','ASC')->get();

        foreach($chats as $chat) {
                    
              $chatData[]= [
                            'id' => $chat->id,
                            'to_id' => $chat->to_id,
                            'from_id' => $chat->from_id,
                            'to_name' => $chat->toUserName()[0],
                            'from_name' => $chat->fromUserName()[0],
                            'message' => $chat->message,
                            'date' => date('M-d-Y h:i', strtotime($chat->created_at))
                ];
        }

        return  $chatData;

    }




}
