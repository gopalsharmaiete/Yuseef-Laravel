<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Property;
use \App\Models\Masters;
use App\Models\CMS;
use App\Models\Upload;
use App\Models\PropertyAmenities;
use App\Models\PropertyInvestment;
use App\Helpers\ImagesHelper;
use Session;
use Redirect;
use File;
use App\Models\GatewayTransaction;

use Illuminate\Support\Facades\Validator;
use Auth;
use App\User;
use App\Models\forms;
use App\Models\forms_serials;
use App\UsersData;
use App\Helpers\TemplateHelper;
use App\Models\secondary_investment_request;
use App\Notifications\ApproveShares;
use App\Notifications\BidsShares;
use App\Models\refuse_secondary_investment_request;
use App\Models\RefuseSecondaryInvestmentOffer;
use App\Models\secondary_investment_offer;
use App\Models\UserPayment;
use App\Models\shares_history;
use App\Models\SecondaryPropertyInvestment;
use App\Notifications\NewMessage;
use App\Helpers\SharesHelper;

class UserDashboardController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
        
        $propertyInvestmentTotal = PropertyInvestment::selectRaw('SUM(amount) as total')->where('user_id',Auth::id())->get();

        $propertyInvestmentTotal = isset($propertyInvestmentTotal[0]['total']) ? $propertyInvestmentTotal[0]['total'] : 0;
        $secondaryInvestmentTotal = SecondaryPropertyInvestment::selectRaw('SUM(amount) as total')->where('user_id',Auth::id())->get();
        $secondaryInvestmentTotal = isset($secondaryInvestmentTotal[0]['total']) ? $secondaryInvestmentTotal[0]['total'] : 0 ; 
        $totalInvestment =  $propertyInvestmentTotal+$secondaryInvestmentTotal; 
      
        $userPayment = UserPayment::query();
        $amountReturnSecondaryRequest = $userPayment->selectRaw('SUM(secondary_investment_request.shares*secondary_investment_request.unit_price) as amount')
                                                     ->join('secondary_investment_request','user_payments.reference_id','=','secondary_investment_request.id')
                                                     ->where('user_payments.reference_table','secondary_investment_request')
                                                     ->where('secondary_investment_request.accepted_by',Auth::id())
                                                     ->get();
           
        
        $totalAmountReturnSecondaryRequest = isset($amountReturnSecondaryRequest[0]['amount']) ? $amountReturnSecondaryRequest[0]['amount'] : 0;
        $amountReturnSecondaryOffer = $userPayment->selectRaw('SUM(secondary_investment_offer.shares*secondary_investment_offer.unit_price) as amount')
                                                   ->join('secondary_investment_offer','user_payments.reference_id','=','secondary_investment_offer.id')
                                                   ->where('user_payments.reference_table','secondary_investment_offer')
                                                   ->where('secondary_investment_offer.user_id',Auth::id())
                                                   ->get();

        
        $totalAmountReturnSecondaryOffer =  isset($amountReturnSecondaryOffer[0]['amount']) ? $amountReturnSecondaryOffer[0]['amount'] : 0;
        $grossTotalInvestment = $totalInvestment - ($totalAmountReturnSecondaryRequest+$totalAmountReturnSecondaryOffer);
        $rateOfReturn = 0;
        
        /*if($propertyInvestmentTotal > 0) {
            $rateOfReturn = (($totalAmountReturnSecondaryRequest+$totalAmountReturnSecondaryOffer) - $propertyInvestmentTotal / $propertyInvestmentTotal)*100;
        }*/

       $rateOfReturn = SharesHelper::Rate_of_return();

        $rateOfReturn = $rateOfReturn < 0 ? 0: $rateOfReturn ;
        $numberOfinvestments = GatewayTransaction::selectRaw('COUNT(id) as count')->where('payment_status','1')->where('user_id',Auth::id())->get();
        $numberOfinvestments = isset($numberOfinvestments[0]['count']) ?  $numberOfinvestments[0]['count'] : 0; 
        $Property = Property::query();        
        $Property = $Property->with('countryname','contracts','investment')->with(['file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->with('SecondaryInvestmentBidsOffer','SecondaryInvestmentForDashboard')->with(['SharesHistory'=>function($q){ $q->where('user_id',Auth::id());}]);
        $Property->where('created_by',Auth::id())->orWhereHas('investment',function($q){
            $q->where('user_id',Auth::id());
        })->orWhereHas('SecondaryInvestment',function($q){
            $q->where('user_id',Auth::id());
        });
        $Property = $Property->get();
        
        return view('frontend.user-dashboard.dashboard-main',compact('Property', 'Category','numberOfinvestments','grossTotalInvestment','rateOfReturn'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value');
       return view('property.add',compact('country'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function saveProperty(Request $request)
    { 
        $user_id = Auth::id();
        //dd($user_id);	
        $imageExt = ['jpg','jpeg','png'];
        $fileSizeImage =1024*1024*10;
        $fileSizeDoc = 1024*1024*20;
        if($request->has('propertyimage')){
            foreach(request()->propertyimage as $image){
                 $size =  $image->getSize();
                 $extension = $image->getClientOriginalExtension();
                   
                 if(!in_array($extension,$imageExt)){
                    Session::flash('error', "Invalid image type please upload valid image");
                    return Redirect::back();
                 }

                if($size > ($fileSizeImage)) {
                    Session::flash('error', "Invalid image size please upload image less then 10MB");
                    return Redirect::back();
                  }
                
            }
        }

        if($request->has('propertydoc')){
            foreach(request()->propertydoc as $image){
                 $size =  $image->getSize();
             

                 if($size > $fileSizeDoc) {
                    Session::flash('error', "Invalid Document size please upload documents less then 20MB");
                    return Redirect::back();
                  }
                
            }
        }
      
        $validatedData = Validator::make($request->all(), [
            'name' => ['required', 'string'],
            'description' => ['required', 'string'],
            'base_price' => ['required','numeric'],
        ]);
       
//'propertyimage' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        if ($validatedData->fails())  {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }


        $update_data = $request->toArray();
        $update_data['created_at'] = date('Y-m-d H:i:s');
        $update_data['end_date'] = date('Y-m-d', strtotime($request->end_date));
		$update_data['created_by'] = $user_id;					
        unset($update_data['_token']);

        $id = Property::create($update_data)->id;
         
        $uploadPath = public_path('images/properties');
        $uploadPathDoc = public_path('documents/contracts');
        
        if($request->has('propertyimage')){
            foreach(request()->propertyimage as $image){
              
                ImagesHelper::upload('',$image,$uploadPath,$id,'property','property'); 
            }
        }
        
        if($request->has('propertydoc')){
            $x = 0;
            foreach(request()->propertydoc as $doc){
                ImagesHelper::upload('',$doc,$uploadPathDoc,$id,'contracts','property', request()->docname[$x]); 
                $x++;
            }
        }

        $amenity_data = $request->amenities;
        foreach($amenity_data as $key => $value)
        {   
            $amenity['property_id'] = $id;
            $amenity['amenity'] = $key;
            $amenity['value'] = $value;
            $amenity['created_at'] = date('Y-m-d H:i:s'); 

            $amenitiesdata[] = $amenity;
        }
        PropertyAmenities::insert($amenitiesdata);


        Session::flash('success', "Property created successfully");
        return Redirect::back();
     
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $Cmstemplate = CMS::find($id);
        return view('cms.edit',compact('Cmstemplate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validatedData = Validator::make($request->all(), [
            'title' => ['required', 'string'],
            'description' => ['required', 'string']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();           
        }

        $update_data = $request->toArray();
        unset($update_data['_token']);
        unset($update_data['_method']);
        CMS::where('id',$id)->update($update_data);
        return redirect('cms')->with('success','Updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        RolesPermissions::destroy($id);
        return 'done';
    }

    /**
     * Show the form for creating a new Property.
     *
     * @return \Illuminate\Http\Response
     */
    public function addProperty(Request $request)
    {
       $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
       $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value');
        $amenities = \App\Models\Multilingual::where(['locale'=>'en','status'=>'1','group'=>'prop-amenities-form'])->pluck('description','label');
       return view('frontend.user-dashboard.add-offering',compact('country', 'Category', 'amenities'));
    }

     /**
     * Edit the specified resource.
     *
     * @param  \App\property  $property
     * @return \Illuminate\Http\Response
     */
    public function propertyEdit($id)
    {
        $user_id = Auth::id();
        $type = Auth::user()->user_type;
        $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
        $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value');
        $amenities = \App\Models\Multilingual::where(['locale'=>'en','status'=>'1','group'=>'prop-amenities-form'])->pluck('description','label');
        

        $Property = Property::with(['amenities','file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->where("id",$id)->first();

         //dd($Property);
         if($Property->count() > 0 && $Property->created_by != $user_id && $type!='admin') {
             abort(404);
         }
         return view('frontend.user-dashboard.property-edit',compact('Property', 'Category', 'country', 'amenities', 'propertyAmenities'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function SaveUpdateProperty(Request $request)
    {
       
        $id = $request->id;
        $user_id = Auth::id(); 
        $checkProperty = Property::find($id);
        if( $checkProperty->created_by != $user_id && $type!='admin' ){
            abort(404);
        }

        if($checkProperty->secondary_target	== 1 && $checkProperty->base_price != $request->base_price) {
            Session::flash('error', "You can't update base price of property after it is listed in secondary market");
            return Redirect::back();
        }

        $imageExt = ['jpg','jpeg','png'];
        $fileSizeImage =1024*1024*10;
        $fileSizeDoc = 1024*1024*20;
        if($request->has('propertyimage')){
            foreach(request()->propertyimage as $image){
                 $size =  $image->getSize();
                 $extension = $image->getClientOriginalExtension();
                   
                 if(!in_array($extension,$imageExt)){
                    Session::flash('error', "Invalid image type please upload valid image");
                    return Redirect::back();
                 }

                if($size > ($fileSizeImage)) {
                    Session::flash('error', "Invalid image size please upload image less then 10MB");
                    return Redirect::back();
                  }
                
            }
        }

        if($request->has('propertydoc')){
            foreach(request()->propertydoc as $image){
                 $size =  $image->getSize();
             

                 if($size > $fileSizeDoc) {
                    Session::flash('error', "Invalid Document size please upload documents less then 20MB");
                    return Redirect::back();
                  }
                
            }
        }
      

        $validatedData = Validator::make($request->all(), [
            'name' => ['required', 'string'],
            'description' => ['required', 'string'],
            'base_price' => ['required','numeric'],
           
          ]);
          
        if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();           
         }
        
        $update_data = $request->toArray();
        $update_data['end_date'] = date('Y-m-d H:i:s',strtotime($request->end_date));
        unset($update_data['_token']);
        unset($update_data['_method']);
        unset($update_data['amenities']);
        unset($update_data['docname']);
        unset($update_data['postedas']);
        unset($update_data['propertyimage']);
        unset($update_data['propertydoc']);
        //return $update_data;
        Property::where('id',$id)->update($update_data);
    
        $amenity_data = array();
        $amenity_data = $request->amenities;
        foreach($amenity_data as $key => $value)
        {   
            $amenity['value'] = $value;            
            PropertyAmenities::where(['property_id'=>$id,'amenity'=>$key])->update($amenity);            
        }
 
        $uploadPath = public_path('images/properties');
        $uploadPathDoc = public_path('documents/contracts');
        
        if($request->has('propertyimage')){
            foreach(request()->propertyimage as $image){
                ImagesHelper::upload('',$image,$uploadPath,$id,'property','property'); 
            }
        }
        
        if($request->has('propertydoc')){
            $x = 0;
            foreach(request()->propertydoc as $doc){
                ImagesHelper::upload('',$doc,$uploadPathDoc,$id,'contracts','property', request()->docname[$x]); 
                $x++;
            }
        }

       
        return redirect()->back()->with('success','Updated successfully');
    }

    /**
     * Delete the specified resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function deleteFiles(Request $request)
    {
        $id = $request->id;
        $uploadPath = public_path($request->path);
        $fileName = $request->file;

        Upload::destroy($id);
        
       if(unlink($uploadPath.'/'.$fileName)) {
                $msg = array(
                    'status' => 'success',
                    'message' => 'Login Successful'
                );
                return response()->json($msg);

            } else {
                $msg = array(
                    'status' => 'error',
                    'message' => 'Login Fail'
                );
                return response()->json($msg);
            }
        
    }

    /**
     * pending transaction for current user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function pendingTransactions()
    {
        $user_id = Auth::id();
        $transaction_detail = GatewayTransaction::where('user_id', $user_id)->whereNull('txn_id')->with('property')->get();
        return view('frontend/user-dashboard/pending-transactions',  compact('transaction_detail'));
        
    }

    /**
     * settings for current user.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function userSettings($id)
    {
        $user =  User::find(Auth::id());
        return view('frontend/user-dashboard/settings',  compact('user'));
        
    }

    /**
     * settings for save user payment information.updatePaymentInfo
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function paymentInfo(request $request, $id='')
    {
        $message = '';
        $user_id = Auth::id();
        $forms_fields = forms::where('form', 'userCardDetails')->get();  
        $editCardinfo = '';
        if(!empty($id))
        {
            $editCardinfo = UsersData::where('serial',$id)->get();
        }

        if($request->has('card_num') && $request->has('exp_month')){

        $serial = forms_serials::where('form','user-card-info')->max('serial'); 
        $serial =$serial+1;
        forms_serials::create(array("serial"=>$serial,"form"=>'user-card-info'));

            $insert[0]['serial'] = $serial;
            $insert[0]['locale'] = 'en';
            $insert[0]['user_id'] = $user_id;
            $insert[0]['label'] = 'cc_name';
            $insert[0]['description'] = $request->cc_name;
            $insert[0]['created_by'] = $user_id;
            $insert[0]['created_at'] = date('Y-m-d H:i:s');

            $insert[1]['serial'] = $serial;
            $insert[1]['locale'] = 'en';
            $insert[1]['user_id'] = $user_id;
            $insert[1]['label'] = 'card_num';
            $insert[1]['description'] = $request->card_num;
            $insert[1]['created_by'] = $user_id;
            $insert[1]['created_at'] = date('Y-m-d H:i:s');

            $insert[2]['serial'] = $serial;
            $insert[2]['locale'] = 'en';
            $insert[2]['user_id'] = $user_id;
            $insert[2]['label'] = 'exp_month';
            $insert[2]['description'] = $request->exp_month;
            $insert[2]['created_by'] = $user_id;
            $insert[2]['created_at'] = date('Y-m-d H:i:s');

            $insert[3]['serial'] = $serial;
            $insert[3]['locale'] = 'en';
            $insert[3]['user_id'] = $user_id;
            $insert[3]['label'] = 'exp_year';
            $insert[3]['description'] = $request->exp_year;
            $insert[3]['created_by'] = $user_id;
            $insert[3]['created_at'] = date('Y-m-d H:i:s');


            if(UsersData::insert($insert)){
                $message = 'Card information saved successfully.';
            }
            
        }

        $cards_info = UsersData::where('user_id',$user_id)->get();
        return view('frontend/user-dashboard/paymentDetails',  compact('user_id', 'forms_fields', 'message', 'cards_info', 'editCardinfo'));
        
    }

    /**
     * settings for update user payment information.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function updatePaymentInfo(request $request, $id='')
    {
        
            $serial = $id;
            $request_data = $request->toArray();
                unset($request_data['_token']);
                unset($request_data['_method']);
                unset($request_data['serial']);
                
                foreach($request_data as $key=>$val)
                {
                   UsersData::where(["serial"=>$id,"label"=>$key])->update(array("description"=>$val));
                }
            

            return redirect()->back()->with('success','updated successfully');
       
        
    }

/**
     * settings for refer a friend.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function referfriend(request $request)
    {
        $user = Auth::user();
            if($request->has('rfemail')){
                $referredLink = url(config('app.url').'?referredby='.$user->id);
                TemplateHelper::SendMailTemplate('4',array($user->id=>$request->rfemail),$mails_cc=[], $constant_to='',$constant_cc='',$data=['LINK'=>$referredLink, 'RNAME'=>$request->rfname.' '.$request->rflname],$logo=1);
                return redirect()->back()->with('success','Mail sent successfully');
            } else{
                return view('frontend/user-dashboard/refer-friend',  compact('user'));
            }
            
    }

    
    /**
     *  Secondary market 
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */

    public function SecondaryMarketDashboard(Request $request)
    {
        $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
        $Property = Property::query();
        $users = User::pluck('name','id');
        $refuse_secondary_investment_request = refuse_secondary_investment_request::where('user_id',Auth::id())->pluck('user_id','request_id');
        $RefuseSecondaryInvestmentOffer = RefuseSecondaryInvestmentOffer::where('user_id',Auth::id())->pluck('user_id','request_id');
        $secondary_investment = SecondaryPropertyInvestment::where('user_id',Auth::id())->pluck('property_id','id')->toArray();
        $UserPropInvestment = PropertyInvestment::where('user_id',Auth::id())->pluck('property_id','id')->toArray();
        $Property = $Property->where('secondary_target','1')->with('countryname','contracts')->with('SecondaryInvestmentBidsOffer')
        ->with(['file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])
        ->with('SecondaryInvestmentRequest')
        ->with(['SharesHistory'=>function($q){ $q->where('user_id',Auth::id()); }])
        ->with(['SecondaryInvestmentGatewayTransaction'=>function($q){$q->where('user_id',Auth::id())->where('payment_status',1);}])
         ->whereHas('investment', function($q){
              $q->where('user_id',Auth::id());
         })->orWhereHas('SecondaryInvestmentRequest',function($q){
            $q->where('user_id',Auth::id());
         })->get();
         
       
        $commission_percent = Masters::where('master_id',6)->pluck('filled_value','option_value');
        return view('frontend.user-dashboard.dashboard-secondary-market',compact('Property', 'Category','commission_percent','users','refuse_secondary_investment_request','UserPropInvestment','secondary_investment'));
    }

        /**
     *  Secondary market 
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */

    public function SecondaryMarketAcceptAjax(Request $request)
    {
        $user_id = Auth::user()->id;
        $secondaryInvestmentStatus = secondary_investment_request::find($request->id);
        $totalShares =0;
        $sharesHistory = shares_history::where(['user_id'=>$user_id,'property_id' => $request->property_id])->get();
        if(!$sharesHistory->isEmpty()) {
           $sharesDebit =  $sharesHistory->where('type','debit')->sum('share');
           $shareCredit =  $sharesHistory->where('type','credit')->sum('shares');
           $totalShares =   $shareCredit-$sharesDebit;
        }

        if($secondaryInvestmentStatus->share > $totalShares) {
            return array("status"=>'error','message' => 'You Dont Have Enough Shares');
        }

        if($secondaryInvestmentStatus->status == 1) {
            return array("status"=>'error','message' => 'This bid is already accepted');
        }
        
        secondary_investment_request::where('id',$request->id)->update(array('status'=>'1','accepted_by'=>Auth::id()));
        
        $user_name = Auth::user()->name;
        $url = url('/dashboard/secondary-market');
        $arr = array("ByUserId"=>$user_id,"ByUserName"=>$user_name,"property_id"=>$request->property_id,"property_name"=>$request->property_name,'URL'=>$url);
        $secondary_investment_request=secondary_investment_request::where('id',$request->id)->first();
        $notify_user = User::find($secondary_investment_request['created_by']);
        $notify_user->notify(new ApproveShares($arr));
        return array("status"=>'success');
    }

       /**
     *  Secondary market 
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */

    public function SecondaryMarketRejectAjax(Request $request)
    {
        $insert = array('request_id'=>$request->id,'user_id'=>Auth::id(),'status'=>'1','created_by'=>Auth::id());
        if(refuse_secondary_investment_request::create($insert))
        {
          return array('status'=>'success');
        }
    }

       /**
     *  Counter bid action 
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */

    public function CounterBidAjax(Request $request)
    {
       
        $status = 'n/a';
       
       if($request->action=='accept')
       {
          $secondaryRequest = secondary_investment_offer::find($request->id);
        
          $sharesHistory = shares_history::where(['user_id'=> $secondaryRequest->user_id,'property_id' => $request->property_id])->get();
           if(!$sharesHistory->isEmpty()) {
                $sharesDebit =  $sharesHistory->where('type','debit')->sum('share');
                $shareCredit =  $sharesHistory->where('type','credit')->sum('share');
                $totalShares =   $shareCredit-$sharesDebit;
            }

        
            if($secondaryRequest->shares > $totalShares) {
                return ['status' => 'error','message' => 'The User Doesn\'t Have enough Shares'];
            }            
            
            if($secondaryRequest->status == '1') {
                return ['status' => 'error','message' => 'This Bid is already accepted'];
            }

       if($request->ToUser!=0)
           {
              secondary_investment_offer::where('id',$request->id)->update(array('status'=>'1'));

              $user_id = Auth::user()->id;
              $user_name = Auth::user()->name;
              $property_det = property::where('id',$request->property_id)->first();
              $url = url('/dashboard/secondary-market');
              $arr = array("ByUserId"=>$user_id,"ByUserName"=>$user_name,"property_id"=>$request->property_id,"property_name"=>$property_det['name'],"URL"=>$url);
              $notify_user = User::where('id',$request->ToUser)->first();
              $notify_user->notify(new BidsShares($arr));
           }
           else
           {
                $to_user=Auth::id();
                secondary_investment_offer::where('id',$request->id)->update(array('status'=>'1','to_user'=>$to_user,'accepted_by'=>$to_user));
           }

            $status =  'accepted';
            
       }
       elseif($request->action=='reject') 
       {
            if($request->ToUser!=0)
            {
              secondary_investment_offer::where('id',$request->id)->update(array('status'=>'2'));
            }
            else
            {
                $to_user=Auth::id();
                RefuseSecondaryInvestmentOffer::create([
                          'request_id'=>$request->id,
                          'user_id' => $to_user,
                          'created_by'=> $to_user,
                          'created_at' => date('Y-m-d H:i:s'),
                          'updated_at' => date('Y-m-d H:i:s'),
                    ]);
                
                //secondary_investment_offer::where('id',$request->id)->update(array('status'=>'2','to_user'=>$to_user,'accepted_by'=>$to_user));
            }
            $status = 'rejected';
       }

       
  
       return array('status'=>$status);

    }

    

     /**
     *  Secondary market 
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */

    public function SharesBid(Request $request)
    { 
       
        $user_id = Auth::id(); 
        $sharesHistory = shares_history::where(['user_id'=>$user_id,'property_id' => $request->property_id])->get();
       $shares = $request->shares;
        if(!$sharesHistory->isEmpty()) {
           $sharesDebit =  $sharesHistory->where('type','debit')->sum('share');

           $shareCredit =  $sharesHistory->where('type','credit')->sum('share');
           $totalShares =   $shareCredit-$sharesDebit;
         }
        
         if( $shares > $totalShares )  {
             return redirect()->back()->with('error','You Dont Have Enough Shares');
         }
         
        $insert_r = array('request_id'=>$request->request_id,'user_id'=>Auth::id(),'status'=>'1','created_by'=>Auth::id());
        refuse_secondary_investment_request::create($insert_r);

        $secondary_investment_request_data = secondary_investment_request::where('id',$request->request_id)->first();
        
        $insert = array('shares'=>$request->shares,'to_user'=>$secondary_investment_request_data['user_id'],'unit_price'=>$request->unit_price,'property_id'=>$request->property_id,'user_id'=>Auth::id(),'status'=>'0','created_by'=>Auth::id());
        secondary_investment_offer::create($insert);

        $user_id = Auth::user()->id;
        $user_name = Auth::user()->name;
        $property_det = property::where('id',$request->property_id)->first();
        $url = url('/dashboard/secondary-market');
        $arr = array("ByUserId"=>$user_id,"ByUserName"=>$user_name,"property_id"=>$request->property_id,"property_name"=>$property_det['name'],"URL"=>$url);
        $notify_user = User::where('id',$secondary_investment_request_data['user_id'])->first();
        $notify_user->notify(new BidsShares($arr));
        //return array("status"=>'success');

        return redirect()->back();
    } 

     /**
     *  SharesBidMain  
     *
     * @param  \Illuminate\Http\Request  $request
     * 
     * @return \Illuminate\Http\Response
     */

    public function SharesBidMain(Request $request)
    { 
       
        $user_id = Auth::id(); 
        $sharesHistory = shares_history::where(['user_id'=>$user_id,'property_id' => $request->property_id])->get();
        $shares = $request->shares;
        if(!$sharesHistory->isEmpty()) {
           $sharesDebit =  $sharesHistory->where('type','debit')->sum('share');

           $shareCredit =  $sharesHistory->where('type','credit')->sum('share');
           $totalShares =   $shareCredit-$sharesDebit;
         }
        
         if( $shares > $totalShares )  {
             return redirect()->back()->with('error','You Dont Have Enough Shares');
         }
       
         $insert = array('shares'=>$request->shares,'to_user'=>'','unit_price'=>$request->unit_price,'property_id'=>$request->property_id,'user_id'=>Auth::id(),'status'=>'0','created_by'=>Auth::id());
         secondary_investment_offer::create($insert);
        $user_name = Auth::user()->name;
        $property_det = property::where('id',$request->property_id)->first();
        $url = url('/dashboard/secondary-market');
        $arr = array("ByUserId"=>$user_id,"shares"=>$request->shares,"ByUserName"=>$user_name,"property_id"=>$request->property_id,"property_name"=>$property_det['name'],"URL"=>$url);
        $propertyInvesters = SecondaryPropertyInvestment::select('user_id')->where('user_id','!=',$user_id)->where('property_id',$request->property_id)->groupBY('user_id')->get();
        foreach($propertyInvesters as $propertyInvester) {
            $notify_user = User::find($propertyInvester->user_id);
            $notify_user->notify(new NewMessage($arr));
         }
        //return array("status"=>'success');

        return redirect()->back()->with('success','Sell Request Sent Successfully');
    } 

    /**
     *  Notification 
     * @return \Illuminate\Http\Response
     * 
     */

    public function notification() 
    {
       return view('frontend/user-dashboard/notification');
    }

     /**
     *  Transaction 
     * @return \Illuminate\Http\Response
     * 
     */

    public function transaction() 
    {
        $id = Auth::id();  
        $Property = Property::query();        
        $Property = $Property->with(['file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->whereHas('investment',function($q){
            $q->where('user_id',Auth::id());
        })->orWhereHas('SecondaryInvestment',function($q){
            $q->where('user_id',Auth::id());
        })->orWhereHas('SecondaryInvestmentBidsOffer',function($q){
            $q->where('to_user',Auth::id());
        });
        $Property = $Property->get();
        
        
       // $GatewayTransaction = GatewayTransaction::where('user_id',$id)->get(); 
        //dd($GatewayTransaction);
        return view('frontend/user-dashboard/transaction',compact('Property'));
    }


     /**
     *  Transfer
     * @return \Illuminate\Http\Response
     * 
     */

    public function transfer() 
    {
        $id = Auth::id();  
        
        $sendInvestmentRequest = secondary_investment_request::where('user_id',$id)->orWhere('accepted_by',$id)->get();
        $sendInvestmentOffer = secondary_investment_offer::where('user_id',$id)->orWhere('to_user',$id)->get();
        $Property = Property::query();        
        $Property = $Property->with(['file' => function($q) {
            $q->where(['uploadable_type'=>'property']);
        }])->whereHas('SecondaryInvestmentRequest',function($q) use($id){
                         $q->where('user_id',$id)->orWhere('accepted_by',$id);
                    })->orWhereHas('SecondaryInvestmentBidsOffer',function($q) use($id){
                        $q->where('to_user',$id)->orWhere('user_id',$id);
                    });
        $Property = $Property->get();
       
        return view('frontend/user-dashboard/transfer',compact('Property'));
    }

    /**
     *  Place Bids
     * @return \Illuminate\Http\Response
     * 
     */

    public function placeBids() 
    {
        $id = Auth::id();  
 
        $sendInvestmentOffer = secondary_investment_offer::where('user_id',$id)->orWhere('to_user',$id)->get();
      
        return view('frontend/user-dashboard/place-bids',compact('sendInvestmentOffer'));
    }


    public function NotificationRead()
    {   
        if(auth()->user()->unreadNotifications->markAsRead())
        {
            return 'true';
        }
        return 'false';
    }


}
