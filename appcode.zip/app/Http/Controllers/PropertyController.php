<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Property;
use \App\Models\Masters;
use App\Models\CMS;

use Illuminate\Support\Facades\Validator;
use Auth;

class PropertyController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,9']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$Property = Property::query();
        $Property = $Property->with('countryname','user')->get();
        return view('property.index',compact('Property'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $this->middleware(['ValidateRole:2,9']);
        $Category = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','3')->get()->pluck('name', 'option_value');
       
        $amenities = \App\Models\Multilingual::where(['locale'=>'en','status'=>'1','group'=>'prop-amenities-form'])->pluck('description','label');
       
       $country = Masters::orderBy('short_order','ASC')->where('status', '1')->where('master_id','2')->pluck('name', 'option_value');
       return view('frontend.user-dashboard.add-offering',compact('country','Category', 'amenities'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    { 
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'name' => ['required', 'string'],
            'description' => ['required', 'string']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }
        
        $update_data = $request->toArray();
        $update_data['created_at'] = date('Y-m-d H:i:s');
		$update_data['created_by'] = $user_id;					
        unset($update_data['_token']);

        Property::create($update_data);

        return redirect('property')->with('success','created successfully');
     
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {   
        $this->middleware(['ValidateRole:3,9']);
        $Cmstemplate = CMS::find($id);
        return view('cms.edit',compact('Cmstemplate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $validatedData = Validator::make($request->all(), [
            'title' => ['required', 'string'],
            'description' => ['required', 'string']
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();           
        }

        $update_data = $request->toArray();
        unset($update_data['_token']);
        unset($update_data['_method']);
        CMS::where('id',$id)->update($update_data);
        return redirect('cms')->with('success','Updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        Property::destroy($id);
        return 'done';
    }
	
    public function importproperty(Request $request)
    {
		$user_id = Auth::id();
		
		if ($request->input('submit')){
			$file = $request->file('csv_file');
			// File Details 
			$filename = $file->getClientOriginalName();
			$extension = $file->getClientOriginalExtension();
			$tempPath = $file->getRealPath();
			$fileSize = $file->getSize();
			$mimeType = $file->getMimeType();
			
			// Valid File Extensions
			$valid_extension = array("csv");
			
			// 2MB in Bytes
			$maxFileSize = 2097152; 
			
			// Check file extension
			if(in_array(strtolower($extension),$valid_extension)){
				if($fileSize <= $maxFileSize){
					// File upload location
					$location = public_path('uploads'); 
					// Upload file
					$file->move($location,$filename);

					// Import CSV to Database
					$filepath = $location."/".$filename;

					// Reading file
					$file = fopen($filepath,"r");

					$importData_arr = array();
					$i = 0;
					fgetcsv($file);
					//while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
					while (($filedata = fgetcsv($file)) !== FALSE) {
						$num = count($filedata);
				 
						// Skip first row (Remove below comment if you want to skip the first row)
						/*
						if($i == 0){
							$i++;
							continue; 
						}
						*/
					 for ($c=0; $c < $num; $c++) {
							$importData_arr[$i][] = $filedata [$c];
						}
						$i++;
					}
					fclose($file);
					
					foreach($importData_arr as $importData){

						$insertedData = array(
						   "name"=>$importData[0],
						   "offering_type"=>$importData[1],
						   "base_price"=>$importData[2],
						   "description"=>$importData[3],
						   "landmark"=>$importData[4],
						   "country"=>$importData[5],
						   "about_developer"=>$importData[6],
						   "about_project"=>$importData[7],
						   "end_date"=>date('Y-m-d',strtotime($importData[8])),
						   "created_at" => date('Y-m-d H:i:s'),
                           "created_by" => $user_id,
                           "status" => 1
						   );
				
						$data = Property::create($insertedData);
					}
					return redirect()->back()->with('success',' Property Imported Successful.');
				}else{
					return redirect()->back()->with('error','File too large. File must be less than 2MB.');
				}
			}else{
				return redirect()->back()->with('error','Invalid File Extension.');
			}
		}
    }
    


    /** 
     * 
     * To Toggle the status of the property 
     * @param   $id
     * @return \Illuminate\Http\Response
     * 
     **/

    public function toggle($id)
     {
       $Property = Property::where('id',$id)->first();
       $Property->toggleIsActive()->save(); // check model for reference
       return redirect()->back()->with('success','Property Status Changed Successfully');
     }

}
