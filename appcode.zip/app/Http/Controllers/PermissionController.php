<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\Models\Permissions;
use Illuminate\Support\Facades\Validator;
use Auth;

class PermissionController extends Controller
{

    protected $user;
    public function __construct()
    {
        $this->middleware(['auth']);
        $this->middleware(['ValidateRole:1,2']);
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $rolesData = Permissions::get();
       return view('permission.index',compact('rolesData'));
    }

    /**
     * Show the form for creating a new Permission.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
       
    }

    /**
     * Store a newly created Permission in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
        $user_id = Auth::id();	
        $validatedData = Validator::make($request->all(), [
            'name' => ['required', 'string'],
          ]);
          
          if ($validatedData->fails()) {
            return redirect()->back()->withErrors($validatedData)->withInput();
            //return $validatedData->messages();        
        }
        $insertedData = array('name'=>$request->name,
                            'value'=>$request->value,
							'created_at'=>date('Y-m-d H:i:s'),
							'created_by'=>$user_id,
							'updated_by'=>$user_id
							);
		$data = Permissions::create($insertedData);
        
        return redirect('permissions')->with('success','Role created successfully');
    }

    /**
     * Display the specified Permission.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        //
    }

    /**
     * Show the form for editing the specified Permission.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        
    }

    /**
     * Update the specified resource in Permission.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $update_data = $request->toArray();
        unset($update_data['_token']);
        Permissions::where('id',$id)->update($update_data);
        return 'done';
    }

    /**
     * Remove the specified Permission from storage.
     *
     * @param  \App\roles  $roles
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
        Permissions::destroy($id);
        return 'done';
    }
}
