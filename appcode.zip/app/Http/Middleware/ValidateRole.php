<?php

namespace App\Http\Middleware;
use Closure;
use App\Helpers\RolesHelper;
use App\Models\ManageTeams;
use App\User;
use Auth;

class ValidateRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $act, $module, $ret='')
    {
        $Rolesaccess = RolesHelper::check($act,$module);
        
        if(!$Rolesaccess || $Rolesaccess=='' || $Rolesaccess==null)
        {
            return redirect(route('login'));
        }
        
             if($Rolesaccess=='administrator')
                {
                    $request->attributes->add(['team_users'=>$Rolesaccess]);
                }
                else
                {   $user_id = Auth::id();
                   /* $teams = ManageTeams::query();
                    $teams->where('team_head_id',$user_id);
                    /*Start Same Team Same Data Also Group Head Data*/
                    /*$TeamHeadDtl = Auth::user()->TeamHead;
                    $team_head_id = 0;
                    if($TeamHeadDtl)
                    {
                        $team_head_id = Auth::user()->TeamHead->team_head_id;
                        $teams->orWhere('team_head_id', $team_head_id);
                    }
                    /*End Same Team Same Data Also Group Head Data*/
                    /*$teams = $teams->pluck('user_id','user_id');
                    $teams[$user_id] = $user_id;

                    /*Start Same Team Same Data Also Group Head Data*/
                    /*$teams[$team_head_id] = $team_head_id;
                    /*End Same Team Same Data Also Group Head Data*/
                    
                    /*$request->attributes->add(['team_users'=>$teams]);*/
                    
                }
           
        return $next($request);
    }
}
