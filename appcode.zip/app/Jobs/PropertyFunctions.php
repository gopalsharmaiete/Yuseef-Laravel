<?php
 namespace App\Jobs; 
 use App\Models\Property;
 use App\Models\AveragePriceHistory;
 use Auth;
 /**
 */

class PropertyFunctions {
 

  public function __construct() {
    
 }
 
 function MoveToSecondary($property_id){
    
    $Property = Property::where(['id'=>$property_id,'secondary_target'=>'0'])->first();
    
    if($Property['investment']->sum('amount') >= $Property['base_price'])
    {   $date = date('Y-m-d');
        Property::where('id',$property_id)->update(array('secondary_target'=>'1','secondary_date'=>$date));
    }
}


/////////
function Check_get_average_price($property_id){

    $share_unit_price = $investor_asked_price_avg = 1;
    $average_type = 'neutral';
    $percentage = 0;
    $Property = Property::with(['SecondaryInvestmentBidsOffer','SecondaryInvestment','SecondaryInvestmentRequest'])->where("id",$property_id)->first();
    
    $prev_average_price = $Property['prev_average_price'];
    if($Property->SecondaryInvestment->where('status','1')->sum('amount')>0){
        $share_unit_price = $Property['average_price'];
        $prev_average_price = $Property['prev_average_price'];
        if($Property->SecondaryInvestmentBidsOffer->where('status','1')->avg('unit_price')>0)
        {
            $investor_asked_price_avg = $Property->SecondaryInvestmentBidsOffer->where('status','1')->avg('unit_price');
        }
        
        $total_amount_placed_bids = $Property->SecondaryInvestmentRequest->where('status','1')->sum('unit_price');
        $count_investor_placed_bids = $Property->SecondaryInvestmentRequest->where('status','1')->unique('user_id')->count('user_id');
            $avg_placed_bids = 0;
        if($total_amount_placed_bids > 0 && $count_investor_placed_bids>0){
                    $avg_placed_bids = $total_amount_placed_bids/$count_investor_placed_bids;
        }
        
        $percentage = (($share_unit_price-$prev_average_price)/$prev_average_price)*100;



        $new_share_unit_price =  $investor_asked_price_avg + $avg_placed_bids/2;
 
        if($new_share_unit_price>0)
         {
            $new_share_unit_price = round($new_share_unit_price,2);
         }

        if($share_unit_price>0)
          {
            $share_unit_price = round($share_unit_price,2);
          }


        if($new_share_unit_price>$share_unit_price)
        {
            Property::where('id',$property_id)->update(array("average_price"=>$new_share_unit_price,"prev_average_price"=>$share_unit_price,"average_type"=>$average_type));
            if(Auth::id())
            {
            AveragePriceHistory::create(array("property_id"=>$property_id,"price"=>$new_share_unit_price,"created_by"=>Auth::id()));
            }
            $percentage = (($new_share_unit_price-$share_unit_price)/$share_unit_price)*100;
            $share_unit_price = $new_share_unit_price;
            $average_type = 'positive';                        
            
        }elseif($new_share_unit_price<$share_unit_price){
            Property::where('id',$property_id)->update(array("average_price"=>$new_share_unit_price,"prev_average_price"=>$share_unit_price,"average_type"=>$average_type));
            if(Auth::id())
            {
            AveragePriceHistory::create(array("property_id"=>$property_id,"price"=>$new_share_unit_price,"created_by"=>Auth::id()));
            }
            $percentage = (($new_share_unit_price-$share_unit_price)/$share_unit_price)*100;
            $share_unit_price = $new_share_unit_price;
            $average_type = 'negative';
        } else {
          
              if(($share_unit_price-$prev_average_price) >0) {
                $average_type = 'positive';
              } elseif(($share_unit_price-$prev_average_price) < 0) {
                $average_type = 'negative';
              }


        }

    }  
    
    $display_price = $share_unit_price - $prev_average_price;
    
    return array("average_price"=>round($share_unit_price,2),"average_type"=>$average_type,"percentage"=>$percentage,"display_price"=>$display_price);    
}
////////////

}