<?php
namespace App\Providers;

use App\Nav;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use App\Models\Setting;

class ComposerServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        // You can use Closure based composers
        // which will be used to resolve any data
        // in this case we will pass menu items from database
        View::composer('layouts.front-header', function ($view) {
             $langSettings = Setting::where(['setting_type' =>'language_toggle'])->get();
            $view->with('langSettings', $langSettings);
        });
    }
}