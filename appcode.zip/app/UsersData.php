<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsersData extends Model
{
   
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'locale', 'user_id', 'serial', 'label', 'description', 'status', 'created_by', 'created_at',
    ];

    public function rolename(){
        return $this->belongsTo('App\User','user_id');
    }

}
