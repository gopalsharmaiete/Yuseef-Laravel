<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AveragePriceHistory extends Model
{
    protected $table = 'average_price_history';
    protected $fillable = ['id','property_id','price','created_by','created_at','updated_at'];    
}
