<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Multilingual extends Model
{
    protected $fillable = ['id','label','description','group','locale','status','created_at','created_by','updated_at'];
}
