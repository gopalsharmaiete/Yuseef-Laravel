<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PMB extends Model
{
    protected $table = 'pmb';
    protected $fillable = ['id','from_id','to_id','message','created_at','updated_at'];



    public function toUserName()
     {
        return $this->belongsTo('App\User','to_id','id')->pluck('name');

     }

     public function fromUserName()
     {
        return $this->belongsTo('App\User','from_id','id')->pluck('name');

     }


}
