<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserPayment extends Model
{   
    protected $table = 'user_payments'; 
    protected $fillable =['id','transaction_id','remarks','amount','reference_table','reference_id','refund_request_id','created_by','created_at','updated_at'];    

   public function amountReturnSecondaryRequest() {
       return $this->belongsTo('App\Models\secondary_investment_request','reference_id');
   }

   public function amountReturnSecondaryOffer() {
    return $this->belongsTo('App\Models\secondary_investment_offer','reference_id');
   }


}