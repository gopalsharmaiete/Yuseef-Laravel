<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Property extends Model
{   
    protected $table = 'property'; 
    protected $fillable =['id','name', 'offering_type', 'landmark','secondary_target','secondary_date','country','description','base_price', 'about_developer', 'about_project', 'end_date', 'status', 'average_price','prev_average_price','average_type','created_at','created_by','updated_at'];    

    
    /**
     *  Toggle The status of the proprty
     *  @param none
     *  @return Illuminate\Database\Eloquent\Model
     * 
     * 
     * **/
    public function toggleIsActive()
     {
            $this->status= !$this->status;
            return $this;
     }


    public function countryname(){
        return $this->hasOne('App\Models\Masters','option_value' , 'country' )->where('master_id', '2')->where('status', '1');
    }

    public function investment(){
        return $this->hasMany('App\Models\PropertyInvestment','property_id','id');
    }

    public function contracts(){
        return $this->hasMany('App\Models\Upload','uploadable_id')->where('uploadable_type','contracts');
    }

    public function amenities(){
        return $this->hasMany('App\Models\PropertyAmenities','property_id','id');
    }

    public function user(){
        return $this->belongsTo('App\Models\Employee','created_by');
    }

    public function file(){
        return $this->hasMany('App\Models\Upload','uploadable_id');
    }

    public function SecondaryInvestment(){
        return $this->hasMany('App\Models\SecondaryPropertyInvestment','property_id','id');
    }

    public function SecondaryInvestmentForDashboard(){
        return $this->hasMany('App\Models\SecondaryPropertyInvestment','property_id','id');
    }

    public function SecondaryInvestmentRequest(){
        return $this->hasMany('App\Models\secondary_investment_request','property_id','id');
    }

    public function SecondaryInvestmentBidsOffer(){
        return $this->hasMany('App\Models\secondary_investment_offer','property_id','id');
    }

    public function SecondaryInvestmentGatewayTransaction(){
        
        return $this->hasMany('App\Models\GatewayTransaction','property_id','id');
    }

    public function SharesHistory(){
        
        return $this->hasMany('App\Models\shares_history','property_id','id');
    }

    public function gatewayTransaction($user_id) {
        return $this->hasMany('App\Models\GatewayTransaction','property_id','id')
                    ->where('user_id',$user_id)
                    ->where('payment_status','1');
    }

    public function secondaryInvestmentBidsOfferTransfer($user_id){
        return $this->hasMany('App\Models\secondary_investment_offer','property_id','id')
                    ->where('user_id',$user_id)
                    ->orWhere('to_user',$user_id);
    }

    public function secondaryInvestmentRequestTransfer($user_id){
        return $this->hasMany('App\Models\secondary_investment_request','property_id','id')
                    ->where('user_id',$user_id)
                    ->orWhere('accepted_by',$user_id);
    }

}
