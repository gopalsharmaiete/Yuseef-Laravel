<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RolesPermissions extends Model
{    
    protected $fillable =['id','role_id','permission_id','module_id','created_by','updated_by','status'];    
}
