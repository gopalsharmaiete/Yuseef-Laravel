<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PropertyInvestment extends Model
{
    protected $table = 'property_investment';
    protected $fillable = ['id','amount','property_id','user_id','payment_ref_id','status','created_at','created_by','updated_at'];



    public function property(){
    return $this->belongsTo('App\Models\Property','property_id');    
    }

    public function user(){
        return $this->belongsTo('App\Models\Employee','user_id');
    }

    public function transaction(){
        return $this->belongsTo('App\Models\GatewayTransaction','payment_ref_id');
    }

}
