<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Mailtemplate extends Model
{
    protected $table = 'mailtemplate';
    protected $fillable = ['id','title','description','status','created_at','created_by','updated_at'];
	
}
