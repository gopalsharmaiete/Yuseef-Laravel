<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Masters extends Model
{
    public $timestamps = false;

    protected $fillable = ['id','master_id','module','type','name','option_value','filled_value','short_order','status','created_at'];
	
}
