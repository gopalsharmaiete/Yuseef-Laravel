<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class secondary_investment_request extends Model
{
    public $timestamps = false;
    protected $table ='secondary_investment_request';
    protected $fillable = ['id','shares','unit_price','accepted_by','is_paid','property_id','user_id','status','created_by','updated_at','created_at'];
	
    public function property(){
        return $this->belongsTo('App\Models\Property','property_id');    
    }

    public function fromUser(){
        return $this->belongsTo('App\Models\Employee','user_id');    
    }

    public function toUser(){
        return $this->belongsTo('App\Models\Employee','accepted_by');    
    }

    public function transactionId(){
        return $this->hasOne('App\Models\GatewayTransaction','secondary_request_reference_id','id')->where('secondary_request_table','secondary_investment_request');    
    }

}
