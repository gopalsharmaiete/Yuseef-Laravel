<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CMS extends Model
{
    protected $table = 'cms';
    protected $fillable = ['id','title','description','status','created_at','created_by','updated_at'];
}
