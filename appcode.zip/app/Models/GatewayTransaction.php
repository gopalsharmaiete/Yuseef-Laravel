<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GatewayTransaction extends Model
{
    protected $table = 'gateway_transactions';
    protected $fillable = ['id','user_id','card_num','secondary_request_table','secondary_request_reference_id','payment_source','card_cvv','card_exp_month','card_exp_year','property_id','amount', 'commission_amount', 'commission_percentage', 'total','currency','order_number','txn_id','gateway_id','payment_status','payment_status_code','created_at','updated_at'];

    public function gateway()
    {
        return $this->belongsTo('App\Models\Masters','option_value')->where('master_id',5);
    }

    public function property(){
        return $this->belongsTo('App\Models\Property','property_id');    
    }

    public function secondaryInvestmentRequest(){
        return $this->belongsTo('App\Models\secondary_investment_request','secondary_request_reference_id')->pluck('share');    
    }
    
    public function user(){
        return $this->belongsTo('App\Models\Employee','user_id');
    }        

}
