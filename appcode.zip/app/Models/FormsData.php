<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormsData extends Model
{
    protected $table = 'forms_data';
    protected $fillable = ['id','label','serial','description','group','locale','status','created_at','created_by','updated_at'];


    public function file(){
        return $this->hasMany('App\Models\Upload','uploadable_id','serial');
    }
}
