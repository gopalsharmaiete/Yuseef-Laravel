<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SecondaryPropertyInvestment extends Model
{
    protected $table = 'secondary_property_investment';
    protected $fillable = ['id','amount','property_id','request_reference_id','user_id','payment_ref_id','status','created_at','created_by','updated_at'];



    public function property(){
    return $this->belongsTo('App\Models\Property','property_id');    
    }

    public function user(){
        return $this->belongsTo('App\Models\Employee','user_id');
    }

    public function transaction(){
        return $this->belongsTo('App\Models\GatewayTransaction','payment_ref_id');
    }

}
