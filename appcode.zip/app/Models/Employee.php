<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{   
    protected $table = 'users'; 
    protected $fillable =['id','name','email','password','status','role','user_type','status','created_by','updated_by'];    

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function rolename(){
        return $this->belongsTo('App\Models\roles','role','value');
    }


    public function gatewayTransaction($property_id) {
       return $this->hasMany('App\Models\GatewayTransaction','user_id')
                    ->where('property_id',$property_id)
                    ->where('payment_status','1')
                    ->where('gateway_id','1');
    }

    /**
     *  Toggle and enable/disable the user
     *  @param none
     *  @return Illuminate\Database\Eloquent\Model
     *
     **/
    public function toggleIsActive()
     {
            $this->status= !$this->status;
            return $this;
     }
}
