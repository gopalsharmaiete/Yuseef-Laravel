<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class shares_history extends Model
{
    public $timestamps = false;
    protected $table ='shares_history';
    protected $fillable = ['id','share','property_id','type','user_id','transaction_id','unit_price','market','status','created_by','updated_at','created_at'];
	
}
