<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Upload extends Model
{
	protected $table = 'uploads'; 
    protected $fillable = ['id','title','name','description','path','module','extension','uploadable_id','uploadable_type','status','created_at','created_by','updated_at'];


    public function uploadable()
    {
        return $this->morphTo();
    }

}
