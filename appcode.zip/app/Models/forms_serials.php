<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class forms_serials extends Model
{
    Protected $table='forms_serials';
    protected $fillable = ['serial','form','status'];


    public function data(){
        return $this->hasMany('App\Models\FormsData','serial','serial');
    }

    public function file($type='team'){
        return $this->hasMany('App\Models\Upload','uploadable_id','serial');
    }

}
