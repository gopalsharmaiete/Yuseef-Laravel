<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class forms extends Model
{
    protected $fillable = ['id','label','type','form','module','status'];
}
