<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class refuse_secondary_investment_request extends Model
{
    public $timestamps = false;
    protected $table ='refuse_secondary_investment_request';
    protected $fillable = ['id','request_id','user_id','status','created_by','updated_at','created_at'];
	
}
