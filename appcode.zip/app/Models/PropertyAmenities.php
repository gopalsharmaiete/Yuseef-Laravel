<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PropertyAmenities extends Model
{   
    protected $table = 'property_amenities'; 
    protected $fillable =['id','property_id', 'amenity', 'value', 'created_at','updated_at'];

}
