<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{   
    protected $table = 'blog'; 
    protected $fillable =['id','title','description','author','status','created_by','created_at','updated_at'];    

    public function file(){
        return $this->hasMany('App\Models\Upload','uploadable_id');
    }

}
